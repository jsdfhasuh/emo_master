# 固定源码最终回归

- 源码 SHA：9fa574597961d5e86097361417a4f70de79e3809。
- 70 个去重模块：766 通过、0 失败、0 错误、0 跳过，2 个历史迁移夹具分支取消选择；耗时 255.38 秒。合计收集 768 例。
- 唯一排除项：tests/designer/test_runtime_validation_feedback.py::testUpgradedDraftResourceFailureCanBeFixedAndRevalidated，沿用历史 runner 的两个参数化分支。本轮新增失败没有被排除。
- Ruff：30 个改动 Python 文件通过；mypy：19 个改动源码文件通过；scripts/gen_proto.py --check、提交差异和工作树差异检查全部通过。
- 执行前后 HEAD/tree 和工作树保持不变；1,299 个 tracked 源码、测试、脚本、proto、示例和配置文件逐一核验 Git blob，无差异。Operator 历史 JSON 夹具另行逐字节核验。
- 环境：Linux、Python 3.10.22、PySide2 5.15.2.1、Qt 5.15.2，QT_QPA_PLATFORM=offscreen。此处是原生 Qt 自动化、子进程和模拟设备证据，不冒充人工桌面、Windows 冻结包或真实硬件验收。

## 命令和证据

完整实际 argv、工作目录、环境、耗时及退出码见 validation.json 和 FINAL_MANIFEST.json；逐项可复制的命令见 *.command.txt；pytest 原始日志/XML 见 aggregate.log / aggregate.xml；源码 blob 见 source-before.json / source-after.json。全部文件 SHA-256 见 SHA256SUMS.txt。

## 测试修正与桌面源码等价

9fa5745 仅修正两个测试文件，没有改动产品源码。产品 src tree 与桌面验证使用的 598d4a8 完全相同：e909de90682d28e0e5b760bb011d24cbecf27a2a。详情见 desktop-source-equivalence.json 和 test-only-corrections.patch。

修正保留了 Runtime 在线配置保护及 P5 发布保护：在线状态拒绝重新加载后保留已加载文件；在新的空 Runtime 单独验证歧义路径；旧包生成器使用明确的 2.1 夹具，而不把当前版本新建工程误当作旧夹具。另修正导入 pytest 夹具的 Ruff noqa 行位置。

较早的 598d4a8 固定源码失败、基线比较及更早运行中源码发生变化的记录均保留在相邻目录。它们不计入上述最终通过数量。最终数字也不叠加此前 11 例定点测试或 2 例单独诊断复跑。
