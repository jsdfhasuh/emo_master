# 最终固定源码受影响模块回归

源码 SHA：e7ceb5135f2f5dcc158110fb23da29c049bbe2be。产品 src tree：0fe7aa08214a3f8068ddb0f69359836238b91557。

本轮实际执行：15 个去重模块，156 passed，0 failed / errors / skipped / deselected。耗时 41.256 秒。覆盖同一 Designer 会话 A→B 显式发布后 F5、图片读取/续租、RuntimeController、inspection、安全副本边界、校验、日志归属、保存/另存/打开/新建/启动入口与发布。

Ruff 检查 33 个本轮变更 Python 文件；mypy 检查 22 个变更 src 文件；proto 生成物检查、提交差异与工作树 diff --check 均通过。

运行前后 HEAD、tree 和 1299 个已跟踪源码/测试/支持文件的 Git blob 与 SHA-256 全部一致。工作树已跟踪文件无修改。父任务单独撰写的未跟踪报告 docs/testing/2026-10-22-desktop-workflow-remediation.md 不属于产品测试输入，已明确记录，没有修改或加入本提交。

完整环境、命令、计数、日志及 XML 见 FINAL_MANIFEST.json、validation.json、*.command.txt、aggregate.log / aggregate.xml、source-before.json / source-after.json。Python 3.10.22，PySide2 5.15.2.1 / Qt 5.15.2，QT_QPA_PLATFORM=offscreen；使用临时工程、模拟资源和 loopback RPC，不代表真实设备验收或人工桌面走查。

保留失败：attempt-setup-error 是测试执行器未建立临时父目录的 156 个 setup errors，测试正文均未执行；修正执行器设置后在相同源码重跑通过，没有改产品或测试来跳过失败。

此前 73194ec 的完整 79 模块聚合实际为 881 passed、2 failed、0 errors/skipped、2 deselected；两项失败是 4/5 路并行图像 While 场景，同 SHA 单独重跑整个 parallel_workflows 模块 11 passed。该原始失败与诊断完整保留于 ../final-73194ec，不能写成原聚合全部通过。历史 2 项 deselected 仅为同一旧迁移用例的两个参数分支，排除路径记录在那里。本最终修复只重跑直接受影响模块，没有再次运行整个并行压力聚合，也不把历史通过数当作本 SHA 通过数。

修复前/后原生反例、最小修复说明及无阻断审查结论见 ../replacement-run-fix/README.md。提交前的 81 + 75 次测试与本次 156 次覆盖重复，不应相加宣称独立测试总数。
