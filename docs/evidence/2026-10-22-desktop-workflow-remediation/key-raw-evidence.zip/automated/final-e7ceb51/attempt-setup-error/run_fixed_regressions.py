from __future__ import annotations
import ast, hashlib, json, os, platform, shlex, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
import xml.etree.ElementTree as ET

REPO=Path('/workspace/shared/emomaster-remediate-20261022')
OUT=Path('/workspace/shared/emomaster-remediation-evidence-20261022/evidence/automated/final-e7ceb51')
TEMP=Path('/tmp/emomaster-remediation-evidence/final-e7ceb51')
SHA='e7ceb5135f2f5dcc158110fb23da29c049bbe2be'
BASELINE='b1bf28a'
PYTHON='/workspace/shared/device-manager-acceptance-20261019/venv/bin/python'

def git(*args):
    return subprocess.check_output(['git',*args],cwd=REPO,text=True).strip()

def capture(label):
    paths=git('ls-tree','-r',SHA,'--','src','tests','scripts','proto','examples','pyproject.toml','AGENTS.md','.gitattributes').splitlines()
    files=[]
    for item in paths:
        meta,path=item.split('\t',1)
        expected=meta.split()[2]
        full=REPO/path
        if not full.exists():
            files.append(dict(path=path,committedBlob=expected,missing=True))
            continue
        data=full.read_bytes()
        actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        files.append(dict(path=path,committedBlob=expected,actualBlob=actual,sha256=hashlib.sha256(data).hexdigest(),matches=actual==expected))
    result=dict(at=datetime.now(timezone.utc).isoformat(),head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--short','--untracked-files=no'),untracked=git('ls-files','--others','--exclude-standard'),files=files)
    result['mismatches']=[f['path'] for f in files if not f.get('matches',False)]
    (OUT/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    return result

def assigned_list(code,name):
    for node in ast.parse(code).body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets):
            return ast.literal_eval(node.value)
    raise ValueError(name)

chain=[]
regression=[]
added=['tests/runtime/test_new_project_online_isolation.py', 'tests/designer/test_runtime_controller.py', 'tests/designer/test_node_image_viewer.py', 'tests/designer/test_inspection_images.py', 'tests/designer/test_runtime_log_usability.py', 'tests/runtime/test_run_inspection_rpc.py', 'tests/designer/test_main_window_project_save_load.py', 'tests/designer/test_named_project_files.py', 'tests/designer/test_startup_project_entry.py', 'tests/designer/test_desktop_new_project_regression.py', 'tests/designer/test_project_configuration_ui.py', 'tests/designer/test_publication_diagnostic_navigation.py', 'tests/designer/test_device_usability_publication.py', 'tests/runtime/test_initial_project_configuration.py', 'tests/runtime/test_named_project_runtime.py']
tests=list(dict.fromkeys(added))
changed=[p for p in git('diff','--name-only',BASELINE,SHA).splitlines() if p.endswith('.py')]
env=dict(os.environ,PYTHONPATH=str(REPO/'src')+os.pathsep+str(REPO),PYTHONIOENCODING='utf-8',QT_QPA_PLATFORM='offscreen',EMO_TEST_SOURCE_SHA=SHA,PYTHONDONTWRITEBYTECODE='1',MYPY_CACHE_DIR=str(TEMP/'mypy-cache'))
record=dict(sourceSha=SHA,sourceTree=git('rev-parse',SHA+'^{tree}'),baseline=git('rev-parse',BASELINE),platform=platform.platform(),executable=PYTHON,workingTree=str(REPO),environment={k:env[k] for k in ('PYTHONPATH','PYTHONIOENCODING','QT_QPA_PLATFORM','EMO_TEST_SOURCE_SHA','PYTHONDONTWRITEBYTECODE','MYPY_CACHE_DIR')},historicalChain=chain,historicalRegression=regression,addedTests=added,deduplicatedTestModules=tests,changedPythonFiles=changed,excluded=[],commands=[])

def save():
    (OUT/'validation.json').write_text(json.dumps(record,indent=2)+'\n')

def run(label,args):
    started=datetime.now(timezone.utc).isoformat(); start=time.monotonic()
    command=shlex.join(args)
    print('RUN '+label+': '+command,flush=True)
    (OUT/(label+'.command.txt')).write_text('cd '+shlex.quote(str(REPO))+'\n'+ ' '.join(k+'='+shlex.quote(v) for k,v in record['environment'].items())+' '+command+'\n')
    with (OUT/(label+'.log')).open('wb') as log:
        completed=subprocess.run(args,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
    entry=dict(label=label,argv=args,command=command,cwd=str(REPO),started=started,elapsedSeconds=round(time.monotonic()-start,3),exitCode=completed.returncode,log=label+'.log')
    record['commands'].append(entry);save()
    print(label+': exit='+str(completed.returncode),flush=True)
    print((OUT/(label+'.log')).read_text(errors='replace')[-4000:],flush=True)
    return entry

assert set(git('ls-files','--others','--exclude-standard').splitlines()) <= {'docs/testing/2026-10-22-desktop-workflow-remediation.md'}
before=capture('source-before');record['sourceBefore']=dict(head=before['head'],tree=before['tree'],fileCount=len(before['files']),mismatches=before['mismatches'],status=before['status']);save()
assert before['head']==SHA and not before['mismatches'] and not before['status'],record['sourceBefore']
run('environment',[PYTHON,'-c',"import emo_master,sys,json,PySide2; from PySide2.QtCore import qVersion; from pathlib import Path; import os; print(json.dumps(dict(python=sys.version,PySide2=PySide2.__version__,Qt=qVersion(),importPath=emo_master.__file__),indent=2)); assert os.path.samefile(Path(emo_master.__file__).parent.parent,Path.cwd()/'src'); assert sys.version_info[:2]==(3,10) and PySide2.__version__=='5.15.2.1'"])
run('aggregate',[PYTHON,'-m','pytest','-q','-rA','-p','no:cacheprovider','--basetemp='+str(TEMP/'pytest-aggregate'),'--junitxml='+str(OUT/'aggregate.xml'),*['--deselect='+x for x in record['excluded']],*tests])
if (OUT/'aggregate.xml').exists():
    root=ET.parse(OUT/'aggregate.xml').getroot()
    suites=list(root) if root.tag=='testsuites' else [root]
    counts={key:sum(int(s.get(key,'0')) for s in suites) for key in ('tests','failures','errors','skipped')}
    counts['passed']=counts['tests']-counts['failures']-counts['errors']-counts['skipped']
    record['aggregateCounts']=counts;save()
run('ruff',[PYTHON,'-m','ruff','check','--no-cache',*changed])
run('mypy',[PYTHON,'-m','mypy','--cache-dir='+str(TEMP/'mypy-cache'),*[p for p in changed if p.startswith('src/')]])
run('proto',[PYTHON,'scripts/gen_proto.py','--check'])
run('diff-check',['git','diff','--check',BASELINE,SHA])
run('worktree-diff-check',['git','diff','--check'])
after=capture('source-after');record['sourceAfter']=dict(head=after['head'],tree=after['tree'],fileCount=len(after['files']),mismatches=after['mismatches'],status=after['status']);record['sourceUnchanged']=before['head']==after['head'] and before['tree']==after['tree'] and before['files']==after['files'] and before['status']==after['status'];save()
print(json.dumps(dict(counts=record.get('aggregateCounts'),sourceUnchanged=record['sourceUnchanged'],commands=[dict(label=x['label'],exitCode=x['exitCode']) for x in record['commands']]),indent=2),flush=True)
sys.exit(int(any(x['exitCode']!=0 for x in record['commands']) or not record['sourceUnchanged']))
