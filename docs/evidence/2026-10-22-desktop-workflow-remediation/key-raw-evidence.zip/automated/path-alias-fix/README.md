# 首次发布后的路径别名身份修复

- 现场：显式首次发布已 COMMITTED，doc/execution revision 均为 1，随后 F5 报 E_PROJECT_NOT_LOADED，无 Job 创建。工程路径经过目录符号链接；现场归档和截图路径见 actual-desktop-identity.json。
- 根因：首次发布解析 canonical sourcePath，而 Designer 保留用户选择的 alias。Runtime._projectMatches 原先只做字符串比较。
- 最小修复：直接 UUID / 原有字符串匹配不变；补用已有 inspection reference canonical identity 比较已载入目录/文件。另一个路径中 UUID 相同的工程副本仍拒绝。没有放宽发布、项目隔离或启动守卫。
- 失败回归：9fa5745 产品源码不变，仅新增固定 2.7 格式用例；嵌入式和 loopback 两分支均在 COMMITTED 后，通过真实 F5 QAction 进入 RuntimeController / worker，0 Job，E_PROJECT_NOT_LOADED。before.log/xml + before-source.txt + regression-before-fix.patch 保留证据。
- 首次测试编写时没有显示 offscreen 窗口，QAction 尚未刷新而断言失败，属于用例搭建问题。test-development-initial.log/xml 原样保留，不算产品缺陷。修正为正常 show + processEvents 后才得到上述产品失败。
- 修复后的提交前定点检查：33 passed，0 failed，0 skipped。包含连续两次 F5 完成、UUID 和 canonical path 接受，以及相同内容不同文件/错误 UUID 拒绝；原工程字节不变。此运行基于 9fa5745 工作树上的修复，最终提交还添加一个 global-variable alias 断言，因此最终提交的全量聚合才是正式结果。
- 产品与测试提交：73194eceef2819b2207129eeb55311efb4be8f79。需重启 Designer/Runtime 加载修复版本；与旧桌面进程不再源码等价。最终固定源码回归位于 ../final-73194ec/。
