# 在线工程替换后运行身份修复

复现源码：73194eceef2819b2207129eeb55311efb4be8f79。
修复提交：e7ceb5135f2f5dcc158110fb23da29c049bbe2be。

实际桌面问题是发布成功后运行身份错误，不是发布失败。首次工程 A 的 Runtime 源路径可指向本地文件；用 B 替换后，Runtime 正确改为自身管理的 online-projects/.../project.emoproj。Designer 原来仍把本地 B 路径送给 inspection 和 StartJob。

before.log / before.xml：2 个实际原生 QAction/F5 回归失败（embedded、loopback），A 的 Job 和图片均成功，B 的显式替换已 COMMITTED R2，随后 E_PROJECT_NOT_LOADED 且没有 B Job。regression-before-fix.patch 保存当时测试，before-source.txt 保存生产源码 SHA。

after.log：修复工作树上 81 passed，0 failed/errors/skipped。entry-publication.log：75 passed，0 failed/errors/skipped。这两组是提交前检查，不能再与 final-e7ceb51 的同组 156 次固定提交重跑相加冒充独立测试数。

修复只改三个 Designer 文件：在同步之后获取 UUID 已核对的在线 sourcePath；Run 和 Validate 共用此引用；图像选择使用 inspection 会话持有的引用。Runtime 的路径/UUID 匹配与冻结副本、Job、revision、nodeRun 校验未放宽。本地文件归属与内容不变。回归还检查 B 未发布时取消运行不启动 A、B 发布后 F5 完成、实际解码像素、同一会话续租、本地路径仍被 Runtime 拒绝及工具栏校验成功。

只读审查：父任务及独立审查者均无阻断意见，确认没有任意 UUID 回退或本地路径回退，读取引用与会话引用一致。

原始测试搭建失败另行保留：test-development-policy 缺少替换必须显式指定的 stop/drain 策略；test-development-outputs 是临时图像工作流输出脚手架；test-development-catalog 是在算子目录 ready 前装载测试工作流导致端口元数据不完整。最终测试等待原生目录 ready，使用正常无根输出的图像流程，并保持明确发布策略。这些记录不是产品修复前的正式反例。

最终结果与源码不变性见 ../final-e7ceb51/，具体完整命令见各 *.command.txt。
