#!/bin/sh
B=/workspace/shared/emomaster-remediation-evidence-20261022
cd /workspace/shared/emomaster-remediate-20261022 || exit
export XDG_CONFIG_HOME="$B/config" XDG_DATA_HOME="$B/data" XDG_CACHE_HOME="$B/cache"
{ date -Is; cat /etc/os-release; echo DISPLAY=$DISPLAY; git rev-parse HEAD; git status --short; /workspace/shared/device-manager-acceptance-20261019/venv/bin/python -c 'import sys,PySide2;from PySide2.QtCore import qVersion;print(sys.version);print(PySide2.__version__,qVersion())'; } > "$B/evidence/environment.log" 2>&1
/workspace/shared/device-manager-acceptance-20261019/venv/bin/python scripts/dev.py run-designer --local > "$B/evidence/designer.log" 2>&1
