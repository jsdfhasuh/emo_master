#!/bin/sh
B=/workspace/shared/emomaster-remediation-evidence-20261022
cd /workspace/shared/emomaster-remediate-20261022 || exit
export PYTHONPATH="$PWD/src" XDG_CONFIG_HOME="$B/config" XDG_DATA_HOME="$B/data" XDG_CACHE_HOME="$B/cache"
{ date -Is; git rev-parse HEAD; git status --short; } > "$B/evidence/final-route/environment.log"
/workspace/shared/device-manager-acceptance-20261019/venv/bin/python -m emo_master.apps.operator_runtime.main "$B/installed-b4" --data-root "$B/operator-data-b4" > "$B/evidence/final-route/operator.log" 2>&1
