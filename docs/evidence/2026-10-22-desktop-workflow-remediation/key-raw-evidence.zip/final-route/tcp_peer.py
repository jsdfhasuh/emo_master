import socket,time,datetime,json
p='/workspace/shared/emomaster-remediation-evidence-20261022/evidence/tcp-peer.jsonl'
def log(**v):
 with open(p,'a') as f:f.write(json.dumps(dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),**v))+'\n')
log(event='started',target='127.0.0.1:18782')
end=time.monotonic()+7200
while time.monotonic()<end:
 try:
  s=socket.create_connection(('127.0.0.1',18782),timeout=1);s.settimeout(2);log(event='connected',local=s.getsockname())
  while time.monotonic()<end:
   try:b=s.recv(65536)
   except socket.timeout:continue
   if not b:break
   log(event='received',hex=b.hex(),text=b.decode('utf-8',errors='replace'),length=len(b))
  s.close();log(event='disconnected')
 except OSError:time.sleep(.3)
