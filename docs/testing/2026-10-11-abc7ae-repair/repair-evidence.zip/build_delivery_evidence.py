"""Package completed evidence only; never copy the unrelated dirty checkout/patch."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

audit = Path(__file__).resolve().parent
repo = Path(r'C:\Users\jsdfhasuh\.codex\worktrees\abc7ae-acceptance-repair\emo_master')
original = Path(r'D:\jsdfhasuh\documents\my_project\emo_master')
delivery = repo / 'docs/testing/2026-10-11-abc7ae-repair'
delivery.mkdir(parents=True, exist_ok=True)


def read(name):
    return json.loads((audit / name).read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args, cwd=repo):
    return subprocess.check_output(['git', *args], cwd=cwd)


def output(name, value):
    (delivery / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def runSummary(name):
    log = (audit / (name + '.log')).read_text(encoding='utf-8-sig')
    tail = next(line for line in reversed(log.splitlines()) if re.search(r'\d+ passed', line))
    suite = ET.parse(audit / (name + '.xml')).getroot().find('testsuite')
    assert suite is not None
    return dict(terminalSummary=tail, junitSuite=dict(suite.attrib),
                skipped=[dict(name=case.get('name'), reason=case.find('skipped').get('message'))
                         for case in suite.findall('testcase') if case.find('skipped') is not None])


windows = read('final-windows-full.json')
linux = read('final-linux.json')
fixed = read('fixed-rounds-results.json')
static = read('final-static-checks.json')
native = read('native-acceptance-results.json')
nativeLoop = read('native-loop-results.json')
assert windows['exit'] == linux['exit'] == 0
assert not windows['sourceChanged'] and not linux['sourceChanged'] and not fixed['sourceChanged']
assert all(row['exit'] == 0 for row in fixed['rounds'])
assert all(row['exit'] == 0 for row in static['checks']) and not static['sourceChanged']
assert native['D06']['status'] == native['ROI']['status'] == 'PASS'
assert native['retirement'] == dict(draftAssets=0, formalJobs=0, operatorResources=False)
assert nativeLoop['status'] == 'PASS' and nativeLoop['pauseSeconds'] >= 80
assert nativeLoop['outputs'] == dict(index=[0, 1, 2], result=[False, True, True])
assert nativeLoop['retirement'] == dict(operatorResources=False, formalJobs=0, projectUnmodified=True)

manifest = read('frozen-source-files.json')
assert digest(audit / 'frozen-source-files.json') == '25eed17019f0ae13abea64c516ae6ad1957bd0e1e1d9b6134b29d9b380b7ade9'
for row in manifest:
    assert digest(audit / 'source' / row['path']) == row['sha256'], row['path']
    assert digest(repo / row['path']) == row['sha256'], row['path']

before = read('workspace-before.json')
changes = [row['path'] for row in before['files'] if digest(original / row['path']) != row['sha256']]
currentNames = set(git('ls-files', '--modified', '--others', '--exclude-standard', '-z', cwd=original).decode().split('\0')) - {''}
initialNames = {row['path'] for row in before['files']}
assert initialNames <= currentNames
assert git('rev-parse', 'HEAD', cwd=original).decode().strip() == before['head']
preservation = dict(path=str(original), observedAt=datetime.now(timezone.utc).isoformat(),
                    originalHead=before['head'], initialDirtyFiles=len(before['files']),
                    finalObservedDirtyFiles=len(currentNames), initialHashUnchangedFiles=len(before['files'])-len(changes),
                    changedInParallelPaths=changes, addedDirtyPaths=sorted(currentNames-initialNames),
                    removedInitialPaths=[], branchMoved=False, originalWorkspaceWrittenByThisRepair=False,
                    note='Earlier checks matched all 31 hashes. Parallel work later changed six paths and added one; preserved current files without rollback. Original patch/content deliberately excluded from delivery evidence.')
output('workspace-preservation.json', preservation)
shutil.copyfile(audit / 'frozen-source-files.json', delivery / 'SOURCE_MANIFEST.json')

names = set(git('diff', '--name-only').decode().splitlines())
names.update(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0'))
names = sorted(name for name in names if name and name.split('/')[0] in {'src', 'tests', 'prototypes'})
output('changed-source-manifest.json', dict(parent=git('rev-parse', 'HEAD').decode().strip(),
    rawCheckoutLineEndings='Windows configured core.autocrlf=true; compare canonical Git blobs across platforms',
    files=[dict(path=name, rawSha256=digest(repo / name),
                canonicalGitBlob=git('hash-object', '--path=' + name, name).decode().strip()) for name in names]))

roundEvidence = []
for index in range(1, 4):
    p0 = read(f'fixed-round-{index}-p0.json')
    assert p0['coverage'] == [1.0, 1.0] and p0['incomplete'] == 0
    assert not any(p0['cleanup']['used'].values()) and p0['cleanup']['owners'] == 0
    roundEvidence.append(dict(round=index, software=runSummary(f'fixed-round-{index}-software'),
        p0=dict(coverage=p0['coverage'], incomplete=p0['incomplete'], clientErrors=p0['client_errors'],
                correctnessStatus=p0['correctness_status'], cleanup=p0['cleanup'],
                measuredOrdinals=[6, 45], imagesPerConsumer=40)))

summary = dict(productBaseline='abc7ae0541e997be0bbe3a4794ad604c239de79a',
    parent='adba329cc11a74034299b9191b7decac6e567fdf', candidate='E',
    sourceFiles=len(manifest), frozenManifestSha256=digest(audit / 'frozen-source-files.json'),
    frozenSourceAndRepairWorktreeMatch=True, windowsFull=dict(**windows, **runSummary('final-windows-full')),
    linuxFocused=dict(**linux, **runSummary('final-linux')),
    nativeQtMatrix=dict(classification='native Windows Qt automation, not manual desktop acceptance',
                       **runSummary('final-native-qt')),
    nativeLongPauseRoi=native, nativeForEachLongPause=nativeLoop,
    fixedRounds=dict(**fixed, evidence=roundEvidence), staticChecks=static,
    resourceBoundaries='Synthetic local fixtures; actual spawn/monitor and loopback; no production devices',
    manualDebian13QtGtk='NOT_RUN', hardwarePackagingReleaseDeployment='NOT_RUN',
    historicalRootCauses=dict(productionNgIncomplete='OPEN_NOT_REPRODUCED', p0Ordinal20='OPEN_NOT_REPRODUCED'),
    previewProtocolLimit='No executionId/resolvedParams/server attestation returned; requestedParams only',
    originalWorkspace=preservation, countsPolicy='Overlapping layers and subtests are not added together')
output('validation-summary.json', summary)

excluded = {'abc7ae-original-evidence.zip', 'original-evidence-inventory.json',
            'workspace-before.json', 'workspace-before.patch'}
allowed = {'.log', '.xml', '.json', '.png', '.zip', '.py'}
paths = [path for path in audit.iterdir() if path.is_file() and path.suffix in allowed and path.name not in excluded]
paths += list((audit / 'fault-injection-baseline').glob('*'))
full = audit / 'original/evidence/automation/full'
paths += [full / name for name in ('pytest.log', 'junit.xml', 'first-failure.json', 'command.txt', 'exit-code.txt', 'summary.json')]
paths += list((full / 'basetemp/testRealWriterContentionIsVisi0').glob('runtime.db*'))
paths += [audit / 'original/evidence/targeted' / name for name in
          ('original-full-failure-db-readonly.json', 'phase-observation/report.json')]
paths = sorted({path for path in paths if path.is_file()})
archivePath = delivery / 'repair-evidence.zip'
entries = []
with zipfile.ZipFile(archivePath, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in paths:
        name = path.relative_to(audit).as_posix()
        archive.write(path, name)
        entries.append(dict(path=name, bytes=path.stat().st_size, sha256=digest(path)))
with zipfile.ZipFile(archivePath) as archive:
    assert archive.testzip() is None
    for row in entries:
        assert hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256']
output('evidence-index.json', dict(archive=archivePath.name, bytes=archivePath.stat().st_size,
    sha256=digest(archivePath), entries=entries,
    exclusionNote='Original 68MB archive remains in baseline split evidence; unrelated dirty patch and complete source copy excluded'))
for name in ('native-roi-editor.png', 'native-roi-full-maskedImage.png',
             'native-d06-paused.png', 'native-d06-resumed.png',
             'native-loop-paused.png', 'native-loop-resumed.png'):
    shutil.copyfile(audit / name, delivery / name)
print(json.dumps(dict(files=len(entries), archiveBytes=archivePath.stat().st_size,
                      sha256=digest(archivePath), checkedFrozenFiles=len(manifest), preservation=preservation)))
