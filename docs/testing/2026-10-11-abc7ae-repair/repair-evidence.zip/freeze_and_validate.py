import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

AUDIT = Path(__file__).resolve().parent
REPO = Path(r"C:\Users\jsdfhasuh\.codex\worktrees\abc7ae-acceptance-repair\emo_master")


def freeze():
    names = subprocess.check_output(["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=REPO)
    rows = []
    for name in sorted(set(names.decode("utf-8").split("\0")) - {""}):
        # Delivery documents are generated after validation, not product input.
        if name.startswith("docs/testing/2026-10-11-abc7ae-repair/"):
            continue
        path = REPO / name
        if not path.is_file():
            continue
        data = path.read_bytes()
        target = AUDIT / "source" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        rows.append(dict(path=name, sha256=hashlib.sha256(data).hexdigest()))
    rendered = json.dumps(rows, ensure_ascii=False, separators=(",", ":")).encode()
    (AUDIT / "frozen-source-files.json").write_bytes(rendered)
    print(json.dumps(dict(files=len(rows), sha256=hashlib.sha256(rendered).hexdigest())))


def run(label, args):
    source = Path(os.environ.get("EMO_VALIDATION_CWD", str(AUDIT / "source"))).resolve()
    env = dict(os.environ, PYTHONPATH=str(source / "src"), PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    env.setdefault("QT_QPA_PLATFORM", "offscreen")
    command = [sys.executable, *args]
    start = time.monotonic()
    with (AUDIT / (label + ".log")).open("w", encoding="utf-8") as stream:
        code = subprocess.call(command, cwd=source, env=env, stdout=stream, stderr=subprocess.STDOUT)
    manifest = json.loads((AUDIT / "frozen-source-files.json").read_text(encoding="utf-8"))
    changed = [row["path"] for row in manifest if hashlib.sha256((source / row["path"]).read_bytes()).hexdigest() != row["sha256"]]
    report = dict(label=label, exit=code, seconds=time.monotonic()-start, command=command, cwd=str(source),
                  python=sys.version, qtBackend=env["QT_QPA_PLATFORM"], sourceChanged=changed)
    (AUDIT / (label + ".json")).write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report), flush=True)
    return code or bool(changed)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode")
    parser.add_argument("args", nargs="*")
    ns = parser.parse_args()
    if ns.mode == "freeze":
        freeze()
    else:
        raise SystemExit(run(ns.mode, ns.args))
