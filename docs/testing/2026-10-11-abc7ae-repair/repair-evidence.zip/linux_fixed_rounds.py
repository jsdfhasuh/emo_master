"""Exactly three independent-process rounds; all outcomes retained, no retry gate."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

audit, source, workspace = Path('/audit'), Path('/source'), Path('/workspace')
manifestBytes = (audit / 'frozen-source-files.json').read_bytes()
rows = json.loads(manifestBytes)
for row in rows:
    content = (source / row['path']).read_bytes()
    assert hashlib.sha256(content).hexdigest() == row['sha256'], row['path']
    target = workspace / row['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
os.chdir(workspace)
temporary = workspace / '.test-temp'
temporary.mkdir()
os.environ.update(PYTHONPATH=os.pathsep.join((str(workspace), str(workspace / 'src'))),
                  PYTHONUTF8='1', PYTHONIOENCODING='utf-8', QT_QPA_PLATFORM='offscreen',
                  TMPDIR=str(temporary))
rounds = []
plan = dict(plannedRounds=3, policy='run each independent process exactly once, keep every outcome; no changes to source/deadlines',
            sourceManifestSha256=hashlib.sha256(manifestBytes).hexdigest())
(audit / 'fixed-rounds-plan.json').write_text(json.dumps(plan, indent=2), encoding='utf-8')
for index in range(1, 4):
    prefix = f'fixed-round-{index}'
    commands = [
        ('software', [sys.executable, '-m', 'pytest', '-q', '--tb=short',
          'tests/sqlite_writer/test_user_path.py::testCompleteSqliteDesignerPath',
          'tests/runtime/test_parallel_workflows.py::testMoreThanTwoActualWhileJobsWithImages',
          'tests/runtime/test_production_boundaries.py::testBusinessNgDoesNotStopAndSharesInvocationWithImageAndCount',
          f'--junitxml=/audit/{prefix}-software.xml']),
        ('p0', [sys.executable, '/audit/p0_capture.py', f'/audit/{prefix}-p0']),
    ]
    for name, command in commands:
        started = time.monotonic()
        with (audit / f'{prefix}-{name}.log').open('w', encoding='utf-8') as stream:
            code = subprocess.call(command, stdout=stream, stderr=subprocess.STDOUT)
        rounds.append(dict(round=index, name=name, command=command, exit=code,
                           seconds=time.monotonic()-started))
        (audit / 'fixed-rounds-results.json').write_text(json.dumps(dict(**plan, rounds=rounds), indent=2), encoding='utf-8')
changed = [row['path'] for row in rows if hashlib.sha256((workspace / row['path']).read_bytes()).hexdigest() != row['sha256']]
result = dict(**plan, rounds=rounds, sourceChanged=changed)
(audit / 'fixed-rounds-results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result), flush=True)
raise SystemExit(bool(changed) or any(row['exit'] for row in rounds))
