import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

audit, source, workspace = Path("/audit"), Path("/source"), Path("/workspace")
rows = json.loads((audit / "frozen-source-files.json").read_text())
for row in rows:
    content = (source / row["path"]).read_bytes()
    assert hashlib.sha256(content).hexdigest() == row["sha256"], row["path"]
    target = workspace / row["path"]
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
os.chdir(workspace)
temporary = workspace / ".test-temp"
temporary.mkdir()
os.environ.update(PYTHONPATH=str(workspace / "src"), PYTHONUTF8="1", PYTHONIOENCODING="utf-8",
                  QT_QPA_PLATFORM="offscreen", TMPDIR=str(temporary))
command = [sys.executable, "-m", "pytest", "-q", "--tb=short",
    "tests/test_r3_sqlite_phases.py", "tests/runtime/test_sqlite_write_admission.py",
    "tests/runtime/test_variable_write_admission.py", "tests/runtime/test_counter_transaction_boundaries.py",
    "tests/runtime/test_global_variables.py", "tests/runtime/test_global_counters.py",
    "tests/runtime/test_global_variable_presentation.py",
    "tests/runtime/test_sqlite_connection_retirement.py", "tests/runtime/test_parallel_workflows.py",
    "tests/runtime/test_worker_heartbeat_finalization.py", "tests/runtime/test_worker_capture_diagnostics.py",
    "tests/runtime/test_production_boundaries.py", "tests/runtime/presentation/test_closure_failures.py",
    "tests/runtime/presentation/test_closure_runtime_integration.py", "tests/runtime/presentation/test_export_diagnostics.py",
    "tests/runtime/presentation/test_images.py", "tests/runtime/presentation/test_multi_capture.py", "tests/p0",
    "tests/designer/test_roi_preview_export.py", "tests/designer/test_draft_pure_preview_ui.py",
    "tests/designer/test_draft_pure_preview_context.py", "tests/designer/test_debug_example_interactions.py",
    "tests/sqlite_writer", "--junitxml=/audit/final-linux.xml"]
started = time.monotonic()
with (audit / "final-linux.log").open("w", encoding="utf-8") as log:
    code = subprocess.call(command, stdout=log, stderr=subprocess.STDOUT)
changed = [row["path"] for row in rows if hashlib.sha256((workspace / row["path"]).read_bytes()).hexdigest() != row["sha256"]]
report = dict(command=command, exit=code, seconds=time.monotonic()-started, python=sys.version,
    os=Path("/etc/os-release").read_text(), sourceChanged=changed, sourceFiles=len(rows),
    storage="writable tmpfs; network isolated; synthetic data only")
(audit / "final-linux.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report), flush=True)
sys.exit(code or bool(changed))
