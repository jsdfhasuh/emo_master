"""Native Windows automation of the shipped D06 ForEach conditional point."""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import tempfile
import time

import emo_master  # noqa: F401
from PySide2.QtCore import Qt
from PySide2.QtTest import QTest
from PySide2.QtWidgets import QApplication, QFileDialog
from shiboken2 import isValid

from emo_master.apps.designer.main import applyDesignerStyle
from emo_master.apps.designer.services.runtime_client import RuntimeClient
from emo_master.apps.designer.ui.workflow_debug_window import WorkflowDebugWindow
from emo_master.apps.runtime.grpc_server.service import RuntimeService
from tests.designer.test_debug_example_interactions import EXAMPLES, step, finish
from tests.designer.test_operator_debug_window import wait

audit = Path(__file__).resolve().parent


def main():
    app = QApplication.instance() or QApplication([])
    applyDesignerStyle(app)
    path = EXAMPLES / '02-foreach.emoproj'
    original = path.read_bytes()
    payload = json.loads(original)
    initial = deepcopy(payload)
    with tempfile.TemporaryDirectory(prefix='emo-native-loop-pause-') as directory:
        root = Path(directory)
        os.environ['EMO_RUNTIME_DATA_DIR'] = str(root / 'runtime-data')
        runtime = RuntimeService(dbPath=root / 'runtime.db')
        dialog = WorkflowDebugWindow(RuntimeClient(runtime), payload, 'main')
        dialog.show()
        try:
            wait(lambda: dialog.startButton.isEnabled())
            QFileDialog.getOpenFileName = lambda *_: (str(EXAMPLES / 'items.json'), '')
            dialog.file('items')
            wait(lambda: dialog.startButton.isEnabled() and dialog.rows['items'].wire() is not None)
            QTest.mouseClick(dialog.startButton, Qt.LeftButton)
            wait(lambda: dialog.current is not None and dialog.buttons['continue'].isEnabled())
            row = next(row for row in dialog.breakpointRows if row[:2] == ('body', 'compare'))
            row[2].setChecked(True)
            row[3].setText('inputs["left"] >= 5')
            QTest.mouseClick(dialog.applyBreakpoints, Qt.LeftButton)
            wait(lambda: dialog.buttons['continue'].isEnabled())
            observations = []
            for value, iteration in ((5, 1), (9, 2)):
                current = step(dialog, 'continue', 'compare', 'body')
                assert current['reason'] == 'breakpoint' and current['inputs']['left'] == value
                assert current['identity']['iterationPath'] == [iteration]
                observations.append(current)
            identity, sequence = deepcopy(dialog.current['identity']), dialog.pauseSequence
            dialog.grab().save(str(audit / 'native-loop-paused.png'))
            started = time.monotonic()
            while time.monotonic() - started < 80:
                app.processEvents()
                time.sleep(.025)
            elapsed = time.monotonic() - started
            assert dialog.current['identity'] == identity and dialog.pauseSequence == sequence
            expected = dict(result=[False, True, True], index=[0, 1, 2])
            finish(dialog, expected)
            dialog.grab().save(str(audit / 'native-loop-resumed.png'))
            result = dict(status='PASS', classification='native Windows Qt automated ForEach conditional point; not manual Debian UI',
                pauseSeconds=elapsed, pauseSequence=sequence, identity=identity,
                conditionalObservations=observations, outputs=dialog.displayed['outputs'],
                projectSha256=hashlib.sha256(original).hexdigest())
        finally:
            dialog.close()
            wait(lambda: not isValid(dialog))
            assert not runtime.operatorDebugManager.ownsResources() and not runtime.jobRepository.all()
            runtime.close()
        assert payload == initial and path.read_bytes() == original
        result['retirement'] = dict(operatorResources=False, formalJobs=0, projectUnmodified=True)
    (audit / 'native-loop-results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=True), flush=True)


if __name__ == '__main__':
    main()
