"""Scripted native Windows Qt interaction; not a manual Debian desktop claim."""
from copy import deepcopy
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import tempfile
import time
import zipfile

import emo_master  # noqa: F401
import cv2
import numpy as np
from PySide2.QtCore import Qt
from PySide2.QtTest import QTest
from PySide2.QtWidgets import QApplication, QFileDialog, QMessageBox
from shiboken2 import isValid

from emo_master.apps.designer.main import applyDesignerStyle
from emo_master.apps.designer.operator_editors import OperatorEditorManager
from emo_master.apps.designer.services.runtime_client import RuntimeClient
from emo_master.apps.designer.ui.workflow_debug_window import WorkflowDebugWindow
from emo_master.apps.runtime.grpc_server.service import RuntimeService
from tests.designer.test_builtin_operator_editor_ui import _Settings
from tests.designer.test_operator_debug_window import wait
from tests.runtime.test_draft_context_preview import project
from tests.runtime.test_workflow_debug_control import nestedProject

AUDIT = Path(__file__).resolve().parent


def main():
    app = QApplication.instance() or QApplication([])
    applyDesignerStyle(app)
    results = dict(classification="native Windows Qt automation; synthetic images; no devices", qtBackend=app.platformName())
    with tempfile.TemporaryDirectory(prefix="emo-native-acceptance-") as temporary, ExitStack() as cleanup:
        root = Path(temporary)
        os.environ["EMO_RUNTIME_DATA_DIR"] = str(root / "runtime-data")
        runtime = RuntimeService(dbPath=root / "runtime.db")
        cleanup.callback(runtime.close)
        dialog = WorkflowDebugWindow(RuntimeClient(runtime), nestedProject(), "main")
        dialog.show()
        try:
            wait(lambda: dialog.startButton.isEnabled())
            QTest.mouseClick(dialog.startButton, Qt.LeftButton)
            wait(lambda: dialog.current is not None and dialog.buttons["continue"].isEnabled())
            identity, sequence = deepcopy(dialog.current["identity"]), dialog.pauseSequence
            dialog.grab().save(str(AUDIT / "native-d06-paused.png"))
            started = time.monotonic()
            while time.monotonic() - started < 80:
                QApplication.processEvents()
                time.sleep(.025)
            elapsed = time.monotonic() - started
            print(json.dumps(dict(stage="paused-80s", elapsed=elapsed, identity=identity, sequence=sequence)), flush=True)
            assert dialog.current["identity"] == identity and dialog.pauseSequence == sequence
            QTest.mouseClick(dialog.buttons["continue"], Qt.LeftButton)
            wait(lambda: dialog.state == "SUCCEEDED" and dialog.displayed is not None
                 and dialog.displayed.get("phase") == "workflow.result")
            assert dialog.displayed["outputs"] == {"value": 7}
            dialog.grab().save(str(AUDIT / "native-d06-resumed.png"))
            results["D06"] = dict(status="PASS", pausedSeconds=elapsed, pauseSequence=sequence, identity=identity, outputs=dialog.displayed["outputs"])
        finally:
            dialog.close()
            wait(lambda: not isValid(dialog))
        assert not runtime.operatorDebugManager.ownsResources() and not runtime.jobRepository.all()
        manifest = json.loads(Path("src/emo_master/plugins/builtins/roi/manifest.json").read_text(encoding="utf-8"))
        payload = project(manifest["operatorId"])
        manager = OperatorEditorManager(runtimeClient=RuntimeClient(runtime), settingsStore=_Settings(),
            applyParams=lambda *_: (_ for _ in ()).throw(AssertionError("Apply was not requested")), appendLog=lambda *_: None,
            getPreviewProject=lambda _: payload, cacheRoot=root / "ui-cache")
        window = manager.open(projectId="draft", workflowId="main", nodeId="node", operatorId=manifest["operatorId"],
            displayName=manifest["displayName"], schema=manifest["paramSchema"], values={},
            operatorDefinition=dict(version=manifest["version"], editorSpec=manifest["editor"]))
        controller = window._controller
        window.resize(1000, 800)
        QFileDialog.getOpenFileName = lambda *_: (str(root / "gradient.png"), "")
        QMessageBox.question = lambda *_args, **_kwargs: QMessageBox.Discard
        try:
            image = np.arange(320 * 240, dtype=np.uint8).reshape(240, 320)
            ok, png = cv2.imencode(".png", image)
            assert ok
            (root / "gradient.png").write_bytes(png.tobytes())
            controller.controls["x"].setValue(32)
            controller.controls["y"].setValue(16)
            controller.controls["width"].setValue(32)
            controller.controls["height"].setValue(24)
            QTest.mouseClick(controller.localImageButton, Qt.LeftButton)
            wait(lambda: controller._previewSnapshot is not None)
            window.grab().save(str(AUDIT / "native-roi-editor.png"))
            snapshot = controller._previewSnapshot
            target = AUDIT / "native-roi-preview.zip"
            QFileDialog.getSaveFileName = lambda *_: (str(target), "")
            QTest.mouseClick(controller.exportArchiveButton, Qt.LeftButton)
            with zipfile.ZipFile(target) as archive:
                exported = json.loads(archive.read("result.json"))
                assert len(exported["images"]) == 4
                for row in exported["images"]:
                    raw = archive.read(row["file"])
                    assert raw == window.context.downloadPreviewAsset(row["assetId"])[0]
                    assert hashlib.sha256(raw).hexdigest() == row["sha256"]
            controller.outputCombo.setCurrentIndex(controller.outputCombo.findData("maskedImage"))
            QTest.mouseClick(controller.viewImageButton, Qt.LeftButton)
            app.processEvents()
            controller._resultViewers[-1].grab().save(str(AUDIT / "native-roi-full-maskedImage.png"))
            results["ROI"] = dict(status="PASS", preview=json.loads(snapshot.metadataJson), outputs=exported["images"],
                                  pixels="all four PNG bytes equal original authorized assets")
        finally:
            manager.closeAll()
            wait(lambda: not controller._retirementThread.is_alive())
        assert not runtime.previewAssetStore._assets
        results["retirement"] = dict(draftAssets=0, formalJobs=len(runtime.jobRepository.all()), operatorResources=runtime.operatorDebugManager.ownsResources())
        runtime.close()
    (AUDIT / "native-acceptance-results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(results, ensure_ascii=True))


if __name__ == "__main__":
    main()
