"""Preserve the same watchdog's complete dual-consumer report for one round."""
from pathlib import Path
import json
import sys
from prototypes.runtime_pages_p0.watchdog import supervised

if __name__ == '__main__':
    target = Path(sys.argv[1])
    stdout, stderr = supervised('continuous', timeout=60)
    target.with_suffix('.stdout.log').write_text(stdout, encoding='utf-8')
    target.with_suffix('.stderr.log').write_text(stderr, encoding='utf-8')
    report = json.loads(stdout.strip().splitlines()[-1])
    target.with_suffix('.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    assert report['coverage'] == [1.0, 1.0]
    assert report['correctness_status'] == 'PASS' and report['incomplete'] == 0
    assert report['client_errors'] == [None, None]
    for client in report['clients']:
        assert [row['ordinal'] for row in client] == list(range(6, 46))
        assert all(row['decoded'] for row in client)
    assert report['stats']['runs'] == 0
    assert not any(report['cleanup']['used'].values()) and report['cleanup']['owners'] == 0
    print(json.dumps(dict(coverage=report['coverage'], incomplete=report['incomplete'],
                         clientErrors=report['client_errors'], cleanup=report['cleanup'])))
