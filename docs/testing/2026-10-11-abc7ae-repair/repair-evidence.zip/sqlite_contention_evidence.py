import json
from pathlib import Path
import tempfile

from pytest import MonkeyPatch
from scripts.r3_sqlite_phases import SqlitePhases
from tests.test_r3_sqlite_phases import testRealWriterContentionIsVisibleAtBeginAndPreservesAllDurableRows

audit = Path(__file__).resolve().parent
snapshots = []
original = SqlitePhases.snapshot
def observe(self):
    result = original(self)
    snapshots.append(result)
    return result

with tempfile.TemporaryDirectory(prefix="emo-contention-evidence-") as directory, MonkeyPatch.context() as patch:
    patch.setattr(SqlitePhases, "snapshot", observe)
    testRealWriterContentionIsVisibleAtBeginAndPreservesAllDurableRows(Path(directory), patch)
    result = dict(status="PASS", classification="isolated real SQLite writer/blocker, automated",
        observed=snapshots, writerConfiguration=dict(synchronous=2, journal_mode="wal", busy_timeout=5000),
        assertions="original 2s / 5ms observation; no successful BEGIN, body or commit before release; exactly one successful BEGIN/body/COMMIT after; durable row sequence=[1]")
    (audit / "sqlite-contention-evidence.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result), flush=True)
