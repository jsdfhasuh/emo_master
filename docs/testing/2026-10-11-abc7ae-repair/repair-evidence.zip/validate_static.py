"""Final frozen candidate static checks, separate from the full pytest run."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

audit = Path(__file__).resolve().parent
source = audit / 'source'
manifest = json.loads((audit / 'frozen-source-files.json').read_text(encoding='utf-8'))
env = dict(os.environ, PYTHONPATH=str(source / 'src'), PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
checks = [
    ('proto', ['scripts/gen_proto.py', '--check']),
    ('ruff', ['-m', 'ruff', 'check', 'src', 'tests']),
    ('prototype-ruff', ['-m', 'ruff', 'check', 'prototypes/runtime_pages_p0/async_exports.py']),
    ('mypy', ['-m', 'mypy', '--config-file', 'mypy.ini', 'src']),
]
report = []
for label, args in checks:
    start = time.monotonic()
    with (audit / ('final-' + label + '.log')).open('w', encoding='utf-8') as stream:
        code = subprocess.call([sys.executable, *args], cwd=source, env=env,
                               stdout=stream, stderr=subprocess.STDOUT)
    report.append(dict(name=label, command=[sys.executable, *args], exit=code,
                       seconds=time.monotonic()-start))
changed = [row['path'] for row in manifest
           if hashlib.sha256((source / row['path']).read_bytes()).hexdigest() != row['sha256']]
result = dict(sourceManifestSha256=hashlib.sha256((audit / 'frozen-source-files.json').read_bytes()).hexdigest(),
              sourceChanged=changed, checks=report)
(audit / 'final-static-checks.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result), flush=True)
raise SystemExit(bool(changed) or any(row['exit'] for row in report))
