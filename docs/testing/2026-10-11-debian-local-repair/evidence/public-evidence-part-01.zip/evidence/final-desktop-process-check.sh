/workspace/shared/emo-master-0120814-acceptance/venv/bin/python - <<'PY'
import os,json,pathlib,datetime
b=pathlib.Path('/workspace/shared/emo-master-0120814-repair-20261011');rows=[]
for pid in [2144,2191,2289,2438,2474,2514,2555,2650,2683,2698,2756,2785]:
 p=pathlib.Path('/proc')/str(pid)
 try: rows.append({'pid':pid,'cmdline':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()})
 except OSError: rows.append({'pid':pid,'absent':True})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pidNamespace':os.readlink('/proc/self/ns/pid'),'rows':rows}
(b/'evidence/ui/final-desktop-process-check-native.json').write_text(json.dumps(result,indent=2));print(result)
PY
