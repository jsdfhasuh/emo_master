#!/bin/bash
set -eu
BASE=/workspace/shared/emo-master-0120814-repair-20261011
cd "$BASE/source-o20-native"
{ date -u; uname -a; cat /etc/os-release; printf 'DISPLAY=%s SESSION=%s DESKTOP=%s\n' "${DISPLAY:-}" "${XDG_SESSION_TYPE:-}" "${XDG_CURRENT_DESKTOP:-}"; ps -eo pid,lstart,args | grep -E 'emo_master|scripts/dev.py' | grep -v grep || true; ss -ltnp; xrandr --current; xfconf-query -c xsettings -p /Gdk/WindowScalingFactor || true; xfconf-query -c xsettings -p /Xft/DPI || true; git rev-parse HEAD; git status --short; } > "$BASE/evidence/ui-o20-native/environment-run2.log" 2>&1
export HOME="$BASE/evidence/ui-o20-native/home" XDG_CONFIG_HOME="$BASE/evidence/ui-o20-native/config" XDG_CACHE_HOME="$BASE/evidence/ui-o20-native/cache"
unset QT_QPA_PLATFORM
export QT_SCALE_FACTOR=1
PY=/workspace/shared/emo-master-0120814-acceptance/venv/bin/python
"$PY" scripts/dev.py run-designer --local --check > "$BASE/evidence/ui-o20-native/check.log" 2>&1
(set +e; "$PY" scripts/dev.py run-designer --local > "$BASE/evidence/ui-o20-native/designer-run2.log" 2>&1; echo $? > "$BASE/evidence/ui-o20-native/designer-run2.exit") &
echo $! > "$BASE/evidence/ui-o20-native/launcher-run2.pid"
echo "Started local repair Designer PID $!"
