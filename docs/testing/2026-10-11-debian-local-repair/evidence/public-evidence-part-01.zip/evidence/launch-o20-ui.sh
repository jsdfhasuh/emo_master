#!/bin/bash
set -eu
BASE=/workspace/shared/emo-master-0120814-repair-20261011
cd "$BASE/source-o20-ui"
export HOME="$BASE/evidence/ui-o20/home" XDG_CONFIG_HOME="$BASE/evidence/ui-o20/config" XDG_CACHE_HOME="$BASE/evidence/ui-o20/cache"
unset QT_QPA_PLATFORM EMO_RUNTIME_TARGET EMO_RUNTIME_DB_PATH EMO_MASTER_RUNTIME_DB_PATH
export QT_SCALE_FACTOR=1 PYTHONPATH="$BASE/source-o20-ui/src" EMO_RUNTIME_DATA_DIR="$BASE/source-o20-ui/manual_test_workspace/runtime-embedded" EMO_UI_TELEMETRY="$BASE/evidence/ui-o20/windows.jsonl"
PY=/workspace/shared/emo-master-0120814-acceptance/venv/bin/python
"$PY" scripts/dev.py run-designer --local --check > "$BASE/evidence/ui-o20/check.log" 2>&1
(set +e; "$PY" "$BASE/evidence/observe-designer-dpr.py" > "$BASE/evidence/ui-o20/designer.log" 2>&1; echo $? > "$BASE/evidence/ui-o20/designer.exit") &
echo $! > "$BASE/evidence/ui-o20/launcher.pid"
