# F03/F04 局部布局维修（自动化证据，非原生桌面验收）

基线：012081423dff794a1e7bf69202b55af8076b90dd。源码在独立 repair 工作区；未提交、推送。

## 已确认原因与修复

- F03 工具栏：Fusion 的 qt_toolbar_ext_button 宽12逻辑像素；通用工具按钮左右padding各7像素再加边框，箭头绘制矩形耗尽。对象isVisible仍真，既有测试漏检。仅对该扩展按钮取消padding/边框，保留Qt原生展开行为及共享QAction。
- F03 菜单：当前主题下中文标题、图标与快捷键的列宽不够，单改左右padding或去padding不能消除重叠。采用7em字体相关的最小标题列宽，保留原快捷键和动作。这是当前菜单布局修正；未宣称已经定位Qt内部尺寸计算的所有原因。实验QProxyStyle进程崩溃，已舍弃，未进入产品代码。
- F04 PLC：基线生产装配在640宽参数控件区viewport49像素但内容77像素，高级区展开viewport=0。参数来源面板占高，加上结果表最低100像素，将原最低24像素的控件区和最低0的高级区挤压。旧12项测试没有生产参数来源面板。
- PLC 改运行页整体滚动；参数来源保留为第三tab；不修改参数值、引用契约、连接/写入/租约逻辑。高级区按实时字体与宽度计高，不产生内层垂直滚动。QScrollArea内容不把结果表192像素首选高度当成100像素最小高度。

## 最终自动化

- caption-scale-1 / 1.25 / 1.5 / 2：最终字幕修正版矩阵，结果以对应log/xml为准；前一轮frozen各44 passed。均QT_QPA_PLATFORM=offscreen，不当作原生缩放体验PASS。
- caption-plc：原PLC专用编辑器113+新9项，合计122 passed，旧430px布局/安全/异步断言未改。
- frozen-ruff：通过；frozen-mypy：两个改动Python源文件检查通过。
- 新增9项：PLC read/write × 640/800生产来源装配，所有连接字段/高级字段/来源字段逐项滚达，原参数和来源不变；4种宽度的扩展按钮像素确有箭头、点击后尾部按钮出现、点击整理流程只触发原QAction一次；菜单标题/快捷键列间隔。
- 不把各缩放重复用例相加作为独立功能数量。

## 文件

- before-toolbar-*.png / after-toolbar-*.png 与对应jsonl：DPR2前后同尺寸箭头。
- plc-before/geometry.json、截图：原提交生产装配复现。
- plc-caption-final/geometry.json、截图：最终结构与完整标题、滚到高级底端；plc-final是修复旧横排标题前的结构。
- menu-final0.png：最终完整菜单；menu-pad/menu-rightpad/menu-nativepadding/menu-min/menu-em：调查实验，不作为最终结果。
- frozen-*.log/xml：最终测试；所有 earlier/first/second/third/pre/final 等发展阶段日志保留，不能用文件名里的final替代frozen轮。
- frozen-source-sha256.json：上一候选冻结摘要；最终统一源码身份由父任务提供，父任务仍在workspace_window.py追加独立Esc生命周期维修。
- probe*.py：隔离取证脚本，仅offscreen/stub context，没有连接真实PLC。

## 边界及保留项

- 原生Xfce桌面由父任务独占复核；本任务未操作桌面。
- 最后补齐640宽横排标签截短：四参数改标题在上/控件在下，新增完整标题字体度量与行高断言；旧430px保持通过。
- 尚未执行真实PLC、相机、外部写入；本布局测试用stub上下文。
- 开发中保留失败：首次外层滚动使结果表首选高造成旧布局失败，已改；高级区字体变更需重算；DPR测试先处理Show后的fitWindow再主动resize，避免把离屏800×600屏幕自动缩窗误记为请求窗口尺寸；QSignalSpy在PySide2不可用的测试导入错误已修正。原产品安全断言、超时没有放宽。
