import json
from PySide2.QtWidgets import QApplication
from PySide2.QtCore import QPoint
from emo_master.apps.designer.main import applyDesignerStyle
from tests.designer.test_visual_layout import makeWindow
app=QApplication([]);applyDesignerStyle(app);qss=app.styleSheet()
w=makeWindow();w.show();m=w._workspaceMenus['编辑']
for pad in [26,40,60,80]:
 app.setStyleSheet(qss.replace('padding: 7px 26px','padding: 7px 26px 7px '+str(pad)+'px'))
 m.popup(QPoint(50,50))
 for _ in range(10):app.processEvents()
 print(json.dumps({'pad':pad,'size':[m.width(),m.height()],'actions':[[a.text(),a.shortcut().toString(),m.actionGeometry(a).width(),m.fontMetrics().horizontalAdvance(a.text()),m.fontMetrics().horizontalAdvance(a.shortcut().toString())] for a in m.actions()]},ensure_ascii=False))
 m.grab().save('/workspace/shared/emo-master-0120814-repair-20261011/evidence/layout/menu-pad'+str(pad)+'.png');m.hide()
w.close()
