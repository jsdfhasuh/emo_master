import json
from PySide2.QtWidgets import QApplication
from PySide2.QtCore import QPoint
from emo_master.apps.designer.main import applyDesignerStyle
from tests.designer.test_visual_layout import makeWindow
app=QApplication([]);applyDesignerStyle(app);qss=app.styleSheet()
w=makeWindow();w.show();m=w._workspaceMenus['编辑']
for pad in [0]:
 app.setStyleSheet(qss.replace('QMenu::item { padding: 7px 26px; border-radius: 4px; }','QMenu::item { border-radius: 4px; }'))
 m.popup(QPoint(50,50))
 for _ in range(10):app.processEvents()
 print(json.dumps({'pad':pad,'size':[m.width(),m.height()],'actions':[[a.text(),a.shortcut().toString(),m.actionGeometry(a).width(),m.fontMetrics().horizontalAdvance(a.text()),m.fontMetrics().horizontalAdvance(a.shortcut().toString())] for a in m.actions()]},ensure_ascii=False))
 m.grab().save('/workspace/shared/emo-master-0120814-repair-20261011/evidence/layout/menu-nativepadding'+str(pad)+'.png');m.hide()
w.close()
