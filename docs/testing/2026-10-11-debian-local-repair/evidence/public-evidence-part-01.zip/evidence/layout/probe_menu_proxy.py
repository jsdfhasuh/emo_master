import json
from PySide2.QtWidgets import QApplication, QProxyStyle, QStyle, QStyleFactory
from PySide2.QtCore import QPoint
from emo_master.apps.designer.main import applyDesignerStyle
from tests.designer.test_visual_layout import makeWindow
class MenuStyle(QProxyStyle):
 def sizeFromContents(self,t,opt,sz,w=None):
  s=super().sizeFromContents(t,opt,sz,w)
  if t == QStyle.CT_MenuItem:
   s.setWidth(s.width()+opt.maxIconWidth+16)
  return s
app=QApplication([]);applyDesignerStyle(app);app.setStyle(MenuStyle(QStyleFactory.create('Fusion')));qss=app.styleSheet()
w=makeWindow();w.show();m=w._workspaceMenus['编辑']
for pad in [0]:
 app.setStyleSheet(qss)
 m.popup(QPoint(50,50))
 for _ in range(10):app.processEvents()
 print(json.dumps({'pad':pad,'size':[m.width(),m.height()],'actions':[[a.text(),a.shortcut().toString(),m.actionGeometry(a).width(),m.fontMetrics().horizontalAdvance(a.text()),m.fontMetrics().horizontalAdvance(a.shortcut().toString())] for a in m.actions()]},ensure_ascii=False))
 m.grab().save('/workspace/shared/emo-master-0120814-repair-20261011/evidence/layout/menu-proxy'+str(pad)+'.png');m.hide()
w.close()
