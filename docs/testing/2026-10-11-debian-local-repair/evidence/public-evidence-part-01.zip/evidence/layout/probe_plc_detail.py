"""Evidence-only offscreen production assembly, stub context; no PLC connection."""
import json,sys
from pathlib import Path
from PySide2.QtWidgets import QApplication
from PySide2.QtCore import QPoint
from emo_master.apps.designer.main import applyDesignerStyle
from tests.designer.test_plc_editor import _Context,_manifest,_ROOT,loadUiBytes,PlcEditorController,OperatorWorkspaceWindow
app=QApplication([]);applyDesignerStyle(app)
c=_Context();c.variableDefinitions=lambda:{};c.variableBindings=[]
m=_manifest('plc_slmp_read');root=loadUiBytes((_ROOT/'plc_slmp_read'/m['editor']['uiResource']).read_bytes())
x=PlcEditorController();w=OperatorWorkspaceWindow(key=c.key,title='PLC SLMP读取',context=c,schema=c.paramSchema,values={},customRoot=root,controller=x)
w.bindDebug(lambda *args:None);w.openController();w.show();x.tabs.setCurrentWidget(x.runtimePage)
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
rows=[]
for width,height in [(640,474),(800,478),(980,720)]:
 for advanced in [False,True]:
  x.advancedButton.setChecked(advanced);w.resize(width,height)
  if hasattr(x,'runtimeScroll'):x.runtimeScroll.verticalScrollBar().setValue(0)
  for _ in range(10):app.processEvents()
  data={'requested':[width,height],'actual':[w.width(),w.height()],'dpr':w.devicePixelRatioF(),'advanced':advanced,'fields':{},'scrollers':{},'sourcePanelHeight':w._bindingScroll.height()}
  for field in [x.hostEdit,x.deviceCombo,x.addressSpin,x.dataTypeCombo,x.countSpin,*x._endpointControls.values()]:
   p=field.mapTo(w,QPoint());data['fields'][field.objectName()]={'rect':[p.x(),p.y(),field.width(),field.height()],'visibleRegionEmpty':field.visibleRegion().isEmpty()}
  for name in ['controlsScroll','advancedScroll','runtimeScroll']:
   a=getattr(x,name,None)
   if a:data['scrollers'][name]={'viewport':[a.viewport().width(),a.viewport().height()],'range':a.verticalScrollBar().maximum(),'hRange':a.horizontalScrollBar().maximum(),'selfHint':[a.minimumSizeHint().width(),a.minimumSizeHint().height()],'child':[a.widget().width(),a.widget().height()],'childMin':[a.widget().minimumSizeHint().width(),a.widget().minimumSizeHint().height()],'childHFW':a.widget().heightForWidth(a.viewport().width())}
  w.grab().save(str(out/f'plc-{width}-{height}-advanced{int(advanced)}.png'))
  rows.append(data)
(out/'geometry.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
x.dispose();x._executor.shutdown(wait=True);w._forceClosing=True;w.close()
