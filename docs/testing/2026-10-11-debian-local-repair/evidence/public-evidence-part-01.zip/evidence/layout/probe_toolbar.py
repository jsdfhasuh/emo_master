import json
from PySide2.QtCore import Qt
from PySide2.QtWidgets import QApplication,QToolButton
from emo_master.apps.designer.main import applyDesignerStyle
from tests.designer.test_visual_layout import makeWindow
app=QApplication([]);applyDesignerStyle(app)
w=makeWindow();w.show()
for width in (480,589,658,800,1280):
 w.resize(width,500)
 for _ in range(10):app.processEvents()
 t=w.mainToolbar
 print(json.dumps({'width':w.width(),'toolbar':[t.x(),t.y(),t.width(),t.height()],'dpr':w.devicePixelRatioF(),'buttons':[[b.objectName(),b.text(),b.isVisible(),b.x(),b.y(),b.width(),b.height()] for b in t.findChildren(QToolButton)]},ensure_ascii=False))
 w.grab().save('/workspace/shared/emo-master-0120814-repair-20261011/evidence/layout/before-toolbar-'+str(width)+'.png')
w.close()
