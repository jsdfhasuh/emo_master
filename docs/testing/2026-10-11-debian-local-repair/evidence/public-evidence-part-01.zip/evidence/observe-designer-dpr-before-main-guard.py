"""Read-only Qt window telemetry wrapper. No click, state change, or RPC injection."""
import os, sys, json, datetime
from pathlib import Path
from PySide2 import QtWidgets, QtCore
OriginalApplication=QtWidgets.QApplication
class ObservedApplication(OriginalApplication):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.telemetryTimer=QtCore.QTimer(self)
        self.telemetryTimer.timeout.connect(self.recordWindows)
        self.telemetryTimer.start(1000)
    def recordWindows(self):
        rows=[]
        for w in self.topLevelWidgets():
            if w.isVisible():
                rows.append({"class":type(w).__name__,"title":w.windowTitle(),"size":[w.width(),w.height()],"dpr":w.devicePixelRatioF(),"screen":w.screen().name() if w.screen() else None})
        with open(os.environ["EMO_UI_TELEMETRY"],"a") as f:
            f.write(json.dumps({"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"pid":os.getpid(),"windows":rows},ensure_ascii=False)+"\n")
QtWidgets.QApplication=ObservedApplication
from emo_master.apps.designer.main import runDesigner
runDesigner()
