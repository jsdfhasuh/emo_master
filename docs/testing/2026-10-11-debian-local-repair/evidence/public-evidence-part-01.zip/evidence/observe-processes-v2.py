"""Read-only desktop process lifecycle observer; no RPC or process signals."""
import os, json, time, pathlib, datetime
BASE=pathlib.Path('/workspace/shared/emo-master-0120814-repair-20261011')
OUT=BASE/'evidence/ui'
last=None
(OUT/'observer-v2-identity.json').write_text(json.dumps({'pid':os.getpid(),'pidNamespace':os.readlink('/proc/self/ns/pid'),'netNamespace':os.readlink('/proc/self/ns/net'),'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
while not (OUT/'stop-observer-v2').exists():
 rows=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit() or int(p.name)==os.getpid():continue
  try:
   cwd=os.readlink(p/'cwd');args=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   if str(BASE/'source') not in cwd and str(BASE/'source') not in args and str(BASE).encode() not in (p/'environ').read_bytes():continue
   status=(p/'status').read_text();fields=dict(l.split(':',1) for l in status.splitlines() if ':' in l)
   rows.append({'pid':int(p.name),'ppid':int(fields['PPid'].strip()),'args':args,'cwd':cwd,'exe':os.readlink(p/'exe'),'threads':int(fields['Threads'].strip()),'state':fields['State'].strip()})
  except (OSError,KeyError):continue
 stable=sorted(rows,key=lambda r:r['pid'])
 if stable!=last:
  with (OUT/'process-v2-timeline.jsonl').open('a') as f:f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonic':time.monotonic(),'processes':stable})+'\n')
  last=stable
 time.sleep(.2)  # observational sampling interval; never changes product waits
