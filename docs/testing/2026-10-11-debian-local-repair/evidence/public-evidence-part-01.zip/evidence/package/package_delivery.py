#!/usr/bin/env python3
"""Read-only delivery packaging. No source edits, uploads, commits or deletion.

candidate: build selected source ZIP parts and inventory/size the evidence.
final: build both source and evidence parts after the parent freezes outputs.
Each run uses a new directory. ZIP parts are independently extractable; extract
all same-kind parts into one fresh directory. No binary multipart slicing.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import zipfile
import zlib

BASE = Path('/workspace/shared/emo-master-0120814-repair-20261011')
NEW_TESTS = [
 'tests/designer/test_debug_dialog_retirement.py',
 'tests/designer/test_debug_main_window_boundaries.py',
 'tests/designer/test_parameter_editor_retirement.py',
 'tests/designer/test_small_window_layout_repair.py',
]
LIMIT = 19_000_000
CACHE_NAMES = {'__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache',
               'mypy-linux-cache', 'mypy-win32-cache', 'ruff-cache', 'fontconfig'}
IMPORTANT_SUFFIXES = {'.json', '.jsonl', '.log', '.txt', '.xml', '.db', '.sqlite',
                      '.sqlite3', '.emoproj', '.py', '.sql', '.csv', '.yaml', '.yml',
                      '.ini', '.conf', '.md', '.sha256'}


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def files(root):
    for directory, dirs, names in os.walk(root, followlinks=False):
        dirs.sort()
        for name in list(dirs):
            p = Path(directory) / name
            if p.is_symlink():
                dirs.remove(name)
                yield p
        for name in sorted(names):
            yield Path(directory) / name


REQUIRED_HISTORICAL_FIXTURES = {'docs/evidence/p4/c-accepted-visible/screens/two-pages.json'}


def compact_reason(name):
    if name in REQUIRED_HISTORICAL_FIXTURES:
        return None
    if name.startswith('docs/evidence/'):
        return 'compact_omits_historical_evidence_not_product_source'
    if name.startswith('docs/testing/') and Path(name).suffix.lower() not in {'.md', '.html', '.py'}:
        return 'compact_omits_historical_testing_logs_images_archives_results'
    return None


def evidence_reason(relative):
    parts = relative.parts
    if relative == Path('report/emo-master-0120814-debian-repair-report-final.zip'):
        return 'duplicate_report_archive_original_docx_pdf_and_qa_included'
    # Never recursively archive the delivery archives/manifests themselves.
    if parts[0] == 'package' and not (len(parts) == 2 and relative.suffix == '.py'):
        return 'generated_delivery_output_not_recursive'
    if any(p in CACHE_NAMES for p in parts):
        return 'regenerable_python_typecheck_lint_font_cache'
    if 'pytest-tmp' in parts:
        # O20 independent rounds are retained in full, including business/runtime
        # databases, project inputs and result artifacts, even inside pytest-tmp.
        if len(parts) > 1 and parts[0] == 'regression' and parts[1] in {'o20', 'final-o20'}:
            return None
        # Retain diagnostics, database state and projects from ALL full-suite
        # attempts (including first failures), not just the final green run.
        name = relative.name.lower()
        if relative.suffix.lower() in IMPORTANT_SUFFIXES or name.endswith(('-wal', '-shm', '.json.bak')):
            return None
        return 'regenerable_pytest_fixture_binary_or_input_archive'
    return None


def describe(path, arcname, kind, *, hash_content=True):
    info = path.lstat()
    result = {'path': arcname, 'kind': kind, 'size_bytes': info.st_size,
              'mtime_ns': info.st_mtime_ns, 'mode': stat.S_IMODE(info.st_mode)}
    if path.is_symlink():
        result['link_target'] = os.readlink(path)
        result['size_bytes'] = len(result['link_target'].encode('utf-8'))
    if hash_content:
        sha = hashlib.sha256()
        compressor = zlib.compressobj(6, zlib.DEFLATED, -15)
        total = 0
        if path.is_symlink():
            blocks = [result['link_target'].encode('utf-8')]
            for block in blocks:
                sha.update(block); total += len(compressor.compress(block))
        else:
            with path.open('rb') as stream:
                while block := stream.read(1024 * 1024):
                    sha.update(block); total += len(compressor.compress(block))
        total += len(compressor.flush())
        after = path.lstat()
        if (after.st_size, after.st_mtime_ns) != (info.st_size, info.st_mtime_ns):
            raise RuntimeError(f'Input changed during inventory: {path}')
        result.update(sha256=sha.hexdigest(), deflated_bytes=total)
    return result


def partition(records):
    groups = [[]]
    size = 22  # ZIP end-of-central-directory record
    for record in records:
        # ZIP local + central headers and two UTF-8 filename copies. 128 bytes
        # conservatively cover any timestamp/ZIP64 extras; final size verified.
        cost = record['deflated_bytes'] + 128 + 2 * len(record['path'].encode('utf-8'))
        if cost + 22 >= LIMIT:
            raise RuntimeError(f'One compressed file exceeds part limit: {record["path"]}')
        if groups[-1] and size + cost >= LIMIT:
            groups.append([]); size = 22
        groups[-1].append(record)
        size += cost
    return [g for g in groups if g]


def build_parts(base, records, out, name):
    result = []
    for number, group in enumerate(partition(records), 1):
        target = out / f'{name}-part-{number:02}.zip'
        with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for record in group:
                path = base / record['path']
                if record['kind'] == 'symlink':
                    zi = zipfile.ZipInfo(record['path'])
                    zi.create_system = 3
                    zi.external_attr = (stat.S_IFLNK | 0o777) << 16
                    archive.writestr(zi, record['link_target'], compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
                else:
                    now = path.stat()
                    if (now.st_size, now.st_mtime_ns) != (record['size_bytes'], record['mtime_ns']):
                        raise RuntimeError(f'Input changed after inventory: {path}; retain this attempt and rerun frozen inputs')
                    archive.write(path, record['path'])
        if target.stat().st_size >= LIMIT:
            raise RuntimeError(f'Part unexpectedly exceeds {LIMIT}: {target}')
        with zipfile.ZipFile(target) as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f'CRC failed: {target}')
            for record in group:
                actual = hashlib.sha256(archive.read(record['path'])).hexdigest()
                if actual != record['sha256']:
                    raise RuntimeError(f'Archived bytes mismatch: {record["path"]}')
                record['zip_part'] = target.name
        result.append({'file': target.name, 'bytes': target.stat().st_size,
                       'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                       'file_count': len(group), 'crc_and_content_sha256_verified': True})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['analyze', 'candidate', 'final'], default='analyze')
    parser.add_argument('--source-kind', choices=['compact', 'full'], default='compact')
    parser.add_argument('--source-only', action='store_true', help='Skip evidence inventory/build for a source candidate')
    args = parser.parse_args()
    base = BASE
    package = base / 'evidence/package'
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    out = package / f'{args.mode}-{args.source_kind}-{stamp}'
    out.mkdir(parents=True, exist_ok=False)
    source = base / 'source'
    git = lambda *a: subprocess.check_output(['git', '-C', str(source), *a])
    tracked = [p.decode('utf-8') for p in git('ls-files', '-z').split(b'\0') if p]
    wanted = set(tracked + NEW_TESTS)
    included = {'source': [], 'evidence': []}
    excluded = []
    identity = {'mode': args.mode, 'source_kind': args.source_kind, 'source_only': args.source_only,
                'created_utc': stamp, 'base': str(base),
                'head': git('rev-parse', 'HEAD').decode().strip(),
                'status_porcelain': git('status', '--porcelain=v1').decode(),
                'tracked_count': len(tracked), 'additional_new_tests': NEW_TESTS,
                'part_limit_bytes': LIMIT, 'no_upload_or_source_modification': True,
                'required_historical_fixture_exceptions': sorted(REQUIRED_HISTORICAL_FIXTURES)}
    dump(out / 'identity.json', identity)
    for name in sorted(wanted):
        path = source / name
        if not path.exists() and not path.is_symlink():
            raise RuntimeError(f'Missing required source file: {path}')
        reason = compact_reason(name) if args.source_kind == 'compact' else None
        record = describe(path, 'source/' + name, 'symlink' if path.is_symlink() else 'file', hash_content=not reason)
        if reason:
            record['reason'] = reason
            excluded.append(record)
        else:
            included['source'].append(record)
    # Record every observed excluded generated/untracked source file except .git
    # internals (recorded as one explicitly excluded repository-metadata directory).
    for directory, dirs, names in os.walk(source, followlinks=False):
        if '.git' in dirs:
            dirs.remove('.git')
            excluded.append({'path': 'source/.git/', 'reason': 'repository_metadata_directory_not_deliverable'})
        for name in sorted(names):
            path = Path(directory) / name
            relative = path.relative_to(source).as_posix()
            if relative not in wanted:
                record = describe(path, 'source/' + relative, 'symlink' if path.is_symlink() else 'file', hash_content=False)
                record['reason'] = 'untracked_generated_source_workspace_file'
                excluded.append(record)
    for path in ([] if args.source_only else files(base / 'evidence')):
        relative = path.relative_to(base / 'evidence')
        if out in path.parents:
            continue  # Current manifest/output cannot inventory itself recursively.
        kind = 'symlink' if path.is_symlink() else 'file'
        reason = evidence_reason(relative)
        if kind == 'symlink':
            reason = 'evidence_symlink_not_followed_original_target_retained_if_selected'
        record = describe(path, 'evidence/' + relative.as_posix(), kind, hash_content=not reason)
        if reason:
            record['reason'] = reason
            excluded.append(record)
        else:
            included['evidence'].append(record)
    summary = {'included': {key: {'files': len(records),
                        'raw_bytes': sum(r['size_bytes'] for r in records),
                        'deflated_file_bytes': sum(r['deflated_bytes'] for r in records),
                        'estimated_zip_parts': len(partition(records))}
                        for key, records in included.items()},
               'excluded_file_count': len(excluded),
               'excluded_bytes': sum(r.get('size_bytes', 0) for r in excluded),
               'exclusions_by_reason': dict(Counter(r['reason'] for r in excluded)),
               'scope_note': 'Current run output omitted from recursive inventory; all originals left untouched.',
               'evidence_inventory_skipped': args.source_only,
               'source_categories': {}, 'archives': []}
    for record in included['source']:
        parts = Path(record['path']).parts
        category = parts[1] if len(parts) > 2 else '(root files)'
        values = summary['source_categories'].setdefault(category, {'files': 0, 'raw_bytes': 0, 'deflated_file_bytes': 0})
        values['files'] += 1
        values['raw_bytes'] += record['size_bytes']
        values['deflated_file_bytes'] += record['deflated_bytes']
    if args.mode in {'candidate', 'final'}:
        summary['archives'] += build_parts(base, included['source'], out, 'emo-master-' + args.source_kind + '-source')
    if args.mode == 'final' and not args.source_only:
        summary['archives'] += build_parts(base, included['evidence'], out, 'emo-master-repair-evidence')
    for key, records in included.items():
        dump(out / f'{key}-included-files.json', records)
    dump(out / 'excluded-files.json', excluded)
    dump(out / 'compact-historical-exclusions.json', [r for r in excluded if r['reason'].startswith('compact_')])
    dump(out / 'summary.json', summary)
    lines = [f'{item["sha256"]}  {item["file"]}' for item in summary['archives']]
    for name in ['identity.json', 'source-included-files.json', 'evidence-included-files.json', 'excluded-files.json', 'compact-historical-exclusions.json', 'summary.json']:
        lines.append(f'{hashlib.sha256((out/name).read_bytes()).hexdigest()}  {name}')
    (out / 'SHA256SUMS.txt').write_text('\n'.join(lines) + '\n')
    (out / 'README.txt').write_text('''EmoMaster 局部维修交付包\n\n所有分卷均为独立完整ZIP，不是二进制切片。将同类所有part解压到同一新的目录即可还原；文件路径不重叠。\n源码范围见identity.source_kind：full为完整git ls-files加4新测试；compact保留全部产品、测试、脚本、proto、examples、配置、根文件、文档正文，排除docs历史验收日志/图片/归档，不能称完整仓库复制。compact保留被现有UI测试依赖的two-pages.json例外夹具。无.git、依赖环境或生成缓存。\n证据保留所有阶段外层日志、JUnit、退出码、身份、截图、工程、素材、导出、取证脚本和报告；O20各轮pytest-tmp原始数据库与工程全部保留。其他pytest-tmp保留数据库/sidecar、JSON/日志和工程，排除可再生二进制测试夹具与大归档。完整逐文件排除原因见excluded-files.json。\n字体缓存、mypy/ruff/pytest/Python缓存、旧打包输出排除，不删除原文件。证据符号链接不跟随，以免重复或越出工作区；原始目标按规则正常收录。\n每项实际内容SHA256及ZIP归属见included-files清单；每个ZIP均实际检查小于19,000,000字节、CRC和逐文件SHA256。\n模式candidate只生成候选源码，证据只分析。模式final才生成最终源码及证据ZIP。候选包不是最终交付、不能用于最终验收身份。\n''', encoding='utf-8')
    with (out / 'SHA256SUMS.txt').open('a', encoding='utf-8') as hashes:
        hashes.write(hashlib.sha256((out / 'README.txt').read_bytes()).hexdigest() + '  README.txt\n')
    # Keep the index self-contained without a recursive checksum: its internal
    # SHA list covers data ZIPs/manifests; the external SHA list also covers the
    # index ZIP itself. The input source/evidence content is unchanged.
    if args.mode == 'final' and not args.source_only:
        index = out / 'emo-master-delivery-index.zip'
        names = ['README.txt', 'identity.json', 'source-included-files.json',
                 'evidence-included-files.json', 'excluded-files.json',
                 'compact-historical-exclusions.json', 'summary.json', 'SHA256SUMS.txt']
        with zipfile.ZipFile(index, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for name in names:
                archive.write(out / name, name)
            delivery_readme = base / 'evidence/DELIVERY_README.txt'
            if delivery_readme.exists():
                archive.write(delivery_readme, 'DELIVERY_README.txt')
        if index.stat().st_size >= LIMIT:
            raise RuntimeError('Delivery index ZIP exceeds size limit')
        with zipfile.ZipFile(index) as archive:
            assert archive.testzip() is None
            for name in names:
                assert archive.read(name) == (out / name).read_bytes()
        digest = hashlib.sha256(index.read_bytes()).hexdigest()
        with (out / 'SHA256SUMS.txt').open('a', encoding='utf-8') as hashes:
            hashes.write(digest + '  ' + index.name + '\n')
        summary['index_archive'] = {'file': index.name, 'bytes': index.stat().st_size,
                                    'sha256': digest, 'crc_and_content_verified': True,
                                    'checksum_note': 'External SHA256SUMS additionally covers this index ZIP.'}
    print(json.dumps({'output': str(out), **summary}, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
