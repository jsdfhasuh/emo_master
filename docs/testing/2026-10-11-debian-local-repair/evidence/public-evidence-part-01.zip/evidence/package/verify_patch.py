"""Apply the delivered patch in a new minimal baseline tree; compare every byte."""
from datetime import datetime, timezone
import hashlib,json,subprocess
from pathlib import Path
BASE=Path('/workspace/shared/emo-master-0120814-repair-20261011')
source=BASE/'source';patch=BASE/'evidence/emo-master-0120814-local-repair.patch'
old=BASE/'evidence/repair-final-candidate.patch'
assert patch.read_bytes()==old.read_bytes(), 'candidate and final patch differ'
head=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD']).decode().strip()
assert head=='012081423dff794a1e7bf69202b55af8076b90dd'
tracked={p.decode() for p in subprocess.check_output(['git','-C',str(source),'ls-files','-z']).split(b'\0') if p}
stat=subprocess.check_output(['git','apply','--numstat',str(patch)]).decode()
paths=[line.split('\t',2)[2] for line in stat.splitlines()]
out=BASE/'evidence/patch-verification'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
out.mkdir(parents=True,exist_ok=False);tree=out/'reconstructed';tree.mkdir()
for name in paths:
    target=tree/name;target.parent.mkdir(parents=True,exist_ok=True)
    if name in tracked:
        target.write_bytes(subprocess.check_output(['git','-C',str(source),'show',head+':'+name]))
commands=[]
for args in [['git','apply','--check',str(patch)],['git','apply',str(patch)]]:
    p=subprocess.run(args,cwd=tree,capture_output=True,text=True)
    commands.append({'argv':args,'cwd':str(tree),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    if p.returncode:
        (out/'commands.json').write_text(json.dumps(commands,indent=2))
        raise RuntimeError('Patch application failed')
records=[]
for name in paths:
    expected=(source/name).read_bytes();actual=(tree/name).read_bytes()
    assert actual==expected,name
    records.append({'path':name,'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest(),'exact_final_source_match':True})
result={'base_sha':head,'patch_bytes':patch.stat().st_size,'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),
        'candidate_patch_byte_identical':True,'changed_files':len(paths),'commands':commands,'files':records,
        'scope':'Only changed paths reconstructed from exact Git baseline, patch applied and compared byte-for-byte; no product run or original workspace edit.'}
(out/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'output':str(out),'patch_sha256':result['patch_sha256'],'changed_files':len(paths),'all_exact':True},indent=2))
