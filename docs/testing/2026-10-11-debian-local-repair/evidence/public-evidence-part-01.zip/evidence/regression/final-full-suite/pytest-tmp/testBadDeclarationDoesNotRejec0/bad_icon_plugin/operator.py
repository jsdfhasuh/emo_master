class TempOperator:
    class Meta:
        operatorId = 'vision.demo.temp'
        displayName = 'Temp'
        version = '0.1.0'
        inputPorts = {}
        outputPorts = {}
        paramSchema = {'type': 'object'}
    meta = Meta()
    def validateParams(self, params):
        return None
    def executeNode(self, inputs, params, runtimeContext):
        return {'status': 'ok', 'outputs': {}}
