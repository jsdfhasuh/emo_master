from pathlib import Path
import datetime, hashlib, importlib, importlib.metadata, json, os, platform, shlex, subprocess, sys, time
BASE = Path('/workspace/shared/emo-master-0120814-repair-20261011')
ROOT = BASE / 'source'
OUT = BASE / 'evidence/regression'
name = sys.argv[1]
run = OUT / name
run.mkdir(parents=True, exist_ok=False)
env = dict(os.environ)
env.update(QT_QPA_PLATFORM='offscreen', PYTHONPATH=str(ROOT/'src')+':'+str(ROOT), PYTHONDONTWRITEBYTECODE='1', EMO_RUNTIME_DATA_DIR=str(run/'runtime-data'), XDG_CONFIG_HOME=str(run/'config'), XDG_CACHE_HOME=str(run/'cache'))
env.update(HOME=str(run/'home'),XDG_RUNTIME_DIR=str(run/'xdg-runtime'),XDG_DATA_HOME=str(run/'data'))
for key in ['HOME','XDG_RUNTIME_DIR','XDG_DATA_HOME']: Path(env[key]).mkdir(mode=0o700,parents=True,exist_ok=True)
env.pop('EMO_RUNTIME_DB_PATH', None)
env.pop('HUARAY_CAMERA_SMOKE', None)
if name in {'original-lease', 'final-lease-v3', 'stress-thousand-fifty'}: env['EMO_DEBUG_STRESS'] = '1'
else: env.pop('EMO_DEBUG_STRESS', None)
command = [sys.executable, '-m', 'pytest', '-p', 'no:cacheprovider', '-vv', '-ra', '--junitxml='+str(run/'junit.xml'), '--basetemp='+str(run/'pytest-tmp')] + sys.argv[2:]
def git(*args): return subprocess.check_output(['git',*args], cwd=ROOT, text=True).strip()
paths = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'], cwd=ROOT).split(b'\x00')
manifest = {os.fsdecode(path): hashlib.sha256((ROOT/os.fsdecode(path)).read_bytes()).hexdigest() for path in paths if path and (ROOT/os.fsdecode(path)).is_file()}
(run/'tracked-sha256.before.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
identity = {'head':git('rev-parse','HEAD'),'statusBefore':git('status','--porcelain=v1'),'branch':git('branch','--show-current'),'executable':sys.executable,'python':sys.version,'platform':platform.platform(),'command':command,'shellCommand':shlex.join(command),'environment':{key:env.get(key) for key in ['QT_QPA_PLATFORM','PYTHONPATH','PYTHONDONTWRITEBYTECODE','EMO_RUNTIME_DATA_DIR','EMO_RUNTIME_DB_PATH','EMO_DEBUG_STRESS','HUARAY_CAMERA_SMOKE','XDG_CONFIG_HOME','XDG_CACHE_HOME']},'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
probe = 'import sys, json, emo_master, PySide2, grpc, google.protobuf, numpy, cv2, pytest; print(json.dumps({"sysPath":sys.path,"emoMaster":emo_master.__file__,"designer":__import__("emo_master.apps.designer.services.runtime_client",fromlist=["RuntimeClient"]).__file__,"runtime":__import__("emo_master.apps.runtime.grpc_server.service",fromlist=["RuntimeService"]).__file__,"PySide2":PySide2.__version__,"grpc":grpc.__version__,"protobuf":google.protobuf.__version__,"numpy":numpy.__version__,"cv2":cv2.__version__,"pytest":pytest.__version__},ensure_ascii=False,indent=2))'
probe_run = subprocess.run([sys.executable,'-c',probe],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(run/'imports.log').write_text(probe_run.stdout)
identity['importProbeExitCode']=probe_run.returncode
(run/'identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2))
if probe_run.returncode: print(probe_run.stdout,flush=True); raise SystemExit(probe_run.returncode)
started=time.monotonic()
with (run/'pytest.log').open('w') as log:
    log.write('$ '+shlex.join(command)+'\n'); log.flush()
    result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
identity.update(exitCode=result.returncode,elapsedSeconds=time.monotonic()-started,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),statusAfter=git('status','--porcelain=v1'))
after={path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in manifest if (ROOT/path).is_file()}
identity['trackedFilesUnchanged'] = after == manifest
(run/'identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2))
(run/'exit-code.txt').write_text(str(result.returncode)+'\n')
print(json.dumps(identity,ensure_ascii=False,indent=2),flush=True)
print('\n'.join((run/'pytest.log').read_text().splitlines()[-45:]),flush=True)
raise SystemExit(result.returncode)
