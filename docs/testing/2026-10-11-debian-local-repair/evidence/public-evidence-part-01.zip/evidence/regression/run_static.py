from pathlib import Path
import datetime,hashlib,importlib.metadata,json,os,shlex,subprocess,sys,time,xml.etree.ElementTree as ET
BASE=Path('/workspace/shared/emo-master-0120814-repair-20261011'); ROOT=BASE/'source'; OUT=BASE/'evidence/regression'/(sys.argv[1] if len(sys.argv)>1 else 'static')
OUT.mkdir(exist_ok=False)
env=dict(os.environ)
env.update(QT_QPA_PLATFORM='offscreen',PYTHONPATH=str(ROOT/'src')+':'+str(ROOT),PYTHONDONTWRITEBYTECODE='1',RUFF_CACHE_DIR=str(OUT/'ruff-cache'),MYPY_CACHE_DIR=str(OUT/'mypy-cache'))
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
paths=[os.fsdecode(p) for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT).split(b'\x00') if p]
def hashes():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths if (ROOT/p).is_file()}
before=hashes(); (OUT/'tracked-sha256.before.json').write_text(json.dumps(before,indent=2))
identity={'head':git('rev-parse','HEAD'),'statusBefore':git('status','--porcelain=v1'),'python':sys.version,'executable':sys.executable,'environment':{k:env[k] for k in ['QT_QPA_PLATFORM','PYTHONPATH','PYTHONDONTWRITEBYTECODE','RUFF_CACHE_DIR','MYPY_CACHE_DIR']},'versions':{},'runs':[]}
for package in ['ruff','mypy','grpcio-tools','protobuf']:
    try:identity['versions'][package]=importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:identity['versions'][package]='NOT_INSTALLED'
steps=[('proto',[sys.executable,'scripts/gen_proto.py','--check']),('ruff',[sys.executable,'-m','ruff','check','src','tests']),('mypy-linux',[sys.executable,'-m','mypy','--config-file','mypy.ini','--cache-dir',str(OUT/'mypy-linux-cache'),'src']),('mypy-win32-static',[sys.executable,'-m','mypy','--config-file','mypy.ini','--platform','win32','--cache-dir',str(OUT/'mypy-win32-cache'),'src'])]
suite=ET.Element('testsuite',name='0120814-static',tests=str(len(steps)))
for name,command in steps:
    start=time.monotonic()
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT/(name+'.log')).open('w') as log:
        log.write('$ '+shlex.join(command)+'\n');log.flush()
        completed=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    row={'name':name,'command':command,'shellCommand':shlex.join(command),'startedUtc':stamp,'exitCode':completed.returncode,'elapsedSeconds':time.monotonic()-start}
    identity['runs'].append(row)
    (OUT/(name+'.exit-code.txt')).write_text(str(completed.returncode)+'\n')
    case=ET.SubElement(suite,'testcase',name=name,classname='static',time=str(row['elapsedSeconds']))
    output=(OUT/(name+'.log')).read_text()
    ET.SubElement(case,'system-out').text=output
    if completed.returncode:ET.SubElement(case,'failure',message=f'exit {completed.returncode}').text=output
    (OUT/'identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2))
    print(json.dumps(row,ensure_ascii=False),flush=True)
    print(output[-4000:],flush=True)
identity.update(statusAfter=git('status','--porcelain=v1'),trackedFilesUnchanged=before==hashes())
suite.set('failures',str(sum(row['exitCode']!=0 for row in identity['runs'])))
ET.ElementTree(suite).write(OUT/'junit.xml',encoding='utf-8',xml_declaration=True)
(OUT/'identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2))
raise SystemExit(int(any(row['exitCode']!=0 for row in identity['runs'])))
