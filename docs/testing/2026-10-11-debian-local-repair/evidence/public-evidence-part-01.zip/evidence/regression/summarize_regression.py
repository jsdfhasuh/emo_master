from pathlib import Path
import json,sqlite3,hashlib,xml.etree.ElementTree as ET
BASE=Path(__file__).resolve().parent
rows=[]
for name in ['full-suite','final-full-suite','final-full-suite-v2','final-full-suite-v3','sqlite-safety','stress-thousand-fifty','original-lease']:
 p=BASE/name
 if not (p/'exit-code.txt').exists():continue
 identity=json.loads((p/'identity.json').read_text()); xml=ET.parse(p/'junit.xml').getroot()
 suites=list(xml) if xml.tag=='testsuites' else [xml]
 rows.append({'name':name,'exitCode':identity['exitCode'],'sourceUnchanged':identity['trackedFilesUnchanged'],'elapsedSeconds':identity['elapsedSeconds'],'junitSuites':[s.attrib for s in suites], 'skips':[{'test':t.attrib,'reason':s.attrib,'text':s.text} for t in xml.iter('testcase') for s in t.findall('skipped')],'errors':[{'test':t.attrib,'error':s.attrib,'text':s.text} for t in xml.iter('testcase') for s in t.findall('error')]})
checks=[]
for p in sorted((BASE/'final-o20').glob('round-*')):
 r=json.loads((p/'verification.json').read_text());dbs=[]
 for d in r['databases']:
  db=Path(d['path']); c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True)
  dbs.append({'path':str(db),'integrity':c.execute('pragma integrity_check').fetchall(),'sha256':hashlib.sha256(db.read_bytes()).hexdigest(),'valuesCorrect':d['values_correct']});c.close()
 checks.append({'round':p.name,'exitCode':r['exitcode'],'committed':r['committed'],'distinctJobs':r['distinct_job_ids'],'distinctRuns':r['distinct_workflow_run_ids'],'dbs':dbs})
summary={'automatedOnly':True,'notNativeDesktopEvidence':True,'overlappingTestCountsMustNotBeSummed':True,'v1ErrorsRetained':True,'runs':rows,'finalO20':checks}
(BASE/'software-regression-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print([(r['name'],r['exitCode']) for r in rows]);print('O20',len(checks))
