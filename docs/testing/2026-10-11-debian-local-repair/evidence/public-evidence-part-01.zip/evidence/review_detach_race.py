import os, tempfile, threading, time
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ['EMO_RUNTIME_DATA_DIR']=tempfile.mkdtemp()
import emo_master
from PySide2.QtWidgets import QApplication
from emo_master.apps.runtime.grpc_server.service import RuntimeService
from emo_master.apps.designer.ui.operator_debug_window import OperatorDebugWindow
from emo_master.apps.designer.services.runtime_client import RuntimeClientError
from tests.designer.test_operator_debug_window import editorFor, wait
from pathlib import Path

def main():
    app=QApplication([])
    root=Path(tempfile.mkdtemp())
    runtime=RuntimeService(dbPath=root/'runtime.db', workspaceRoot=root/'jobs')
    editor,*_=editorFor(runtime)
    dialog=OperatorDebugWindow(editor); editor._debugWindow=dialog; dialog.show()
    connection=dialog.connection
    entered, release, failed = threading.Event(),threading.Event(),threading.Event()
    attempts=[]; original=connection.close
    def close():
        attempts.append(1)
        if len(attempts)==1:
            entered.set(); release.wait(5); failed.set()
            raise RuntimeClientError('E_RESOURCE_CLEANUP_FAILED','Injected transport failure before close RPC')
        return original()
    connection.close=close
    try:
        wait(dialog.run.isEnabled)
        dialog.close(); wait(entered.is_set)
        editor.forceClose(); release.set(); wait(failed.is_set)
        time.sleep(.2); QApplication.processEvents()
        print('RESULT',{'attempts':len(attempts),'disposed':dialog.disposed,'resourcesHeld':runtime.operatorDebugManager.ownsResources(),'leaseStopped':connection.stop.is_set()},flush=True)
    finally:
        release.set(); original(); runtime.close()
if __name__=='__main__': main()
