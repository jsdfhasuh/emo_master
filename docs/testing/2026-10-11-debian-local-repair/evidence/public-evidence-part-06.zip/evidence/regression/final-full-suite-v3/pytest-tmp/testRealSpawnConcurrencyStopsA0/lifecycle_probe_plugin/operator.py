from pathlib import Path
from threading import Event

class LifecycleProbeOperator:
    class Meta:
        inputPorts = {'mode': 'string'}
        outputPorts = {'result': 'json'}
    meta = Meta()

    def validateParams(self, params):
        return None

    def executeNode(self, inputs, params, runtimeContext):
        job_id = runtimeContext['jobId']
        marker_dir = Path(params['markerDir'])
        release_dir = Path(params['releaseDir'])
        marker_dir.mkdir(parents=True, exist_ok=True)
        release_dir.mkdir(parents=True, exist_ok=True)
        (marker_dir / f'{job_id}.started').touch()
        release = release_dir / f'{job_id}.release'
        while not release.exists():
            Event().wait(0.01)
        return {
            'status': 'ok',
            'outputs': {'result': {'jobId': job_id, 'mode': inputs['mode']}},
        }
