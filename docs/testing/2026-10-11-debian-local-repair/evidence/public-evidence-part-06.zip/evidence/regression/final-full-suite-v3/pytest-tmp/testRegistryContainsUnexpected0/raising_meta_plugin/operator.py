class TempOperator:
    class Meta:
        @property
        def inputPorts(self):
            raise RuntimeError('broken metadata')
        outputPorts = {}
    meta = Meta()
    def validateParams(self, params):
        return None
    def executeNode(self, inputs, params, runtimeContext):
        return {'status': 'ok', 'outputs': {}}
