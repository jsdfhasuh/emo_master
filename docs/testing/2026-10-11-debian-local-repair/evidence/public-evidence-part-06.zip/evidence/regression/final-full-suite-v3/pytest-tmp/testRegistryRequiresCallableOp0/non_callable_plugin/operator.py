class TempOperator:
    class Meta:
        inputPorts = {}
        outputPorts = {}
    meta = Meta()
    validateParams = None
    def executeNode(self, inputs, params, runtimeContext):
        return {'status': 'ok', 'outputs': {}}
