from pathlib import Path
from threading import Event

class ProbeOperator:
    class Meta:
        inputPorts = {'value': 'string'}
        outputPorts = {'result': 'json'}
    meta = Meta()

    def validateParams(self, params):
        return None

    def executeNode(self, inputs, params, runtimeContext):
        Path(params['startedPath']).touch()
        releasePath = Path(params['releasePath'])
        while not releasePath.exists():
            Event().wait(0.01)
        outputPath = Path(params['outputPath'])
        outputPath.parent.mkdir(parents=True, exist_ok=True)
        outputPath.write_text(str(inputs['value']), encoding='utf-8')
        return {
            'status': 'ok',
            'outputs': {'result': {'path': str(outputPath)}},
            'metrics': {'probeCalls': 1},
            'diagnostics': {'probe': 'ok'},
        }
