class CrashOperator:
  class Meta:
    inputPorts = {'mode': 'string'}
    outputPorts = {'result': 'json'}
  meta = Meta()
  def validateParams(self, params):
    return None
  def executeNode(self, inputs, params, runtimeContext):
    if inputs.get('mode') == 'crash':
      raise RuntimeError('intentional worker crash')
    return {'status': 'ok', 'outputs': {'result': {'mode': inputs.get('mode')}}, 'metrics': {}, 'diagnostics': {}}
