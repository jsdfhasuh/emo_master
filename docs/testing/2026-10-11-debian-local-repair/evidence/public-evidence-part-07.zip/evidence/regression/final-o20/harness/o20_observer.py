"""Read-only test-process identity observer; no fixture/assertion/timing changes."""
import json, os, platform, subprocess, sys
from pathlib import Path

def pytest_sessionstart(session):
    import emo_master
    from PySide2 import __version__ as pyside_version
    from PySide2.QtCore import qVersion
    from emo_master.apps.runtime.grpc_server import service
    from emo_master.apps.designer.services import runtime_client
    source=Path(os.environ['O20_SOURCE']).resolve()
    modules={name: str(Path(module.__file__).resolve()) for name, module in [('emo_master',emo_master),('runtime_service',service),('designer_runtime_client',runtime_client)]}
    assert all(path.startswith(str(source/'src')+'/') for path in modules.values()), modules
    data={'pid':os.getpid(),'ppid':os.getppid(),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'qt':qVersion(),'pyside':pyside_version,'modules':modules,'sys_path':sys.path,'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'git_status':subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True),'environment':{k:os.environ.get(k) for k in ['HOME','TMPDIR','XDG_RUNTIME_DIR','XDG_CACHE_HOME','XDG_CONFIG_HOME','XDG_DATA_HOME','EMO_RUNTIME_DATA_DIR','EMO_SQLITE_SCREEN_DIR','QT_QPA_PLATFORM','DISPLAY','PYTHONPATH']}}
    Path(os.environ['O20_EVIDENCE'],'identity.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))

def pytest_sessionfinish(session,exitstatus):
    root=Path(os.environ['O20_EVIDENCE'])
    (root/'pytest-session-end.json').write_text(json.dumps({'pid':os.getpid(),'pytest_exitstatus':int(exitstatus),'collected':session.testscollected,'failed':session.testsfailed},indent=2))
