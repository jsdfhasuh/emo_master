class EchoOperator:
    class Meta:
        inputPorts = {'value': 'string'}
        outputPorts = {'result': 'string'}
    meta = Meta()

    def validateParams(self, params):
        return None

    def executeNode(self, inputs, params, runtimeContext):
        return {'status': 'ok', 'outputs': {'result': inputs['value']}}
