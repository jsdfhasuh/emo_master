"""Absolute difference builtin operator."""
