"""Affine transform builtin operator."""
