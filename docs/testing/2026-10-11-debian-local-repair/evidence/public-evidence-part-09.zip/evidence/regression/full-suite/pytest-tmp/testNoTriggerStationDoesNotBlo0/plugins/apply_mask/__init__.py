"""Apply mask builtin operator."""
