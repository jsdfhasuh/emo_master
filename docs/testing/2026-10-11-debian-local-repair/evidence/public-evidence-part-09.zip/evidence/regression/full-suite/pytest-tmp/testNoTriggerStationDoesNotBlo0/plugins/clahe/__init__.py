"""CLAHE builtin operator."""
