"""Color-space conversion builtin."""
