"""Contour extraction builtin operator."""
