"""Histogram equalization builtin operator."""
