"""Flip builtin operator."""
