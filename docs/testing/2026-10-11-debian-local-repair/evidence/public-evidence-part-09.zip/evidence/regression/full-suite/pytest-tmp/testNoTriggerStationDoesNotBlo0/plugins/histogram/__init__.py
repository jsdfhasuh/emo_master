"""Histogram builtin operator."""
