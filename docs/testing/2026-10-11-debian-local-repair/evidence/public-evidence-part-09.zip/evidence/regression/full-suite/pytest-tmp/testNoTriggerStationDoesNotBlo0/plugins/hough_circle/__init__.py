"""Hough circle builtin operator."""
