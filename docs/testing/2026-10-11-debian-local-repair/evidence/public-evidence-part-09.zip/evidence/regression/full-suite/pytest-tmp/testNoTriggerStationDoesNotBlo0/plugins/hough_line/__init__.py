"""Hough line builtin operator."""
