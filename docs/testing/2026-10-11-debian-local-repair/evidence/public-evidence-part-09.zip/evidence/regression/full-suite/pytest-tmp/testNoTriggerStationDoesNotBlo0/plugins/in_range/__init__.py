"""Color-range segmentation builtin."""
