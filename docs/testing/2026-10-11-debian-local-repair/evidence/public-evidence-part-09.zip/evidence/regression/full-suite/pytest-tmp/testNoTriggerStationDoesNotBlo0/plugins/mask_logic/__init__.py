"""Binary mask logic builtin."""
