"""Binary morphology builtin."""
