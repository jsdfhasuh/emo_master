"""Perspective transform builtin operator."""
