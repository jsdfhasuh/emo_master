"""Mitsubishi SLMP read builtin."""
