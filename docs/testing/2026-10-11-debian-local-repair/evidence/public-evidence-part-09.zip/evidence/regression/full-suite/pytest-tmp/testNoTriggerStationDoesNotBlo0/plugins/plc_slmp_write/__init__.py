"""Mitsubishi SLMP write builtin."""
