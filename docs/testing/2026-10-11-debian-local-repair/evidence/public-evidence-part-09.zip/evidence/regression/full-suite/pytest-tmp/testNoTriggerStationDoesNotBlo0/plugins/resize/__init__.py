"""Resize and letterbox builtin."""
