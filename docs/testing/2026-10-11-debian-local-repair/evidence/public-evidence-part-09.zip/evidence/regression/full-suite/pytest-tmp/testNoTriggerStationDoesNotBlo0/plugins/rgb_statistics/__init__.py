"""RGB region-statistics builtin."""
