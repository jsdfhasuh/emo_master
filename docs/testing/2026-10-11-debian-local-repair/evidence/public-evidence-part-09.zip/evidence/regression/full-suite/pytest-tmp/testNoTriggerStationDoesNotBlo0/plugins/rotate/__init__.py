"""Rotate builtin operator."""
