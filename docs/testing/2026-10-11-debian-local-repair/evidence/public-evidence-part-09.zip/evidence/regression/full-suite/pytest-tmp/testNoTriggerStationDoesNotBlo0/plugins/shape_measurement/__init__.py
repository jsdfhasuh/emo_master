"""Shape measurement builtin operator."""
