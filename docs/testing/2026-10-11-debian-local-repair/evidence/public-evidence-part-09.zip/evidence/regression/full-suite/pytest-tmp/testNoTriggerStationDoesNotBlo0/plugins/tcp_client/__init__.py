"""Bounded TCP client builtin."""
