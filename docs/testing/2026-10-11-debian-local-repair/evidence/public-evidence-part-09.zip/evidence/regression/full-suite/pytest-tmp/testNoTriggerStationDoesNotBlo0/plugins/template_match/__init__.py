"""Template matching builtin operator."""
