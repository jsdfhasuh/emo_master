"""Image thresholding builtin."""
