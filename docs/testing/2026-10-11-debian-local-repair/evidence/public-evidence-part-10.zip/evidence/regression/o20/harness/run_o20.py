import os,json,subprocess,time,sqlite3,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
BASE=Path('/workspace/shared/emo-master-0120814-repair-20261011/evidence/regression/o20')
SOURCE=Path('/workspace/shared/emo-master-0120814-repair-20261011/source')
PYTHON='/workspace/shared/emo-master-0120814-acceptance/venv/bin/python'

def run(name,tests,screens=False):
    out=BASE/name
    out.mkdir(exist_ok=False)
    for part in ['home','tmp','xdg-runtime','cache','config','data','runtime-data','screens']:
        (out/part).mkdir(mode=0o700)
    env=dict(os.environ)
    for key in ['DISPLAY','WAYLAND_DISPLAY','EMO_RUNTIME_DB_PATH','PYTEST_ADDOPTS','PYTEST_PLUGINS','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH','QT_QPA_FONTDIR']:
        env.pop(key,None)
    env.update(HOME=str(out/'home'),TMPDIR=str(out/'tmp'),TEMP=str(out/'tmp'),TMP=str(out/'tmp'),XDG_RUNTIME_DIR=str(out/'xdg-runtime'),XDG_CACHE_HOME=str(out/'cache'),XDG_CONFIG_HOME=str(out/'config'),XDG_DATA_HOME=str(out/'data'),EMO_RUNTIME_DATA_DIR=str(out/'runtime-data'),QT_QPA_PLATFORM='offscreen',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join([str(SOURCE/'src'),str(SOURCE),str(BASE/'harness')]),O20_SOURCE=str(SOURCE),O20_EVIDENCE=str(out))
    if screens: env['EMO_SQLITE_SCREEN_DIR']=str(out/'screens')
    else: env.pop('EMO_SQLITE_SCREEN_DIR',None)
    command=[PYTHON,'-m','pytest','-p','o20_observer','-p','no:cacheprovider','-vv','--tb=long','--junitxml='+str(out/'junit.xml'),'--basetemp='+str(out/'pytest-tmp'),*tests]
    (out/'command.json').write_text(json.dumps(command,indent=2))
    start=datetime.now(timezone.utc).isoformat(); t=time.monotonic()
    with (out/'pytest.log').open('w') as log:
        process=subprocess.Popen(command,cwd=SOURCE,env=env,stdout=log,stderr=subprocess.STDOUT)
        code=process.wait()
    result={'round':name,'pid':process.pid,'started_utc':start,'elapsed_seconds':time.monotonic()-t,'exitcode':code,'tests':tests}
    (out/'exitcode.txt').write_text(str(code)+'\n')
    if screens:
        ui=out/'screens'/'ui-results.json'
        result['ui_results_present']=ui.exists()
        if ui.exists():
            report=json.loads(ui.read_text()); result['qpa']=report['platform']; result['receipts']=report['jobs']; result['reported_rows']=report['rows']
            result['committed']=len(report['jobs'])==2 and all(r['status']=='COMMITTED' for r in report['jobs'])
            ids=[r['execution']['jobId'] for r in report['jobs']]; runs=[r['execution']['workflowRunId'] for r in report['jobs']]
            result['distinct_job_ids']=len(set(ids))==2;result['distinct_workflow_run_ids']=len(set(runs))==2
            result['screenshots_hashes_match']=all(hashlib.sha256((out/'screens'/file).read_bytes()).hexdigest()==sha for file,sha in report['artifacts'].items())
        dbs=list((out/'pytest-tmp').glob('**/业务 数据.sqlite3'))
        result['databases']=[]
        for db in dbs:
            connection=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True)
            try: rows=connection.execute('SELECT id,write_id,"数量" FROM "检测记录" ORDER BY id').fetchall()
            finally: connection.close()
            result['databases'].append({'path':str(db),'rows':rows,'values_correct':[r[2] for r in rows]==[7,13]})
    (out/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k not in ['receipts','reported_rows','databases']},ensure_ascii=False),flush=True)
    return result

if __name__=='__main__':
    results=[]
    for number in range(1,11):
        results.append(run('round-%02d'%number,['tests/sqlite_writer/test_user_path.py'],screens=True))
    (BASE/'ten-round-summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    sys.exit(0 if all(r['exitcode']==0 and r.get('committed') and r.get('distinct_job_ids') and r.get('distinct_workflow_run_ids') and r.get('screenshots_hashes_match') and all(d['values_correct'] for d in r['databases']) for r in results) else 1)
