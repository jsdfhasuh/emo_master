"""External diagnostic: retain the original business assertions and teardown."""
import json
import threading
import time
from pathlib import Path
import pytest
import emo_master
from PySide2.QtCore import QCoreApplication, QEvent
from shiboken2 import isValid
from tests.qt_widget_owner import OwnedDesignerWindows
from tests.runtime.test_operator_debug_rpc import runtime as runtime
from tests.designer import test_debug_example_interactions as examples
from emo_master.apps.designer.ui.operator_debug_window import OperatorDebugWindow

pytest_plugins = ['tests.conftest', 'tests.designer.conftest']
OUT = Path(__file__).with_name('probe.jsonl')
# Retain the pre-adaptation fixture, while keeping its original examples path.
namespace = {'__name__': 'original_example_probe', '__file__': examples.__file__}
reference = Path(__file__).with_name('test_debug_example_interactions.before.py')
exec(compile(reference.read_text(), str(reference), 'exec'), namespace)
runOriginal = namespace['testStandaloneNodeUsesOnlyExplicitInputs']

@pytest.mark.parametrize('gate_ack', [False, True])
@pytest.mark.parametrize('filename,workflow,node', [
    ('01-nested-calls.emoproj','child','number'),
    ('03-image.emoproj','process','threshold'),
])
def testProbe(runtime, retainedQtApplication, monkeypatch, filename, workflow, node, gate_ack):
    owner = OwnedDesignerWindows(retainedQtApplication)
    release = threading.Event()
    originals = OperatorDebugWindow.__init__
    records, calls = [], []
    def initialize(self, *args, **kwargs):
        originals(self, *args, **kwargs)
        original_close = self.connection.close
        def close():
            calls.append('close')
            result = original_close()
            if gate_ack:
                assert release.wait(15), 'Diagnostic ACK release missing'
            return result
        self.connection.close = close
        records.append((self, self.editor))
    monkeypatch.setattr(OperatorDebugWindow, '__init__', initialize)
    def snapshot(label, window, close_return=None):
        debug, editor = records[0]
        provider = window.operatorIconProvider
        return dict(case=node, gate_ack=gate_ack, label=label,
            resourcesHeld=runtime.operatorDebugManager.ownsResources(),
            debugValid=isValid(debug), debugDisposed=debug.disposed,
            editorValid=isValid(editor), editorWaiting=editor._waitingForDebug,
            editorDisposed=editor._disposed, mainCloseReturn=close_return,
            runtimeClosed=window.runtimeController._closed,
            iconRunning=bool(provider and provider.worker and provider.worker.isRunning()),
            catalogRunning=bool(window.operatorCatalogWorker and window.operatorCatalogWorker.isRunning()),
            closeCalls=len(calls))
    trace=[]
    try:
        # Calls the unchanged shipped test, including its original exampleWindow finally.
        runOriginal(runtime, owner, monkeypatch, filename, workflow, node)
        window = owner._owned[0][0]
        trace.append(snapshot('original_fixture_finished',window))
        closed=window.close()
        trace.append(snapshot('first_main_close',window,closed))
        release.set()
        deadline=time.monotonic()+15
        debug, editor=records[0]
        while time.monotonic()<deadline:
            QCoreApplication.processEvents()
            QCoreApplication.sendPostedEvents(None,QEvent.DeferredDelete)
            if window.runtimeController._closed and not isValid(debug) and not isValid(editor):
                break
        trace.append(snapshot('natural_qt_delivery_finished',window))
        assert not runtime.operatorDebugManager.ownsResources()
        assert window.runtimeController._closed and not isValid(debug) and not isValid(editor)
        assert len(calls)==1, 'No close RPC should be retried by the diagnostic'
        owner.retire()
    finally:
        release.set()
        with OUT.open('a') as stream:
            for row in trace: stream.write(json.dumps(row)+'\n')
