from pathlib import Path
import json, re, hashlib, shutil
from datetime import datetime, timezone
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
O=Path(__file__).resolve().parent; E=O.parent; ROOT=E.parent
D=json.loads((O/'evidence-index.json').read_text()); C=json.loads((O/'report-control.json').read_text())
FIN=C['finalized']; stage='final' if FIN else 'stage'
X={x['path']:x for x in D['xmlRuns']}
DOC=Document(); sec=DOC.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=sec.bottom_margin=Inches(.66);sec.left_margin=sec.right_margin=Inches(.68)
sec.footer_distance=Inches(.25)
for name,size in [('Normal',10.5),('Title',23),('Subtitle',12),('Heading 1',16),('Heading 2',12),('Heading 3',11),('Caption',9)]:
 st=DOC.styles[name];st.font.name='Noto Sans CJK SC';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0);st.font.italic=False
 st.element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
 st.paragraph_format.space_after=Pt(6);st.paragraph_format.line_spacing=1.12
 if name.startswith('Heading'):st.paragraph_format.keep_with_next=True;st.paragraph_format.space_before=Pt(10)
DOC.styles['Normal'].paragraph_format.widow_control=True
# Remove inherited Word template title rules.
for st in DOC.styles:
 for el in list(st.element.xpath('.//w:pBdr')): el.getparent().remove(el)
DOC.core_properties.title=C['title'];DOC.core_properties.subject='0120814 基线局部补丁及 Debian 分层复验';DOC.core_properties.author='EmoMaster 修复复验记录'
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=footer.add_run('0120814 局部修复复验  |  ');r.font.size=Pt(8)
f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');footer._p.append(f)
def p(t='',bold=False,size=None):
 z=DOC.add_paragraph();r=z.add_run(t);r.bold=bold
 if size:r.font.size=Pt(size)
 return z
def h(t,level=1,new=False):
 z=DOC.add_paragraph(t,'Heading '+str(level));z.paragraph_format.page_break_before=new;return z
def tab(headers,rows,widths,size=9.5):
 t=DOC.add_table(rows=1,cols=len(headers));t.autofit=False;t.alignment=WD_TABLE_ALIGNMENT.CENTER
 for col,w in zip(t.columns,widths):col.width=Inches(w)
 bd=OxmlElement('w:tblBorders')
 for e in ['top','left','bottom','right','insideH','insideV']:
  x=OxmlElement('w:'+e);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');bd.append(x)
 t._tbl.tblPr.append(bd)
 for c,s in zip(t.rows[0].cells,headers):c.text=str(s)
 rp=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(rp)
 for vals in rows:
  for c,v in zip(t.add_row().cells,vals):c.text=str(v)
 for ri,row in enumerate(t.rows):
  row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
  for ci,cell in enumerate(row.cells):
   cell.width=Inches(widths[ci]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   pr=cell._tc.get_or_add_tcPr();mg=OxmlElement('w:tcMar')
   for side in ['top','left','bottom','right']:
    x=OxmlElement('w:'+side);x.set(qn('w:w'),'80' if side in ['top','bottom'] else '90');x.set(qn('w:type'),'dxa');mg.append(x)
   pr.append(mg);sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'DDE7EF' if ri==0 else 'F6F7F9' if ri%2==0 else 'FFFFFF');pr.append(sh)
   for par in cell.paragraphs:
    par.paragraph_format.space_after=Pt(2);par.paragraph_format.line_spacing=1.05
    if widths[ci]<.9:par.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for r in par.runs:r.font.size=Pt(size);r.font.color.rgb=RGBColor(0,0,0);r.bold=(ri==0)
 p('',size=2)
 return t
def ev(t):p('证据  '+t,size=8.5)
def image(rel,caption,width=6.7):
 f=E/rel
 if f.exists():
  z=DOC.add_paragraph();z.paragraph_format.keep_with_next=True;z.alignment=WD_ALIGN_PARAGRAPH.CENTER
  r=z.add_run();shape=r.add_picture(str(f),width=Inches(width));shape._inline.docPr.set('descr',caption)
  DOC.add_paragraph(caption,'Caption')
def summary(rel):
 x=X.get(rel);return x['terminalSummary'].strip('= ') if x and x['terminalSummary'] else '等待完整终态'
def run_summary(name):return summary('regression/'+name+'/junit.xml')
# Page 1
DOC.add_paragraph(C['title'],'Title')
DOC.add_paragraph('0120814 基线局部补丁及分层验证','Subtitle')
p(C['reportDate'],True);p('基线 '+D['baseline'],size=9)
p('证据索引截点 '+D['generatedUtc']+'；本轮补丁未提交、未推送。',size=9)
h('1 结论与复验范围')
p(C['overallConclusion'],True)
rows=[['F05','调试窗口退出生命周期','统一 done、reject、accept 进入安全关闭；窗口等待真实退休。'],['F03','工具栏与菜单布局','恢复扩展箭头绘制，保留原生 QAction；菜单标题列按字体宽度预留。'],['F04','PLC 小窗生产装配','参数来源独立 tab；运行页整体滚动；四参数标题置于控件上方。'],['R01','参数编辑器完成路径','Esc 等完成路径遵守 dirty 提示和 manager 注销，取消或丢弃结果分明。'],['边界','父窗与主窗关闭','等待所有调试资源退休；失败保持可见，只允许明确重试；活动调试阻止项目替换。']]
tab(['编号','修复对象','当前实现'],rows,[.65,1.8,4.69])
p('本报告只覆盖本轮 Debian 局部修复和列明复验。旧 O01 至 O20、U01 至 U13、D01 至 D08 全部验收结果没有迁入本轮；未重测的旧范围保持原结论。')
h('判定口径',2)
p('自动化、真实桌面、静态检查、开发阶段失败分别记账。PASS 只证明指定版本及列明范围；SKIP 和 NOT_RUN 不等同通过。专项与全量存在重叠，不加总；DPR 重复矩阵也不计为新增独立功能。')
p('候选全量 4765 passed、19 skipped、29 subtests passed 保留为过程证据。该轮执行中源码继续变化，不能认证最终补丁。',True)
# Page2
h('2 调试窗口退出修复',new=True)
h('F05 根因与局部改动',2)
p('QDialog 的 Esc、reject、accept 和 done 可绕过 closeEvent。旧路径删除窗口后，调试 connection 的续租与 Worker/session 仍可能保留，下一次打开调试会遭遇资源占用。两个调试窗口的完成入口现统一转入已有异步安全关闭，待确认资源退休后才允许对象销毁。')
p('单算子窗口增加 closeSent，避免关闭中重复提交同一关闭请求；失败时重置可重试状态并发出 cleanupFailed。detach 仅在尚未发送关闭时补发一次，保持原 pinned connection 的所有者关系。')
tab(['场景','断言或观察','证据层'],[
 ['六种完成入口','Esc、reject、accept、done、窗口 X、结束按钮；两类调试窗口。对象删除前续租停止，manager 不再持有资源，CloseOperatorDebugSession 恰好一次。','QTest 与真实 Runtime'],
 ['慢速打开中重复关闭','打开未结束时连续 Esc、reject、close，窗口保留；放开测试门后清理完成。','故障时序自动化'],
 ['关闭失败','E_RESOURCE_CLEANUP_FAILED 后窗口保留且可见，调用次数保持 1；明确再次结束后调用次数为 2，资源释放。','故障注入自动化'],
 ['立即重开','工作流 Esc 关闭后重新进入 READY；暂停时点窗口 X 关闭；单算子 Esc 后重新打开并运行99。','本轮候选真实 UI'],
 ],[1.25,4.55,1.34])
ev('escape-baseline.log/xml；escape-fixed-first.log/xml；lifecycle-expanded.log/xml；lifecycle-special.log/xml；ui/screenshots/029 至 048；ui/process-v2-timeline.jsonl')
h('开发过程保留',2)
p('基线 Esc 复现 2 failed；首次修复检查 4 passed；扩展入口检查 16 passed；后续生命周期专项 39 passed。它们是分阶段、重叠运行，不能相加为最终独立测试数量。')
h('覆盖边界',2)
p('原生截图能证明窗口表现和可重开，资源退休还需结合进程时间线与 Runtime 断言。自动化注入的清理失败不宣称等同真实网络丢包、丢 ACK 或全部强制乱序的原生验收。')
#Page3
h('3 参数编辑器及父窗边界',new=True)
h('R01 参数编辑器完成路径',2)
p('真实 UI 复验发现，参数编辑器同样会被 Esc 绕过 dirty 提示和管理器注销。本轮新增局部修复，将 done、reject、accept 路由至正常 closeEvent，保留取消、丢弃和应用后关闭的既有语义。')
tab(['选择','自动化预期与结果','本轮真实 UI'],[
 ['取消','99 仍留在编辑器；正式 model 为7；manager 保留同一实例。','061 弹出未保存提示；062 取消后保留99。'],
 ['丢弃','model 保持7；manager 注销一次；立即重开产生新实例。','063 再提示；064 关闭；065 首次立即重开显示7。'],
 ['应用后关闭','model 变99；apply 恰好一次；外部项目文件字节不变，Apply 不暗中 Save。','此分支未单独做原生操作，不提升为原生 PASS。'],
 ],[.8,3.8,2.54])
p('专项初始单例 1 failed；扩展先保留 12 failed、16 passed；修复后组合 31 passed。首失败与原栈没有覆盖。')
ev('editor-single-first.log/xml；editor-lifecycle.log/xml；editor-lifecycle-final.log/xml；ui/first-parameter-editor-escape-failure.log；ui/screenshots/061 至 065')
h('父参数窗与主窗等待真实退休',2)
p('参数父窗等待子调试窗真实销毁，等待期间只禁用父编辑控件，保留调试窗的错误查看和重试能力。清理失败后恢复控件并清除强制关闭标志；再次普通关闭须重新遵守 dirty 提示。')
p('主窗口收集所有活动调试窗并保持 Runtime transport 存活。一个兄弟窗口成功退休不会自动重发另一个失败窗口的关闭；用户明确再次关闭才重试。目录打开、Runtime 路径打开和启动项目入口在活动调试存在时先拒绝，避免修改当前项目。')
ev('parent-close-retirement.log/xml；parent-failure-injection.log/xml；parent-failure-recovery-final.log/xml；tests/designer/test_debug_main_window_boundaries.py；tests/designer/test_debug_dialog_retirement.py')

#Page4
h('4 工具栏菜单与 PLC 布局',new=True)
h('F03 箭头绘制与菜单列宽',2)
p('Fusion 的 qt_toolbar_ext_button 只有 12 个逻辑像素。通用 QToolButton 左右各 7px padding 加边框耗尽绘制矩形；isVisible 仍可为真，旧可见性断言因此漏检。仅对扩展按钮去除 padding 和边框，保留 Qt 原生展开动作及共享 QAction。')
p('DPR 2 下，480、589、658、800 四种宽度的箭头区深色像素由每组 0 增至 100。新增测试同时验证真实绘制、展开后尾部动作可见，以及“整理流程”只触发原 QAction 一次。中文菜单采用 7em 最小标题列宽；未宣称已解释 Qt 内部全部尺寸算法。')
ev('layout/extension-paint-before-after.json；before-toolbar-*.png；after-toolbar-*.png；menu-final0.png；caption-scale-*.log/xml')
h('F04 生产参数来源面板挤占',2)
p('基线在 640 宽生产装配中，参数控件 viewport 仅49px、内容77px；高级区展开后 viewport 为0。参数来源面板占高，加上结果表最低100px，将原最低24px控件区和最低0高级区挤压。旧12项测试未装配真实参数来源面板。')
p('修复将参数来源保留为第三 tab，将运行页改成整体滚动；高级区按实时字体与宽度计高，避免内层垂直滚动。运行页按结果表100px最小高度布局，不再被192px首选高度抬高；四参数使用标题在上、控件在下，补齐640宽中文标签。参数值、来源引用、连接、写入和租约逻辑不变。')
tab(['最终局部矩阵','结果','边界'],[
 ['caption-scale 1 / 1.25 / 1.5 / 2','每种 44 passed','offscreen；四种缩放重复用例不相加。'],
 ['caption-plc','122 passed','原113项与新9项；原430px、安全、异步断言未放宽。'],
 ['字段逐项可达','read/write × 640/800','连接、高级和来源字段逐项滚达，并验证原值/来源保持。'],
 ],[2.15,1.35,3.64])
ev('layout/layout-result.md；layout/plc-before/geometry.json；layout/plc-caption-final/geometry.json；layout/caption-plc.log/xml')

#Page5
h('5 本轮真实桌面证据',new=True)
p('桌面为 Debian 13.6、Xfce/X11，1364×1024。运行环境为 Python 3.10.22、PySide2 5.15.2.1、gRPC 1.78.0。自动化使用独立 offscreen 进程；不得把它的缩放矩阵当作原生桌面缩放完成。原生分阶段启动源分别保留身份和环境记录。')
tab(['范围','本轮操作和已观察结果','截图编号'],[
 ['D03 D08数字','进入子调用，临时试参99，长暂停后跳出、进入第二次调用、单步跳过；两次正式返回7，继续到完成。','014-029'],
 ['工作流退出','完成后 Esc 关闭，首次立即重开 READY；再运行到暂停，窗口 X 关闭。','030-037'],
 ['D01单算子','Esc 关闭后参数窗保留；带未应用99重开，单步输出99，再次 Esc；正式参数仍7。','040-050'],
 ['参数编辑器','Esc 出 dirty 提示；Cancel 保留99；Discard 后第一次立即重开7。','061-065'],
 ['D02 D07 D08图像','独立127、run-to threshold的上游滤波输入、临时200与正式127分别零像素差异；详见冻结原生结果。','139-191'],
 ['D04 D05 D06','普通断点、条件断点、ForEach本轮未重走真实UI，只按本轮自动化判定；旧原生记录不计入本轮。','NOT_RUN'],
 ['最终冻结版','统一源码布局、父窗/主窗、项目替换及O20原生证据独立列在后文。','067-200'],
 ],[1.25,4.99,.9])
p('D03 临时参数隔离：trial99.emodebug.zip 保存临时试跑结果；正式项目副本 SHA256 与原样例相同。该证据只证明本轮列明流程，不扩大到所有调试结果隔离路径。')
ev('ui/actions.jsonl；ui/process-v2-timeline.jsonl；ui/number-draft-file-preservation.json；ui/trial99.emodebug.zip；ui/environment-before.log；ui-final/environment-before.log；ui-frozen/environment-before.log')
h('6 原生复验观察与首失败',new=True)
for i,t in enumerate(C['observations']):
 h(['旧无效工程启动','PLC 滚轮误改','O20 辅助工具首失败','收尾进程核验口径'][i] if i<4 else '补充观察',2);p(t,size=10)
# Final frozen native record
h('7 最终冻结原生复验',new=True)
p('以下记录来自本轮最终产品源码副本的桌面复验，source-frozen-ui用于布局及生命周期，source-o20-native用于官方入口O20，source-image-ui用于图像与项目替换边界。结果随源身份、实际窗口尺寸和原始截图分别绑定；没有将旧验收记录替代本轮操作。')
if not C['nativeFinalResults']:p('本阶段尚在执行，等待完整截图、操作记录和资源检查。')
for x in C['nativeFinalResults']:
 h(x.get('title',x['section']),2);p(x['text']);ev(x.get('evidence',''))
#Page6
h('8 自动化静态与 SQLite 分账',new=True)
fullName=C.get('finalFullRun','final-full-suite')
staticName=C.get('finalStaticRun','final-static-0147')
final=D['runIdentities'].get(fullName,{})
finalstatus=run_summary(fullName) if final.get('finishedUtc') else '仍运行，未作通过结论'
static=D['runIdentities'].get(staticName,{})
staticstatus='四项exit 0' if len(static.get('runs',[]))==4 and all(r.get('exitCode')==0 for r in static['runs']) else '等待完整终态'
tab(['运行','结果','可采用范围'],[
 [fullName,finalstatus,'JUnit、退出码及前后源码一致性共同判定。'],
 ['候选 full-suite','4765 passed / 19 skipped / 29 subtests','过程证据；源码中途改变，不认证最终补丁。'],
 [staticName,staticstatus,'proto、ruff、Linux/win32 mypy；win32仅静态。'],
 ['SQLite 安全专项','23 passed / 8 skipped','Windows大小写路径8变体跳过。'],
 ['冻结 O20 十轮','10轮×2项，20 passed','02:03独立进程；不并入全量、非真实桌面。'],
 ['候选 O20 历史','另10轮×2项，20 passed','01:21前期候选，仅保留历史；不叠加为最终轮数。'],
 ],[1.6,2.55,2.99])
h('O20 冻结十轮与候选历史',2)
p('02:03冻结产品后的final-o20十轮各有2项通过，原test_user_path.py未改，每轮独立进程、业务库、两个不同Job及workflowRunId，两次COMMITTED，数据[7,13]。01:21候选十轮另保留，不算作最终20轮。最终十个业务库另经SQLite只读URI执行integrity_check全部为ok，检查前后文件SHA256不变；候选检查仍独立保留。')
p('资源退休证明来自原测试：原10秒退休栅栏后 getProcess(job) is None 且 ownsJobResources(job) 为 false，随后第一次 LoadProject 成功。本轮十轮未另加独立实时资源快照探针，因此不把这一层写成额外原生观测。')
ev('regression/final-o20/ten-round-summary.json与十个round目录；regression/o20/保留候选历史及database-integrity-summary.json。')
h('跳过与专项分账',2)
p('19项SKIP为真实相机1、显式压力1、长租约1、Windows大小写路径8、Windows批处理1、Windows原生WAL捕获3、PowerShell4。最终跳过明细以 '+fullName+'/pytest.log 和 JUnit 为准。显式专项通过不改写全量SKIP；未完成专项保持NOT_RUN，不能借用旧轮数值。')
h('9 首轮全量诊断与补充专项',new=True)
for x in C.get('automationFinalResults',[]):
 if x.get('title'):h(x['title'],2)
 p(x['text']);ev(x.get('evidence',''))
#Page7
h('10 版本身份与交付边界',new=True)
p('固定基线0120814；产品6文件、既有测试退出同步2文件、新测试4文件，共12文件。未提交或推送。源码哈希见source-manifest-at-report.json，完整补丁应用校验另附。')
tab(['文件','改动范围'],[
 ['operator_editors/workspace_window.py','参数来源 tab；参数编辑器完成入口；父窗等待/失败恢复。'],
 ['ui/main_window.py','活动调试统一收集；主窗异步退休；项目替换前置拒绝。'],
 ['ui/operator_debug_window.py','统一完成入口；closeSent；cleanupFailed；防止重复关闭。'],
 ['ui/workflow_debug_window.py','统一完成入口进入安全关闭。'],
 ['ui/styles/app.qss','扩展按钮绘制与菜单标题最小列宽。'],
 ['plugins/builtins/_plc_editor.py','运行页整页滚动、高级区计高和参数标题布局。'],
 ],[3.5,3.64])
p('新增4个测试文件覆盖调试退出、主窗边界、参数编辑器退出和小窗布局；两份既有测试仅增强退出同步。原超时、业务及安全断言未放宽，精确路径见完整补丁和证据索引。',size=10)
p('统一冻结身份：'+C['sourceFinalIdentity'])
h('尚未覆盖及保留项',2)
p('修复补丁未提交、推送或发布，无远端SHA及对应CI，记NOT_RUN；旧012精确SHA的CI绿灯不计为补丁CI。Windows实机与补丁Windows动态CI仍NOT_RUN，win32 mypy仅静态。真实PLC、相机、外部写入、物理联锁、用户安装及生产部署未执行；旧PR合并版F01/F02超时不在本轮修复结论内。')
p('本轮关闭失败不自动重试 RPC。清理失败保留错误、窗口与所有者，允许用户明确重试；不能用最终正常退出证明全部中途失败边界均已通过。')
p('产品源码包排除3842项历史验收附件，包含必要夹具，并非仓库镜像。完整补丁可从固定012基线恢复12文件。每个ZIP小于20MB，附清单及SHA256。旧验收仅作编号参考。')
#Page8
h('11 证据索引',new=True)
p('以下为相对 evidence 的入口。完整逐例 JUnit 映射、阶段状态、运行身份和源码哈希保存在 evidence-index.json；可读入口为 evidence-index.txt。')
tab(['主题','主要证据入口'],[
 ['首失败与修复','escape-baseline、escape-fixed-first、lifecycle-expanded、lifecycle-special 的 .log/.xml/.exit。'],
 ['参数 dirty 修复','editor-single-first、editor-lifecycle、editor-lifecycle-final；ui/first-parameter-editor-escape-*.log。'],
 ['父窗与主窗','parent-close-retirement、parent-failure-injection、parent-failure-recovery-final。'],
 ['布局诊断及当前实现','layout/layout-result.md；caption-*.log/xml；plc-caption-final/geometry.json；extension-paint-before-after.json。'],
 ['过程失败保留','layout/scale-*、final-*、verified-* 的失败或导入错误；无效候选阶段没有覆盖删除。'],
 ['真实 UI','ui/actions.jsonl；ui/screenshots；ui/process-v2-timeline.jsonl；ui-frozen/与最终原生启动目录。'],
 ['冻结全量','regression/'+fullName+'/ 的 identity.json、imports.log、pytest.log、junit.xml、exit-code.txt、tracked-sha256.before.json。'],
 ['冻结静态','regression/'+staticName+'/ 的 identity.json、四份 .log/.exit-code.txt、junit.xml。'],
 ['O20及安全','regression/final-o20/及ten-round-summary.json；report/final-o20-readonly-integrity.json；regression/o20/保留候选历史；regression/sqlite-safety。'],
 ],[1.65,5.49])
p('证据完整性说明：文件名含 final 不自动表示最终版本。布局以 caption 系列为最新局部结果；全局以本报告明确命名的统一冻结运行及其前后源码一致性为准。',True)
#Appendix images
for title,rel,caption in [
 ('12 原生工作流试参与正式结果','ui/screenshots/027-second-return-output7.png','UI027  第二次正式调用返回7；临时试参99的独立结果见UI019及trial99.emodebug.zip。'),
 ('13 原生工作流首次立即重开','ui/screenshots/034-workflow-reopened-ready.png','UI034  Esc关闭后的首次重新打开进入READY。它属于本轮候选UI阶段，源身份按前文分层。'),
 ('14 原生参数编辑器取消','ui/screenshots/062-phase2-dirty-cancel-keeps-99.png','UI062  Esc触发dirty提示后取消，参数编辑器保留临时99。'),
 ('15 原生参数编辑器丢弃后重开','ui/screenshots/065-phase2-immediate-reopen-original7.png','UI065  丢弃后第一次立即重开显示原正式值7，未把99应用到正式参数。'),
 ('16 最终原生 PLC 高级字段可达','ui/screenshots/087-frozen-plc-640-advanced-bottom.png','UI087  最终冻结版640×474实际小窗，高级区底部可滚达；未连接或允许写入。'),
 ('17 最终原生高 DPI 工具栏展开','ui/screenshots/111-dpr2-overflow-open-result.png','UI111  最终冻结版实际DPR2.0，扩展箭头可见可点，尾部动作展开为第二行。')]:
 h(title,new=True);image(rel,caption)
 p('完整原图和前后操作时序见配套截图目录及 ui/actions.jsonl。',size=9)
name='emo-master-0120814-debian-repair-'+stage+'.docx'; out=O/name
DOC.save(out)
manifest={'generatedUtc':datetime.now(timezone.utc).isoformat(),'report':name,'stage':stage,'indexSha256':hashlib.sha256((O/'evidence-index.json').read_bytes()).hexdigest(),'controlSha256':hashlib.sha256((O/'report-control.json').read_bytes()).hexdigest(),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
(O/'report-build-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(out)
