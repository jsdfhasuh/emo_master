from pathlib import Path
import json, hashlib, re, subprocess, xml.etree.ElementTree as ET
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[2]
E=ROOT/'evidence'; O=E/'report'; S=ROOT/'source'
xmls=[]
for f in sorted(E.rglob('*.xml')):
 if 'pytest-tmp' in f.parts or 'report' in f.parts: continue
 try:
  root=ET.parse(f).getroot(); ss=list(root.iter('testsuite'))
  counts={k:sum(int(s.get(k,0)) for s in ss) for k in ('tests','failures','errors','skipped')}
  log=f.with_suffix('.log')
  if f.name=='junit.xml': log=f.parent/'pytest.log'
  lines=log.read_text(errors='replace').splitlines() if log.exists() else []
  terminal=[x for x in lines if re.search(r'\b(?:passed|failed|error|skipped)\b.* in [0-9.]+s',x)]
  xmls.append({'path':str(f.relative_to(E)),'junitCounts':counts,'terminalSummary':terminal[-1] if terminal else None,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'testcases':[{'classname':t.get('classname'),'name':t.get('name'),'result':'FAIL' if t.find('failure') is not None else 'ERROR' if t.find('error') is not None else 'SKIP' if t.find('skipped') is not None else 'PASS'} for t in root.iter('testcase')]})
 except ET.ParseError: pass
source_paths=[x for x in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=S).decode().split('\0') if x and (S/x).is_file()]
manifest={p:hashlib.sha256((S/p).read_bytes()).hexdigest() for p in source_paths}
status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=S,text=True)
actions=[json.loads(x) for x in (E/'ui/actions.jsonl').read_text().splitlines()]
runs={}
for p in (E/'regression').glob('*/identity.json'):
 d=json.loads(p.read_text()); runs[p.parent.name]=d
claims=[
 ('F05','QDialog completion routes','阶段修复已验证','escape-baseline.xml; escape-fixed-first.xml; lifecycle-expanded.xml; lifecycle-special.xml; source/tests/designer/test_debug_dialog_retirement.py','ui/screenshots/029-037; ui/screenshots/040-048; ui/process-v2-timeline.jsonl','工作流及单算子 Esc、窗口 X、立即重开；最终统一源码验证仍随终局证据更新'),
 ('R01','参数编辑器 dirty 与注销','阶段修复已验证','editor-single-first.xml; editor-lifecycle.xml; editor-lifecycle-final.xml; source/tests/designer/test_parameter_editor_retirement.py','ui/screenshots/061-065','Cancel 保留99；Discard 重开7；Save 分支当前为自动化，原生未单独执行'),
 ('PARENT','父窗和主窗退休边界','专项自动化已验证','parent-close-retirement.xml; parent-failure-injection.xml; parent-failure-recovery-final.xml; source/tests/designer/test_debug_main_window_boundaries.py','待最终冻结原生记录','失败保留并显式重试，无自动RPC重发；自动化故障注入不是真实网络故障原生验收'),
 ('F03','工具栏与菜单布局','自动化已验证','layout/layout-result.md; layout/caption-scale-*.xml; layout/extension-paint-before-after.json','待最终冻结原生记录','offscreen DPR矩阵不能替代原生高DPI体验'),
 ('F04','PLC生产参数来源布局','自动化已验证','layout/caption-plc.xml; layout/caption-scale-*.xml; layout/plc-caption-final/geometry.json','待最终冻结原生记录','保留参数和来源契约；未连接真实PLC'),
 ('D03','临时参数99与正式7隔离','本轮候选原生通过','ui/number-draft-file-preservation.json; ui/trial99.emodebug.zip','ui/screenshots/014-029; ui/actions.jsonl','长暂停约100秒后两次调用正式返回7；按本轮候选源码阶段注明'),
 ('O20','十轮SQLite路径回归','自动化20项通过','regression/o20/ten-round-summary.json; regression/o20/database-integrity-summary.json; regression/o20/round-*/junit.xml','本轮真实UI待终局','10独立进程×2项；每轮[7,13]、独立Job/Run、COMMITTED及原资源断言；不合并进全量'),
 ('FINAL_FULL','统一冻结全量','等待终局','regression/final-full-suite/identity.json; regression/final-full-suite/pytest.log; regression/final-full-suite/junit.xml','不适用','候选4765pass不得替代本轮最终结论'),
 ('FINAL_STATIC','统一冻结静态','完整终态已出现','regression/final-static-0147/identity.json; regression/final-static-0147/junit.xml','不适用','4项exit0，trackedFilesUnchanged=true；win32仅静态'),
]
control=json.loads((O/'report-control.json').read_text()) if (O/'report-control.json').exists() else {}
data={'generatedUtc':datetime.now(timezone.utc).isoformat(),'baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'gitStatus':status,'sourceManifest':manifest,'runIdentities':runs,'xmlRuns':xmls,'uiCutoff':actions[-1] if actions else None,'claims':[dict(zip(['id','subject','status','automatedEvidence','nativeEvidence','boundary'],r)) for r in claims]}
data['reportControl']=control
for r in data['claims']:
 if r['id'] in ['F03','F04'] and any(x.get('section')=='layout' and r['id'] in x.get('title','') for x in control.get('nativeFinalResults',[])):
  r['status']='局部自动化及最终冻结列明原生范围通过'
  r['nativeEvidence']='；'.join(x['evidence'] for x in control['nativeFinalResults'] if r['id'] in x.get('title',''))
 if r['id']=='PARENT' and any(x.get('section')=='lifecycle' for x in control.get('nativeFinalResults',[])):
  r['status']='专项自动化及最终冻结成功关闭原生通过'
  r['nativeEvidence']='；'.join(x['evidence'] for x in control['nativeFinalResults'] if x.get('section')=='lifecycle')
 if r['id']=='O20':
  r['status']='最终冻结自动化10轮20项通过；最终官方入口列明原生通过'
  r['automatedEvidence']='regression/final-o20/ten-round-summary.json; regression/final-o20/round-*/junit.xml; report/final-o20-readonly-integrity.json；regression/o20/仅保留候选历史'
  r['boundary']='最终10独立进程×2项；每轮[7,13]、独立Job/Run、COMMITTED及原资源断言；前期候选十轮另记，不叠加；不合并进全量'
  r['nativeEvidence']='；'.join(x['evidence'] for x in control.get('nativeFinalResults',[]) if x.get('section')=='o20') or r['nativeEvidence']
 if r['id']=='FINAL_FULL':
  name=control.get('finalFullRun','final-full-suite')
  r['automatedEvidence']='regression/'+name+'/identity.json; pytest.log; junit.xml; exit-code.txt'
  r['status']='4788 passed / 19 skipped / 29 subtests，exit0且源码哈希一致' if control.get('finalized') and runs.get(name,{}).get('exitCode')==0 and runs.get(name,{}).get('trackedFilesUnchanged') else '等待终局'
 if r['id']=='FINAL_STATIC':
  name=control.get('finalStaticRun','final-static-0147')
  r['automatedEvidence']='regression/'+name+'/identity.json; junit.xml; 各静态log及exit-code.txt'
  check=runs.get(name,{})
  r['status']='四项exit0且源码前后一致' if len(check.get('runs',[]))==4 and all(t.get('exitCode')==0 for t in check['runs']) and check.get('trackedFilesUnchanged') else '等待终局'
for r in data['claims']:
 if r['id']=='F05':
  r['status']='局部修复及v3全量通过；候选原生主路径与最终关闭边界分别取证'
  r['boundary']='候选UI直接走工作流及单算子Esc、窗口X、立即重开；最终产品源码原生父窗/主窗关闭与v3全量另证，不把候选截图改称最终版'
data['claims'].append({'id':'FINAL_LEASE','subject':'最终v3长暂停续租','status':'1 passed / 66.01s，exit0且源码哈希一致','automatedEvidence':'regression/final-lease-v3/identity.json; pytest.log; junit.xml','nativeEvidence':'ui-image/pixel-check.json及actions中的超过80秒暂停，属另列原生观察','boundary':'original-lease成功但测试fixture在运行期间变化，保留过程；最终采用final-lease-v3，不改变全量19项SKIP'})
(O/'evidence-index.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
(O/'source-manifest-at-report.json').write_text(json.dumps(manifest,indent=2)+'\n')
lines=['EmoMaster Debian 局部修复证据索引', '记录时间 '+data['generatedUtc'],'基线 '+data['baseline'],'以下路径相对于 evidence；source/指工作根源码。','']
for r in data['claims']:
 lines+=['【'+r['id']+'】'+r['subject']+'：'+r['status'],'自动化：'+r['automatedEvidence'],'原生：'+r['nativeEvidence'],'边界：'+r['boundary'],'']
lines+=['完整XML逐项映射与源码SHA256见 evidence-index.json。','本索引是证据采集截面，不能将未完成运行提升为通过。']
(O/'evidence-index.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({'cutoff':data['uiCutoff'],'xmlRuns':len(xmls),'sourceFiles':len(manifest)},ensure_ascii=False))
