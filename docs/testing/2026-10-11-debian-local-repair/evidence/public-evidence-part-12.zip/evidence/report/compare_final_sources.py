from pathlib import Path
import json,hashlib
O=Path(__file__).resolve().parent;R=O.parents[1]
m=json.loads((O/'source-manifest-at-report.json').read_text());comp={}
for name in ['source-frozen-ui','source-o20-native','source-image-ui']:
 T=R/name;missing=[p for p in m if not (T/p).is_file()];diff=[p for p,v in m.items() if (T/p).is_file() and hashlib.sha256((T/p).read_bytes()).hexdigest()!=v]
 comp[name]={'comparedFiles':len(m),'missing':missing,'different':diff,'productSrcFilesCompared':sum(p.startswith('src/') for p in m),'productSrcDifferences':[p for p in missing+diff if p.startswith('src/')]}
(O/'frozen-source-comparison.json').write_text(json.dumps(comp,ensure_ascii=False,indent=2)+'\n');print(json.dumps(comp,ensure_ascii=False,indent=2))
