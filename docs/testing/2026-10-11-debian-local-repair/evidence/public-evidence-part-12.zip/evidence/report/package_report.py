from pathlib import Path
import json,hashlib,zipfile
O=Path(__file__).resolve().parent
C=json.loads((O/'report-control.json').read_text());stage='final' if C['finalized'] else 'stage'
qa=O/f'visual-qa-{stage}.json'
if not qa.exists() or not json.loads(qa.read_text()).get('allPagesInspected'):raise SystemExit('Visual QA has not passed for this build.')
files=[O/f'emo-master-0120814-debian-repair-{stage}.docx',O/f'emo-master-0120814-debian-repair-{stage}.pdf',O/'evidence-index.json',O/'evidence-index.txt',O/'source-manifest-at-report.json',O/'report-build-manifest.json',O/'report-control.json',O/'native-file-crosschecks.json',O/'frozen-source-comparison.json',O/'final-o20-readonly-integrity.json',qa]
if any(not x.exists() for x in files):raise SystemExit('Missing report artifact')
qa_data=json.loads(qa.read_text())
for f in files[:2]:
 if qa_data['sha256'][f.name]!=hashlib.sha256(f.read_bytes()).hexdigest():raise SystemExit('Artifact changed since visual QA')
manifest={f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files}
(O/f'artifact-manifest-{stage}.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
files.append(O/f'artifact-manifest-{stage}.json')
zp=O/f'emo-master-0120814-debian-repair-report-{stage}.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.write(f,f.name)
if zp.stat().st_size>=20_000_000:raise SystemExit('ZIP exceeds 20 MB')
with zipfile.ZipFile(zp) as z:
 if z.testzip() is not None:raise SystemExit('ZIP CRC failed')
print(json.dumps({'path':str(zp),'bytes':zp.stat().st_size,'sha256':hashlib.sha256(zp.read_bytes()).hexdigest()},indent=2))
