"""Read-only checks of PNG archives exported through the native Designer UI."""
import json
import pathlib
import zipfile
import cv2
import numpy as np

root = pathlib.Path(__file__).parent
original = cv2.imread(str(root / 'fixtures/sample.png'), cv2.IMREAD_GRAYSCALE)
blurred = cv2.GaussianBlur(original, (3, 3), 0)
expected = {
    'independent127-mask': cv2.threshold(original, 127, 255, cv2.THRESH_BINARY)[1],
    'threshold-input-blurred': blurred,
    'trial200-mask': cv2.threshold(blurred, 200, 255, cv2.THRESH_BINARY)[1],
    'formal127-mask': cv2.threshold(blurred, 127, 255, cv2.THRESH_BINARY)[1],
}
result = {'checks': {}, 'blur_vs_original_changed_pixels': int(np.count_nonzero(blurred != original))}
for name, value in expected.items():
    with zipfile.ZipFile(root / (name + '.emodebug.zip')) as archive:
        actual = cv2.imdecode(np.frombuffer(archive.read('value.png'), np.uint8), cv2.IMREAD_GRAYSCALE)
        result['checks'][name] = {
            'metadata': json.loads(archive.read('metadata.json')),
            'shape': list(actual.shape),
            'expected_mismatch_pixels': int(np.count_nonzero(actual != value)),
        }
        assert actual.shape == value.shape
        assert np.array_equal(actual, value)
source = root.parent.parent / 'source/examples/workflow_debugger/03-image.emoproj'
result['project_unchanged'] = (root / 'fixtures/03-image.emoproj').read_bytes() == source.read_bytes()
assert result['project_unchanged']
(root / 'pixel-check-reproduced.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print('PASS: four complete 320x240 PNGs, original project unchanged')
