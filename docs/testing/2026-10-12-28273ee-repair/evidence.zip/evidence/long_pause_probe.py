"""Isolated API/worker long-pause acceptance, not manual Qt interaction."""
import json
from pathlib import Path
import time

from emo_master.apps.designer.services.runtime_client import RuntimeClient
from emo_master.apps.designer.services.workflow_debug import WorkflowDebugConnection
from emo_master.apps.runtime.grpc_server.service import RuntimeService
from tests.runtime.test_operator_debug_sessions import waitFor
from tests.runtime.test_workflow_debug_control import nestedProject


def main():
    root = Path(__file__).parent
    output = root / "long-pause.json"
    assert not output.exists()
    service = RuntimeService(dbPath=root / "long-pause-data" / "runtime.db",
                             workspaceRoot=root / "long-pause-data" / "jobs")
    connection = WorkflowDebugConnection(RuntimeClient(service))
    report = dict(layer="API/real worker, not manual GUI", requestedPauseSeconds=80)
    try:
        connection.openWorkflow(nestedProject(), "main")
        waitFor(lambda: connection.call("GetWorkflowDebugSession")["state"] == "READY")
        connection.start({})
        waitFor(lambda: connection.call("GetWorkflowDebugSession")["state"] == "PAUSED")
        before = connection.call("GetWorkflowDebugSession")
        begin = time.monotonic()
        time.sleep(80)
        after = connection.call("GetWorkflowDebugSession")
        report.update(elapsedPauseSeconds=time.monotonic()-begin, before=before, after=after)
        assert after["state"] == "PAUSED" and not connection.leaseError
        assert after["ttlMs"] > 45000
        assert before["flow"]["pauseSequence"] == after["flow"]["pauseSequence"]
        assert before["flow"]["current"] == after["flow"]["current"]
        connection.control("continue", after["flow"]["pauseSequence"])
        waitFor(lambda: connection.call("GetWorkflowDebugSession")["state"] == "SUCCEEDED")
        state = connection.call("GetWorkflowDebugSession")
        result = connection.call("GetWorkflowDebugSnapshot", execution_id=state["flow"]["lastOutput"])
        report["result"] = result
        assert result["outputs"] == {"value": 7}
        report["status"] = "PASS"
    except BaseException as error:
        report.update(status="FAIL", error=repr(error))
        raise
    finally:
        try:
            report["closed"] = connection.close()
            report["resourcesHeld"] = service.operatorDebugManager.ownsResources()
            assert not report["resourcesHeld"]
        finally:
            service.close()
            output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(dict(status=report["status"], elapsed=report["elapsedPauseSeconds"],
                         resourcesHeld=report["resourcesHeld"])), flush=True)


if __name__ == "__main__":
    main()
