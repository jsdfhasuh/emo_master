"""Package path-redacted copies, retaining hashes of untouched private originals."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path.cwd()
RAW = Path(__file__).parent
DEST = ROOT/'docs/testing/2026-10-12-28273ee-repair'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def redact(raw):
    text = raw.decode('utf-8-sig')
    mappings = [(str(ROOT), '<REPAIR_WORKTREE>'), (str(RAW), '<PRIVATE_EVIDENCE>'),
                (r'<USERPROFILE>', '<USERPROFILE>'),
                (r'<ORIGINAL_DIRTY_WORKTREE>', '<ORIGINAL_DIRTY_WORKTREE>')]
    for original, replacement in mappings:
        for pattern in (original.replace('\\', '\\\\'), original.replace('\\', '/'), original):
            text = text.replace(pattern, replacement)
    return text.encode('utf-8')


def main():
    assert (RAW/'final-pytest.xml').exists()
    assert json.loads((RAW/'source-changed.json').read_text()) == []
    assert not (DEST/'evidence.zip').exists()
    files = sorted(p for p in RAW.iterdir() if p.is_file() and p.suffix in {'.json', '.log', '.xml', '.exitcode', '.py'})
    files += sorted(RAW.glob('while-ledger-*/*.json'))
    sourceFiles = [line for line in subprocess.check_output(['git', 'ls-files', '--modified', '--others', '--exclude-standard']).decode().splitlines()
                   if line.startswith(('src/', 'tests/', 'scripts/'))]
    entries = []
    with zipfile.ZipFile(DEST/'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            raw = path.read_bytes()
            public = redact(raw)
            name = 'evidence/'+path.relative_to(RAW).as_posix()
            archive.writestr(name, public)
            entries.append(dict(path=name, rawSha256=digest(raw), publishedSha256=digest(public),
                                rawBytes=len(raw), publishedBytes=len(public), pathRedacted=raw != public))
        for filename in sourceFiles:
            raw = (ROOT/filename).read_bytes()
            archive.writestr('candidate-source/'+filename, raw)
            entries.append(dict(path='candidate-source/'+filename, rawSha256=digest(raw), publishedSha256=digest(raw),
                                rawBytes=len(raw), publishedBytes=len(raw), pathRedacted=False))
        index = dict(baseline='28273ee0436250c2b3efcbddf43d31b4e067ee88',
            description='Original private evidence remains untouched. Public copies redact only known local path prefixes. Numbers/outcomes are not rewritten.',
            entries=entries)
        data = json.dumps(index, ensure_ascii=False, indent=2).encode('utf-8')
        archive.writestr('INDEX.json', data)
        (DEST/'EVIDENCE_INDEX.json').write_bytes(data)
    for_verify = DEST/'evidence.zip'
    with zipfile.ZipFile(for_verify) as archive:
        assert archive.testzip() is None
        for entry in entries:
            assert digest(archive.read(entry['path'])) == entry['publishedSha256']
    (DEST/'SHA256SUMS').write_text('\n'.join(digest((DEST/name).read_bytes())+'  '+name
                                 for name in ('evidence.zip', 'EVIDENCE_INDEX.json'))+'\n', encoding='utf-8')
    print(json.dumps(dict(files=len(entries), zipBytes=for_verify.stat().st_size, zipSha256=digest(for_verify.read_bytes()))))


if __name__=='__main__':
    main()
