"""One fixed final software run. Evidence is never overwritten."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from prototypes.runtime_pages_p0.watchdog import ProcessTree

ROOT = Path.cwd()
OUT = Path(__file__).parent


def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z']).decode().split('\0')
    selected = {path for path in paths if path and
                (path.startswith(('src/', 'tests/', 'scripts/', 'prototypes/', 'examples/')) or '/' not in path)
                and Path(path).suffix in {'.py', '.json', '.toml', '.ini', '.txt', '.ui', '.qss', '.yml', '.yaml', '.proto'}}
    return {path: hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in sorted(selected) if (ROOT/path).is_file()}


def main():
    before = snapshot()
    (OUT/'source-before.json').write_text(json.dumps(before, indent=2), encoding='utf-8')
    env = dict(os.environ, QT_QPA_PLATFORM='offscreen', HUARAY_CAMERA_SMOKE='0')
    steps = [
        ('proto', ['scripts/gen_proto.py', '--check']),
        ('ruff', ['-m', 'ruff', 'check', 'src', 'tests', 'scripts/acceptance_sqlite_ledger.py']),
        ('mypy', ['-m', 'mypy', '--config-file', 'mypy.ini', 'src']),
        ('pytest', ['-u', '-m', 'pytest', '-q', '--junitxml='+str(OUT/'final-pytest.xml')]),
    ]
    results = []
    for name, args in steps:
        command = [sys.executable, *args]
        begin = time.monotonic()
        print('START '+name, flush=True)
        with (OUT/f'final-{name}.log').open('x', encoding='utf-8') as output:
            child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
            tree = ProcessTree(child.pid)
            try:
                code = child.wait(timeout=3600)
            finally:
                tree.close()
        results.append(dict(step=name, command=command, exitCode=code, seconds=time.monotonic()-begin))
        (OUT/'final-steps.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(results[-1]), flush=True)
        print('\n'.join((OUT/f'final-{name}.log').read_text(encoding='utf-8', errors='replace').splitlines()[-8:]), flush=True)
        if code:
            break
    after = snapshot()
    changed = sorted(path for path in before.keys() | after.keys() if before.get(path) != after.get(path))
    (OUT/'source-after.json').write_text(json.dumps(after, indent=2), encoding='utf-8')
    (OUT/'source-changed.json').write_text(json.dumps(changed), encoding='utf-8')
    print('SOURCE_CHANGED '+json.dumps(changed), flush=True)
    return int(bool(changed) or any(row['exitCode'] for row in results))


if __name__ == '__main__':
    raise SystemExit(main())
