"""Offline lossless codec candidate measurement, not a product performance verdict."""
import json
import time
from pathlib import Path

import emo_master  # noqa: F401 - preload ONNX Runtime before Qt/OpenCV on Windows
import cv2
import numpy as np

root = Path(__file__).parent
cases = {
    "noise": np.random.default_rng(20260926).integers(0, 256, (1080, 1920, 3), np.uint8),
    "flat": np.full((1080, 1920, 3), 127, np.uint8),
}
settings = {"default": [], "level0": [cv2.IMWRITE_PNG_COMPRESSION, 0],
            "rle1": [cv2.IMWRITE_PNG_COMPRESSION, 1, cv2.IMWRITE_PNG_STRATEGY, cv2.IMWRITE_PNG_STRATEGY_RLE]}
records = []
for name, image in cases.items():
    for label, params in settings.items():
        times = []
        for _ in range(12):
            started = time.perf_counter_ns()
            ok, data = cv2.imencode('.png', image, params)
            times.append((time.perf_counter_ns() - started) / 1e6)
            assert ok and np.array_equal(cv2.imdecode(data, cv2.IMREAD_UNCHANGED), image)
        records.append(dict(case=name, setting=label, bytes=int(data.nbytes),
                            median_ms=float(np.median(times)), p95_ms=float(np.percentile(times, 95))))
path = root/'codec-probe.json'
with path.open('x', encoding='utf-8') as output:
    json.dump(records, output, indent=2)
print(json.dumps(records, indent=2))
