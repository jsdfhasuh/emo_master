"""Diagnostic stage profile. Not a P0 acceptance run; no deadlines changed."""
import json
from pathlib import Path
import time
import tempfile
import threading
import hashlib

import emo_master  # noqa: F401
import cv2
import numpy as np
from prototypes.runtime_pages_p0.continuous import window
from prototypes.runtime_pages_p0.pipeline import Pipeline
from prototypes.runtime_pages_p0.async_exports import AsyncExports
from prototypes.runtime_pages_p0.resources import Assets
from emo_master.apps.runtime.preview.store import PreviewSnapshotWriter
from emo_master.apps.runtime.grpc_server.service import RuntimeService


def main():
    records = []
    def wrap(cls, name):
        original = getattr(cls, name)
        def measured(*args, **kwargs):
            wall, cpu = time.perf_counter_ns(), time.thread_time_ns()
            try:
                return original(*args, **kwargs)
            finally:
                records.append(dict(stage=f'{cls.__name__}.{name}', thread=threading.current_thread().name,
                    wall_ms=(time.perf_counter_ns()-wall)/1e6, cpu_ms=(time.thread_time_ns()-cpu)/1e6))
        setattr(cls, name, measured)
    for cls, name in [(Pipeline, 'publish'), (Pipeline, 'capture'), (Pipeline, 'committed'),
                      (AsyncExports, 'submit'), (Assets, 'adopt'), (Assets, '_delete'),
                      (PreviewSnapshotWriter, 'capture')]:
        wrap(cls, name)
    with tempfile.TemporaryDirectory(prefix='emo-p0-stage-') as temp:
        root = Path(temp)
        pixels = np.random.default_rng(20260926).integers(0,256,(1080,1920,3),np.uint8)
        path = root/'input.png'
        assert cv2.imwrite(str(path),pixels)
        service = RuntimeService(dbPath=root/'runtime.db',workspaceRoot=root/'jobs')
        try:
            report = window(root/'capture',service,path,hashlib.sha256(pixels).hexdigest(),count=32,warmup=8,viewers=0)
        finally:
            service.close()
    summary = {}
    for stage in sorted({r['stage'] for r in records}):
        rows = [r for r in records if r['stage']==stage]
        summary[stage] = dict(count=len(rows), p95_wall_ms=float(np.percentile([r['wall_ms'] for r in rows],95)),
                             p95_cpu_ms=float(np.percentile([r['cpu_ms'] for r in rows],95)),
                             max_wall_ms=max(r['wall_ms'] for r in rows))
    out=Path(__file__).with_name('pipeline-profile.json')
    with out.open('x',encoding='utf-8') as f:
        json.dump(dict(kind='DIAGNOSTIC_NOT_ACCEPTANCE',summary=summary,records=records,window=report),f,indent=2)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
