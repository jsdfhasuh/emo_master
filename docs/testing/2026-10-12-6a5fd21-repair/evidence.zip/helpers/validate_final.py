"""Frozen, sequential validation; retain first outcomes including performance FAIL."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(r'C:\Users\jsdfhasuh\.codex\worktrees\abc7ae-acceptance-repair\emo_master')
OUT=Path(__file__).parent


def fingerprints():
    return {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for directory in ('src','tests','scripts','prototypes') for p in sorted((ROOT/directory).rglob('*.py'))}


def main():
    env=dict(os.environ, PYTHONPATH=str(ROOT/'src')+os.pathsep+str(ROOT), QT_QPA_PLATFORM='offscreen', PYTHONIOENCODING='utf-8')
    env.pop('EMO_PRESENTATION_TRACE',None)
    before=fingerprints()
    (OUT/'final-source-before.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
    steps=[
        ('final-p0',[sys.executable,'scripts/p0_validate.py','--scenarios','benchmark','--count','96','--rounds','3','--warmup','8','--require-performance','--output',str(OUT/'final-p0.json')]),
        ('final-proto',[sys.executable,'scripts/gen_proto.py','--check']),
        ('final-ruff',[sys.executable,'-m','ruff','check','src','tests','scripts/p0_validate.py']),
        ('final-mypy',[sys.executable,'-m','mypy','--config-file','mypy.ini','src']),
        ('final-pytest',[sys.executable,'-m','pytest','-q','-ra','--junitxml='+str(OUT/'final-pytest.xml')]),
    ]
    report=[]
    for name, command in steps:
        started=time.monotonic()
        row=dict(name=name,command=command,started=datetime.now(timezone.utc).isoformat())
        print('START',name,flush=True)
        with (OUT/(name+'.log')).open('x',encoding='utf-8') as log:
            result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        row.update(exit_code=result.returncode,seconds=time.monotonic()-started,finished=datetime.now(timezone.utc).isoformat())
        report.append(row)
        (OUT/'final-steps.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print('END',name,row['exit_code'],round(row['seconds'],2),flush=True)
    after=fingerprints()
    (OUT/'final-source-after.json').write_text(json.dumps(after,indent=2),encoding='utf-8')
    changed=[key for key in sorted(before.keys()|after.keys()) if before.get(key)!=after.get(key)]
    (OUT/'final-source-changed.json').write_text(json.dumps(changed,indent=2),encoding='utf-8')
    print('SOURCE_CHANGED',changed,flush=True)


if __name__=='__main__':
    main()
