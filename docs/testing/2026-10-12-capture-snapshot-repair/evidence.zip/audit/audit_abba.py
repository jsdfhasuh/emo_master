"""Independent, read-only audit of one fixed export-credit ABBA run."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
manifest = json.loads((root / 'evidence.json').read_text(encoding='utf-8'))
summary = {key: manifest[key] for key in ('head', 'configuration', 'measurement_status', 'performance_status', 'source_stable')}
summary['source_digest'] = manifest['source_after']['digest']
summary['arms'] = []
for index, mode in enumerate(('off', 'on', 'on', 'off')):
    directory = root / f'trial-{index}-credit-{mode}'
    trial = json.loads((directory / 'trial.json').read_text(encoding='utf-8'))
    outcomes = trial['observed_result_outcomes']
    item = dict(index=index, observer=mode, job_status=trial['job_status'], export=trial['export'],
                trial_sha256=hashlib.sha256((directory / 'trial.json').read_bytes()).hexdigest(),
                qt_platform=trial['qt_platform'], pace=trial['pace'], cleanup_errors=trial['cleanup_errors'],
                export_errors=trial['export_errors'], supervisor_errors=trial['supervisor_errors'],
                available=sum(row['source_outcomes']['image']['state'] == 'AVAILABLE' for row in outcomes.values()),
                unobserved=sorted(set(range(1, 97)) - {row['ordinal'] for row in outcomes.values()}),
                unavailable=[dict(ordinal=row['ordinal'], **row['source_outcomes']['image']) for row in outcomes.values()
                             if row['source_outcomes']['image']['state'] != 'AVAILABLE'])
    item['consumers'] = [{key: consumer.get(key) for key in ('total_record_count', 'unique_received', 'unique_decoded',
        'unique_applied', 'missing_measured_ordinals', 'missing_decoded_ordinals', 'missing_applied_ordinals', 'errors')}
        for consumer in trial['consumers']]
    item['ui'] = [{key: window.get(key) for key in ('unique_committed', 'unique_painted', 'missing_committed_ordinals',
        'missing_painted_ordinals')} for window in trial['ui']]
    samples = trial['resource_samples']
    item['reservation_peak'] = {key: max(row[key] for row in samples) for key in
        ('total_reserved', 'shared_capacity', 'export_reserved', 'limit')}
    item['process_peak_rss'] = {}
    for sample in trial['sampler']['samples']:
        for role, values in sample['processes'].items():
            if values.get('status') == 'OBSERVED':
                item['process_peak_rss'][role] = max(item['process_peak_rss'].get(role, 0), values['peak_rss_bytes'])
    item['owner_retirement_verified'] = manifest['trials'][index]['watchdog'].get('owner_retirement_verified')
    if mode == 'on':
        trace = json.loads((directory / 'export-credit.json').read_text(encoding='utf-8'))
        groups = defaultdict(dict)
        for row in trace['rows']:
            if 'result_key' in row:
                key = tuple(row.get(field) for field in ('pool_id', 'job_id', 'result_key', 'source_id', 'slot', 'lane'))
                groups[key].setdefault(row['stage'], []).append(row)
        proved, issues = 0, []
        phases = ('parent.snapshot_recv', 'parent.credit_release', 'parent.pipe_recv', 'parent.export_callback')
        for identity, stages in groups.items():
            if not all(len(stages.get(phase, [])) == 1 and stages[phase][0]['outcome'] == 'OK' for phase in phases):
                issues.append(dict(identity=identity, reason='missing_or_duplicate_phase'))
                continue
            copy, release, finish, callback = (stages[phase][0] for phase in phases)
            if copy['end_ns'] <= release['start_ns'] <= release['end_ns'] <= finish['start_ns'] <= finish['end_ns'] <= callback['start_ns']:
                proved += 1
            else:
                issues.append(dict(identity=identity, reason='invalid_order'))
        item['snapshot_release_completion_order'] = dict(proved=proved, issues=issues)
        item['export_trace'] = trial['export_credit_trace']
        item['capture_trace'] = trial['capture_credit_trace']
    summary['arms'].append(item)
output = Path(sys.argv[2])
output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False))
