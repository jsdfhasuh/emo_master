from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path(r'C:/Users/jsdfhasuh/.codex/worktrees/abc7ae-acceptance-repair/emo_master')
local = Path(r'C:/Users/jsdfhasuh/.codex/tmp/cap-snapshot')
abba = local.parent / 'csnap-abba'
baseline = local.parent / 'ci-2920939'
destination = repo / 'docs/testing/2026-10-12-capture-snapshot-repair'
audit = json.loads((local / 'abba-audit.json').read_text(encoding='utf-8'))
validation = dict(base_sha='29209392b37bd0b95df511f0c2ca89c9b03f058a',
    recorded_at=datetime.now(timezone.utc).isoformat(),
    environment='Windows / Python 3.10 conda emo_master; pytest offscreen; ABBA native windows Qt',
    baseline_ci={'run': 38244847162, 'status': 'INVALID',
        'artifact_json_sha256': '3f96beb3a912b91906e4bc7f824d1f43b1874727f659b7aa79a21366ee93ee8a'},
    tests=[dict(name='deterministic baseline', failed=1, passed=0, file='tests/before.log'),
           dict(name='initial focused', passed=122, failed=1, skipped=1, subtests_passed=12, file='tests/focused.log'),
           dict(name='first broad attempt', status='ABORTED_TEST_HARNESS_HANG', file='tests/regression-aborted.json'),
           dict(name='fault and capture', passed=38, failed=0, file='tests/faults.log'),
           dict(name='final presentation/report/guard regression', passed=821, failed=0, skipped=1,
                subtests_passed=26, seconds=378.49, file='tests/regression-final.log')],
    test_count_scope='Overlapping groups; do not sum. Full local pytest NOT_RUN.',
    static={'ruff': 'PASS', 'mypy': 'PASS (411 source files)', 'proto_drift': 'PASS'},
    abba=audit,
    limitations=['Native scripted Qt is not manual Designer/Runtime acceptance.',
        'Local ABBA has complete source/consumer/live coverage, but incomplete Qt commit/paint in arms 1 and 3.',
        'No rerun of ABBA. Measurement INVALID; performance NOT_ASSESSED.',
        'Hosted exact delivery SHA must be checked separately. No full product or historical root cause closure.'])
(destination / 'VALIDATION.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding='utf-8')
files = {}
for name in ('before.log', 'before.xml', 'focused.log', 'focused.xml', 'regression.log',
             'regression-aborted.json', 'faults.log', 'faults.xml', 'regression-final.log',
             'regression-final.xml', 'ruff.log', 'mypy.log', 'proto.log'):
    files['tests/' + name] = local / name
for name in ('audit_abba.py', 'package_evidence.py', 'abba-audit.json', 'abba.log'):
    files['audit/' + name] = local / name
for path in sorted(abba.rglob('*')):
    if path.is_file() and path.suffix in {'.json', '.log'}:
        files['abba/' + path.relative_to(abba).as_posix()] = path
files['baseline-2920939/audit-summary.json'] = baseline / 'audit-summary.json'
files['baseline-2920939/credit-run.log'] = baseline / 'credit-run.log'
files['baseline-2920939/export-credit-public.json'] = baseline / 'artifact/export-credit-public.json'
hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
assert hashes['baseline-2920939/export-credit-public.json'] == validation['baseline_ci']['artifact_json_sha256']
archive = destination / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, path in files.items():
        bundle.write(path, name)
    bundle.writestr('CONTENTS_SHA256.json', json.dumps(hashes, indent=2))
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert all(hashlib.sha256(bundle.read(name)).hexdigest() == digest for name, digest in hashes.items())
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(destination / 'ARCHIVE_SHA256.txt').write_text(f'{digest}  evidence.zip\n', encoding='ascii')
print(json.dumps(dict(archive=str(archive), bytes=archive.stat().st_size, files=len(files), sha256=digest,
                     source_digest=audit['source_digest'])))
