import sys
from pathlib import Path

if __name__ == '__main__':
    import emo_master
    if sys.argv[1] == 'baseline':
        from emo_master.ui.presentation import images
        exec(compile(Path(__file__).with_name('original_images.py').read_text(), '<baseline images.py>', 'exec'), images.__dict__)
    import pytest
    raise SystemExit(pytest.main(sys.argv[2:]))
