#!/bin/bash
R=/workspace/shared/emo-display-5410737-acceptance-20261013
cd "$R/source" || exit 1
unset QT_QPA_PLATFORM
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
export XDG_CONFIG_HOME="$R/config" XDG_CACHE_HOME="$R/cache" XDG_DATA_HOME="$R/data"
{ date -u; cat /etc/debian_version; uname -m; echo DISPLAY=$DISPLAY; xrandr --current; xfconf-query -c xsettings -p /Xft/DPI; ps -eo pid,lstart,args; } > "$R/evidence/environment/abba-desktop-before.txt" 2>&1
"$R/venv/bin/python" scripts/r3_export_credit_control.py --output "$R/evidence/abba" --qt-platform xcb > "$R/evidence/abba.log" 2>&1 &
echo $! > "$R/evidence/abba.pid"
wait $!
echo $? > "$R/evidence/abba-exit.txt"
