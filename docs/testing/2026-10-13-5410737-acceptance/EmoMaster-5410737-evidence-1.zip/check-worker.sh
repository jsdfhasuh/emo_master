#!/bin/bash
R=/workspace/shared/emo-display-5410737-acceptance-20261013
"$R/venv/bin/python" "$R/scripts/check_designer_worker_after_close.py" > "$R/evidence/environment/designer-worker-check-console.txt" 2>&1
