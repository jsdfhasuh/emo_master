#!/bin/bash
R=/workspace/shared/emo-display-5410737-acceptance-20261013
cd "$R/source" || exit 1
unset QT_QPA_PLATFORM
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8 XDG_CONFIG_HOME="$R/designer-config" XDG_CACHE_HOME="$R/designer-cache" XDG_DATA_HOME="$R/designer-data"
"$R/venv/bin/python" scripts/dev.py run-designer --local --check > "$R/evidence/designer-check.log" 2>&1
"$R/venv/bin/python" scripts/dev.py run-designer --local > "$R/evidence/designer.log" 2>&1 &
echo $! > "$R/evidence/designer-launcher.pid"
wait $!
echo $? > "$R/evidence/designer-exit.txt"
