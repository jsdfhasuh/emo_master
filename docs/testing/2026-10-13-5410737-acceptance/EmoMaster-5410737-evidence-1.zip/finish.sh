#!/bin/bash
R=/workspace/shared/emo-display-5410737-acceptance-20261013
"$R/venv/bin/python" "$R/scripts/final_identity_cleanup.py" > "$R/evidence/environment/final-cleanup-console.txt" 2>&1
printf '%s\n' "$?" > "$R/evidence/environment/final-cleanup.exit"
PID=$(cat "$R/evidence/video/ffmpeg.pid")
if [ "$(cat /proc/$PID/comm 2>/dev/null)" = ffmpeg ]; then kill -INT "$PID"; fi
