#!/bin/bash
R=/workspace/shared/emo-display-5410737-acceptance-20261013
ps -eo pid,ppid,lstart,args | grep "$R" | grep -v grep > "$R/evidence/environment/live-processes.txt"
