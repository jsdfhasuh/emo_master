#!/bin/bash
R=/workspace/shared/emo-display-5410737-acceptance-20261013
cd "$R/source" || exit 1
unset QT_QPA_PLATFORM
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
export XDG_CONFIG_HOME="$R/config-qt-test" XDG_CACHE_HOME="$R/cache-qt-test" XDG_DATA_HOME="$R/data-qt-test"
export EMO_DISPLAY_EVIDENCE="$R/evidence/automated/native-artifacts"
"$R/venv/bin/python" -m pytest -v tests/ui/operator_view/test_five_display_sessions.py --junitxml="$R/evidence/automated/native-junit.xml" -o faulthandler_timeout=90 > "$R/evidence/automated/native.log" 2>&1 &
echo $! > "$R/evidence/automated/native.pid"
wait $!
echo $? > "$R/evidence/automated/native.exit"
