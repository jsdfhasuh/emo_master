#!/bin/bash
R=/workspace/shared/emo-display-5410737-acceptance-20261013
SCENARIO=${1:-full-lifecycle}
cd "$R/source" || exit 1
unset QT_QPA_PLATFORM
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
export XDG_CONFIG_HOME="$R/config-native" XDG_CACHE_HOME="$R/cache-native" XDG_DATA_HOME="$R/data-native"
"$R/venv/bin/python" "$R/scripts/observe_display_541_native.py" --source "$R/source" --project "$R/projects/five-while" --data-root "$R/runtime-native" --evidence "$R/evidence/native-$SCENARIO" --plugin-root "$R/source/src/emo_master/plugins/builtins" --plugin-root "$R/projects/five-while/plugins" > "$R/evidence/native-$SCENARIO.log" 2>&1 &
echo $! > "$R/evidence/native-$SCENARIO.pid"
wait $!
echo $? > "$R/evidence/native-$SCENARIO.exit"
