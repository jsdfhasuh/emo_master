#!/bin/bash
R=/workspace/shared/emo-display-5410737-acceptance-20261013
ffmpeg -nostdin -f x11grab -framerate 12 -video_size 1364x1024 -i "$DISPLAY" -c:v libx264 -preset ultrafast -crf 30 -pix_fmt yuv420p "$R/evidence/video/desktop.mkv" > "$R/evidence/video/ffmpeg.log" 2>&1 &
echo $! > "$R/evidence/video/ffmpeg.pid"
