显示订阅与桌面生命周期验收
最终版本 2026-10-13
仓库 jsdfhasuh/emo_master
SHA 5410737a561e1f192ee9a081b3f208c9b27d9886

阅读顺序
1. report/ACCEPTANCE-REPORT.pdf：7页中文结论与边界；同名DOCX为可编辑版本。
2. report/CASE-MATRIX.json：本轮PASS、NOT_RUN与历史FAIL分别列账。
3. report/UI-OPERATIONS.md：真实桌面操作时间线。
4. report/INDEPENDENT-DISPLAY-AUDIT.json：逐编号、身份、退休、图像样本及压缩还原审计。

关键证据（路径相对验收包根目录）
- evidence/automated/software-junit.xml：15 passed，3.44秒。
- evidence/automated/native-junit.xml及CLASSIFICATION.txt：2 passed，11.30秒；实际offscreen，不计真实桌面。
- evidence/native-full-lifecycle/observer.jsonl：真实桌面7 admitted／7 retired。
- evidence/native-close-running/observer.jsonl：真实桌面5 admitted／5 retired。
- evidence/abba/：原四组off/on/on/off，各96含8warmup，全层96覆盖，正式88；performance NOT_ASSESSED。
- evidence/automated/software-artifacts/changing-96.json：变化图像原测试逐像素断言及verified_pixels记录；非全部96张PNG归档，也非旧历史根因证明。
- evidence/environment/final-process-check.json：实际桌面检查28个已跟踪PID均absent。
- evidence/environment/designer-worker-final-check.json：追加确认Designer worker20496不存在。
- evidence/environment/designer-jobs-readonly.json与final-git-projects.json：Job COMPLETED；正式Run同步保存独立副本revision1变2，语义不变、原范例未变。
- evidence/screenshots/：001至021真实桌面截图。
- evidence/video/desktop.mkv：1202秒，38,874,822字节，SIGINT闭合且ffprobe可读；没有独立wait退出码，不声称ffmpeg exit0。

判定边界
旧8c A02全96显示覆盖FAIL、W01历史FAIL记录原样保留；Windows捕获稳定性继续OPEN。本轮五路场景PASS不构成全产品、真实设备、D01–D08整套、DPI矩阵或32Job64流性能证书。Windows精确SHA Actions由Codex负责，本轮未查询。
共享第二窗与断流按钮是醒目标记的辅助／故障注入入口，不判为原生产品入口。两个Qt窗共享consumer0，另有独立consumer1。
资源在close返回、事件循环返回和事后OS退出三个时点分别核对；不能把取消等同退休，不能声称事件循环返回时所有尾进程已消失。直接关闭没有close后supervisor owns=false独立采样。

开发历史参考
source/docs/testing/2026-10-13-display-subscriptions/REPORT.md与CONTRACT.md只提供历史和契约背景，不作本轮执行结果。原首失败不得用本轮PASS冲销。

校验
report/REPORT-SHA256.json列出本报告四份交付文件的字节数及SHA256；完整证据包清单由归档环节另列。不要将report/draft、渲染中间文件或构建脚本作为最终报告附件。
