# 5410737 真实桌面操作记录
所有时间为本轮工具观测UTC；实际产品时间文本可能系统UTC+1。非精密性能计时。

- 05:38–05:41：新独立source固定5410737、Python3.10.22环境、docs读取；uv默认缓存目录只读导致环境命令失败，改独立UV_CACHE_DIR后安装完成。未启动产品的失败不归产品FAIL。
- 05:42：开始本轮录屏。新版CUA绑定窗paste/typeText在Xfce终端返回“window does not expose a Paste action”，用受支持原生按键输入命令，未修改产品。
- 05:43–05:45：原ABBA四组独占运行，两个真实Qt窗可见，截图001/002；原完整日志与四组trial保留。未自动重试。性能NOT_ASSESSED。
- 05:45：新Runtime PID17670，独立项目、dataRoot。误点选择工程一次打开picker，Escape取消未加载其他工程。运行目标对话框真实勾选四个其余-run，加默认main-run，共五入口，未选内部body。截图003。
- 05:46–05:47：点开始，五实际Job均RUNNING，逐tab main/second/flow3/flow4/flow5查看完整正确样图与结果身份，截图004–008；服务端5长流、工作峰值2、无拒绝。
- 05:47：按固定主→二→三→四→五顺序四轮20次切tab。截图009；admitted仍5，未新建Session。
- 05:48：醒目标记辅助控制窗打开当前flow5的第二RuntimePages，复用原hub/session，无新networkconsumer；截图010。通过辅助按钮关闭共享窗，再取消当前原stream（故障注入）。产品自动建立新流，active回5，admitted6/retired1，截图011。没有把辅助按钮算产品原生入口。
- 05:48–05:49：主tab点停止流程，其余四仍RUNNING；截图012–014。主tab点开始流程生成新Job，截图015。再点全部停止，六个历史/新Job最终ABORTED、ownsJobResources全部false；截图016。
- 05:49–05:52：绑定client窗的Alt+F4/Alt+Space未触发窗口管理器，不记为产品关闭。查当前工具正式文档后使用其支持的Sky全桌面输入，05:52:59点可见Runtime标题栏X（截图017），产品进入正在停止并退出。关闭exit0，7admitted/7retired、active/work/byJob/cleanup0，Session线程停、exporter停、资产cache/readers/lease0。
- 05:53：同本轮dataRoot新Runtime PID19321重新打开。辅助控制窗直接关闭不用。再次GUI选择五-run并开始，五个新Job均RUNNING、Runtime instance不同。
- 05:55：运行中不点停止，直接标题栏X，截图018/019分别关闭前和过程中；产品退出exit0，5admitted/5retired，各资源最终归零。close后supervisor ownsJobResources没有另外直接采样，不能凭零进程改写为该内部断言已执行。
- 05:56：原两GUI测试从桌面终端执行，但仓库conftest设置offscreen，实际2passed11.30s，按offscreen记账，不替代上述真实操作、不重跑取绿。
- 05:57–06:00：原入口新Designerlauncher20464/实际embeddedRuntime20465，打开原01独立副本，点击正式运行，Job d26dfad7-bee5-4cb4-933a-38e959ebaca8完成，真实结果value7，截图020/021。正式运行按产品_syncRuntimeProjectBeforeRun保存副本revision1→2；原始范例hash未变，副本节点/参数/边/坐标语义一致。不是独立调试D01-D08全套复验。标题栏X正常关闭exit0。
- 06:02–06:03：通过实际桌面终端执行只读最终PID检查，28个追踪PID均absent；之后从Designer只读DB发现worker20496，独立追加检查亦absent。两个resource_tracker在各eventloop_return时尚存在，只有后置检查才证明退出。
- 06:02：只对本轮录像ffmpeg17221发送SIGINT。ffprobe完整读取1202秒/38,874,822字节，日志正常signal2。没有父shell wait退出码，不捏造exit0。

本轮没有发现新的产品失败；环境/工具错误仍保留。原8c W01/A02历史证据不改判，Windows/全产品/性能/32Job64流容量/生产设备均不外推。
