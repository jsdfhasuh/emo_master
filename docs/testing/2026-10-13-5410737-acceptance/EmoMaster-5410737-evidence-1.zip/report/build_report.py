from pathlib import Path
import json, hashlib
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
B=Path(__file__).resolve().parents[1]; O=B/'report'; O.mkdir(exist_ok=True)
SHA='5410737a561e1f192ee9a081b3f208c9b27d9886'
doc=Document(); sec=doc.sections[0]; sec.page_width=Inches(8.5); sec.page_height=Inches(11); sec.top_margin=sec.bottom_margin=Inches(.7); sec.left_margin=sec.right_margin=Inches(.75)
for n in ['Normal','Title','Heading 1','Heading 2','Caption','Header','Footer']:
 s=doc.styles[n]; s.font.name='Noto Sans CJK SC'; s.font.color.rgb=RGBColor(0,0,0); s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC')
doc.styles['Normal'].font.size=Pt(10.5); doc.styles['Normal'].paragraph_format.space_after=Pt(6); doc.styles['Normal'].paragraph_format.line_spacing=1.10
doc.styles['Title'].font.size=Pt(24);doc.styles['Heading 1'].font.size=Pt(17);doc.styles['Heading 2'].font.size=Pt(12)
h=sec.header.paragraphs[0]; h.text='emo_master  固定提交独立 Debian 验收'; h.style='Caption'
f=sec.footer.paragraphs[0]; f.alignment=2
f.add_run('2026-10-13  |  证据已核验  |  ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');f._p.append(fld)
def p(t):doc.add_paragraph(t)
def head(t):
 h=doc.add_heading(t,1);h.paragraph_format.page_break_before=True
def sub(t):doc.add_heading(t,2)
def page():pass
def table(headers, rows, widths):
 t=doc.add_table(rows=1,cols=len(headers));t.autofit=False
 for i,w in enumerate(widths):t.columns[i].width=Inches(w)
 for i,x in enumerate(headers):t.rows[0].cells[i].text=x
 for row in rows:
  for c,x in zip(t.add_row().cells,row):c.text=str(x)
 for ri,row in enumerate(t.rows):
  for ci,c in enumerate(row.cells):
   c.width=Inches(widths[ci]);tcPr=c._tc.get_or_add_tcPr(); borders=OxmlElement('w:tcBorders')
   for edge in ['top','left','bottom','right']:
    e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
   tcPr.append(borders);mar=OxmlElement('w:tcMar')
   for edge in ['top','left','bottom','right']:
    e=OxmlElement('w:'+edge);e.set(qn('w:w'),'85');e.set(qn('w:type'),'dxa');mar.append(e)
   tcPr.append(mar)
   if ri==0:
    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E8EEF4');tcPr.append(sh)
   for pp in c.paragraphs:
    pp.paragraph_format.space_after=Pt(2);pp.paragraph_format.line_spacing=1.05
    for r in pp.runs:r.font.size=Pt(9);r.bold=ri==0
  pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
 t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
 return t
def image(name,caption,width=6.8):
 file=B/'evidence/screenshots'/name
 if file.exists():doc.add_picture(str(file),width=Inches(width));doc.add_paragraph(caption,'Caption')
doc.add_paragraph('显示订阅与桌面生命周期验收报告','Title')
p('本轮独立复验 · 2026年10月13日 · 最终验收报告')
sub('结论与适用范围')
p('本轮固定提交的五个真实 DisplaySession 桌面生命周期场景通过；原 ABBA 四组在本次采集窗口内，全 96 个编号从源结果到双消费者接收、解码、live，再到双 Qt 窗口 commit 和 paint 均完整。结论只覆盖下述场景和证据，不是全产品发布许可或生产设备验收。')
p('本轮原始 ABBA measurement=VALID，performance=NOT_ASSESSED。静态输入的 SHA 与解码一致性不能证明逐帧变化图像的新鲜度；变化图像完整像素核对由另一组确定性软件测试提供。')
table(['证据类型','本轮结果','结论边界'],[
 ['软件与故障注入','PASS · 15 passed / 3.44s','真实网络、配额、退休及 live 决策'],
 ['Qt 自动化','PASS · 2 passed / 11.30s','实际 offscreen，不计真实桌面'],
 ['真实桌面鼠标操作','PASS · 两次真实桌面场景','xcb 可见窗口；辅助入口单列'],
 ['原负载 ABBA','PASS · 4组各96/96','正式9–96各88；性能不评定'],
 ['Designer 基础链','PASS · 正式运行完成并关闭','不等于 D01–D08 整套重跑'],
 ['历史与未覆盖','FAIL / OPEN / NOT_RUN 保留','旧8c A02缺号仍FAIL']],[1.5,2.15,3.15])
sub('源码身份')
p('仓库：jsdfhasuh/emo_master\n固定提交：'+SHA+'\n环境：Debian 13.6，Python 3.10.22，PySide2 5.15.2.1。启动前工作树干净。Windows 精确 SHA 的 Actions 由 Codex 负责，本轮不查询或替代其结论。')
p('本报告与 CASE-MATRIX.json、README 一起阅读。源树内 REPORT.md 和 CONTRACT.md 是开发历史及契约参考，不是本轮独立执行结果。')
page();head('1 验证方法与证据分账')
sub('执行约束')
p('独立固定提交检出；不修改产品源码、原测试断言、原分母或期限。ABBA 按 off/on/on/off 原顺序只跑一轮，输入为原 seed20260926 的 1920×1080×3 静态图，计划 5Hz，96 次含 8 次预热。保留全部 1–96；正式区间单列 9–96。')
p('原 export 和 asset RPC deadline 均 500ms，客户端期限仍为原约束；没有通过增加等待、减少输入或扩大额度换取通过。显示工作线程仍为 2；每 Job 两个消费者、最多 32 Job／64 流是安全上界，不构成该规模性能证书。')
sub('真实桌面与观察器')
p('可见 xcb 产品窗口由桌面鼠标操作：选择五个 run 目标、开始、逐 tab、快切、单停、重启、全停和标题栏 X 关闭。仓库外 helper 每 100ms 被动读取有界记录；不创建新的网络 consumer，不改变 Runtime 行为或额度。')
p('admission 在 server loop 读取；资产计数在锁内纯读，不调用会触发回收的 stats。保留退休对象引用只延后垃圾回收，不阻止显式 close。每 Job 最多保存 5 张 PNG；两场景共35张样本经独立解码，shape／dtype／像素SHA匹配，但不是全部运行帧的像素证明。')
sub('辅助操作醒目标识')
p('共享第二窗口与断流重连没有原生产品入口。本轮通过明确标记的辅助控制窗鼠标按钮执行：共享窗复用现有 hub/session；取消现有 stream 属于故障注入。共享窗可能自然增加 image demand。两项只证明相关机制，不判为产品入口易用性通过。')
sub('首失败和历史记录')
p('本轮未观察到新的产品首失败。初始化 uv 只读 cache 与工具绑定 Alt+F4 不生效属于辅助环境问题；分别使用可写 cache、实际桌面标题栏 X 完成操作，原日志保留，没有重跑择优。')
p('native-automated.sh 的文件名不代表真实桌面。CLASSIFICATION.txt 与产物平台字段确认该 2 项 Qt pytest 使用 offscreen，单列补充。源码内开发阶段失败、Windows 失败和原 8c 验收失败继续保留。')
page();head('2 五路桌面正常生命周期')
p('真实桌面主进程 PID 17670。五路 While Job 各建立实际 DisplaySession；逐页查看与 20 次快速切 tab 后继续运行。截图 003–017 与原始 observer.jsonl 联合取证。')
table(['操作','观察结果','分类'],[
 ['五目标开始与逐页','五路运行；逐5 tab检查','PASS · 产品鼠标'],
 ['20次快切','未为切页增建consumer','PASS · 产品鼠标'],
 ['打开并关闭第二窗','共享原session/hub，无新consumer','PASS · 辅助入口'],
 ['取消原stream再连','原流退休，重连新增admission','PASS · 故障注入'],
 ['单停 main','其余4路继续；主路停止','PASS · 产品鼠标'],
 ['重启 main','新Job身份；其他4路不受影响','PASS · 产品鼠标'],
 ['全停再标题栏X关闭','7 admitted对应7 retired；0 rejected','PASS · 产品鼠标']],[1.65,3.55,1.6])
image('013-main-stopped-others-running.jpg','截图 013：单停 main 后其余四路继续。原图可在证据目录核对。',4.5)
p('7 次 admission = 初始 5 路 + 一次断流重连 + 一次主路新 Job 重启。工作并发峰值 2。原始订阅身份逐项对应退休，不能仅用 Job RUNNING 或最后一张快照代替订阅健康。')
page();head('3 运行中关闭与资源退休')
p('第二场景使用新的真实桌面进程 PID 19321，复用已关闭的同一 dataRoot。五路均 RUNNING 后直接点击标题栏 X。5 admitted 对应 5 retired，0 rejected，工作峰值 2，退出码 0。')
table(['观测时点','已取得证据','限制'],[
 ['Runtime close返回','active/byJob/work/cleanup归零；assets/cache/readers/lease=0；exporter进程及线程停止','资产为锁内纯读'],
 ['Session最终记录','保留的Session线程全部停止','有界记录不等于永久审计'],
 ['Qt事件循环返回','两场景exit0、window_done','各有1个resource_tracker尚存活'],
 ['最终独立进程检查','正式28个跟踪PID均absent，范围内产品进程为空','含两个resource_tracker的OS退出']],[1.3,3.9,1.6])
p('直接关闭场景最后一次 Job supervisor 样本仍处于关闭前 RUNNING／owns=true。没有 close 后单独 owns=false 采样，不能把这一字段虚报为已观测归零；关闭完成由 Runtime.close、独立资源计数和最终操作系统进程证据分别支持。')
image('018-five-running-before-direct-close.jpg','截图 018：五路运行中，随后使用实际标题栏 X 关闭。',4.5)
p('正常全停路径与运行中直接关闭路径分别验证。取消请求本身不等于退休；结论以回调、在途工作、迭代器 close 和响应生命周期结束后的退休记录为准。')
page();head('4 ABBA 全编号链路与图像边界')
p('本次原负载四组均完成，measurement=VALID。以下数字是编号集合覆盖，不是事件行数；重复 commit/paint 不能增加覆盖分子。两个 Qt 窗口共享 consumer0 的 hub，consumer1 是另一个独立网络消费者。')
table(['组别','源结果','双端收解live','双窗commit paint','正式9–96'],[
 ['trial0 off','96/96','各96/96','各96/96','各88/88'],
 ['trial1 on','96/96','各96/96','各96/96','各88/88'],
 ['trial2 on','96/96','各96/96','各96/96','各88/88'],
 ['trial3 off','96/96','各96/96','各96/96','各88/88']],[1.05,1,1.65,1.75,1.35])
p('全部 1–96 source AVAILABLE／COMPLETE；owner、Runtime／Job／scope／result 身份一致，无未知 UI key、缺号或清理错误。客户端容量128、Qt容量256，本次没有撞到保留上限。当前 ABBA 全为 APPLIED，没有 SUPERSEDED。')
sub('确定性变化图像另列')
p('changing-96 软件场景使用 96 张变化内容，原测试对两个真实网络消费者逐张断言完整像素及 owner／hash；现存产物保留身份与 verified_pixels 编号，未保存全部96张PNG，未做离线96张重解码。故意延后 consumer0 的 ordinal2，在高位 ordinal3 已接受后释放：consumer0 为95 APPLIED + 1 SUPERSEDED；consumer1 为96 APPLIED。旧2不覆盖新3，决策时 high、generation、Runtime／Job／scope 身份均有直接记录。')
p('这是可控故障注入，对当前 latest 防倒灌契约提供直接证据。它不是旧 8c 历史缺帧根因证明，也不把旧 A02 全96显示要求的 FAIL 改为 PASS。静态 ABBA 的解码／SHA 校验与变化图像全像素校验不能混写。')
sub('报告压缩可逆性')
p('独立审计核对 768 条 ABBA 与 192 条注入记录，共960条，压缩展开后身份与决策字段逐格相同。source_outcomes／image_refs 在脱敏报告中为 SHA 摘要，只能关联原始 raw 核对，不能从摘要逆解原字典。两个 on 组各2306条 parent 记录的身份、精确时钟、索引和 null 逐格还原一致。此结论只证明表示无损，不额外证明捕获性能。')
p('原始来源：evidence/abba/*/trial.json、evidence/automated/software-artifacts/changing-96.json；汇总核对：report/INDEPENDENT-DISPLAY-AUDIT.json。')
page();head('5 Designer 基础链与未覆盖范围')
p('Designer 原 --local --check 自检通过后，新进程20465真实打开独立01工程副本，点击正式运行。Job d26dfad7-bee5-4cb4-933a-38e959ebaca8 为 COMPLETED，主输出 value=7；实际标题栏关闭，exit0。')
image('021-designer-completed.jpg','截图 021：Designer 正式运行完成，主输出 value=7。',4.7)
p('正式 Run 按原源码同步保存工程，独立副本 revision 从1变2、文件hash改变；nodes／params／edges／positions语义一致，原范例未改。此项不是独立调试隔离污染测试；不能宣称副本字节完全不变。只读DB确认worker PID20496，追加桌面末验确认其 /proc 已不存在。')
table(['项目','本轮状态','解释'],[
 ['D01–D08完整矩阵','NOT_RUN','未整套人工重跑，基础链不替代'],
 ['SQLite／O20专项','NOT_RUN','本轮显示订阅范围以外'],
 ['真实生产设备与系统DPI矩阵','NOT_RUN','无设备、无跨DPI矩阵结论'],
 ['32Job／64流性能','NOT_RUN','只有安全配额上界及定向测试'],
 ['Windows精确SHA Actions','NOT_RUN','由Codex负责，本轮未查询'],
 ['发布、部署、PR合并','NOT_RUN','未执行，也未授予上线许可']],[2.65,1.2,2.95])
page();head('6 保留问题与证据阅读顺序')
sub('历史 FAIL 和 OPEN')
p('历史 8c A02 trial0 全96显示覆盖仍为 FAIL：consumer0 的 ordinal2 解码后未进入 live，双窗共享 consumer0；旧记录缺少决策瞬间的 high／generation，supersession 只能作为历史推断。当前全96通过不覆盖、不撤销这份历史失败。')
p('历史 W01 五路订阅失败记录保持原样；本轮固定 SHA 的五路场景已通过，结论限定在本次场景，不扩大成全产品保证。Windows 历史捕获稳定性问题继续 OPEN；源码内报告所述额度拒绝、超时、报告尺寸失败及本地 INVALID 原记录不被本次 Debian 结果冲销。')
sub('证据入口')
table(['路径','用途'],[
 ['CASE-MATRIX.json','按案例、证据类型、状态及边界检索'],
 ['evidence/automated/','15项软件与2项offscreen Qt；JUnit及原始产物'],
 ['evidence/native-*/observer.jsonl','真实桌面逐时观察、订阅与资源退休'],
 ['evidence/screenshots/ 与 video/','真实可见操作截图及录屏'],
 ['evidence/abba/','四组原始96链路与parent记录'],
 ['report/INDEPENDENT-DISPLAY-AUDIT.json','逐编号、身份、压缩还原独立核对'],
 ['evidence/environment/final-process-check.json','实际桌面终端末验28个PID及产品进程范围']],[3.15,3.65])
sub('判定说明')
p('PASS 表示指定观察窗口和案例的断言有对应证据；FAIL 表示原要求未满足且保留；NOT_RUN 表示本轮没有执行，不视为通过。OPEN 单列为历史问题未关闭，不与本轮案例总数相加。不同套件、共享窗口和故障注入之间可能重叠，不把数量累加为独立覆盖规模。')
p('最终桌面检查28个跟踪PID均不存在，Designer worker20496追加末验亦不存在。录屏1202秒、38,874,822字节，SIGINT闭合后ffprobe可读；未取得独立ffmpeg wait退出码。交付正文使用相对路径，不含宿主标识或凭据。')
doc.core_properties.title='显示订阅与桌面生命周期验收报告';doc.core_properties.author='';doc.core_properties.last_modified_by='';
for el in list(doc.styles.element.iter(qn('w:pBdr')))+list(doc.element.iter(qn('w:pBdr'))):el.getparent().remove(el)
doc.save(O/'ACCEPTANCE-REPORT.docx')
cases=[]
def case(i,title,status,typ,evidence,boundary):cases.append(dict(id=i,title=title,status=status,evidence_type=typ,evidence=evidence,boundary=boundary))
case('S01','原软件专项15项','PASS','software_integration_fault_injection',['evidence/automated/software.log','evidence/automated/software-junit.xml'],'15 passed 3.44s；不是人工桌面')
case('Q01','原Qt自动化2项','PASS','offscreen_qt',['evidence/automated/native-junit.xml','evidence/automated/CLASSIFICATION.txt'],'2 passed 11.30s；launcher名称不代表native')
case('N01','五路真实桌面生命周期','PASS','native_xcb_mouse',['evidence/native-full-lifecycle/observer.jsonl'],'7 admitted/7 retired；0 rejected；辅助操作另列')
case('N02','运行中标题栏直接关闭','PASS','native_xcb_mouse',['evidence/native-close-running/observer.jsonl','evidence/environment/final-process-check.json'],'5 admitted/5 retired；正式28PID fence全部absent；无close后supervisor owns独立采样')
case('AUX01','共享窗与断流重连','PASS','auxiliary_and_fault_injection',['evidence/native-full-lifecycle/observer.jsonl'],'辅助控制并非原生产品入口；共享consumer不增加网络consumer')
case('A02-CURRENT','原ABBA四组全编号链路','PASS','original_load_native_qt',['evidence/abba/evidence.json','report/INDEPENDENT-DISPLAY-AUDIT.json'],'每组96含8warmup，正式88；静态图；performance NOT_ASSESSED')
case('L01','变化96及确定性替代','PASS','software_deterministic_fault_injection',['evidence/automated/software-artifacts/changing-96.json'],'双端全像素；consumer0 ordinal2 SUPERSEDED；非历史根因证明')
case('R01','决策及parent压缩可逆性','PASS','offline_evidence_audit',['report/INDEPENDENT-DISPLAY-AUDIT.json'],'960决策行；2×2306 parent行；不代表性能合格')
case('D-BASIC','Designer基础无设备链','PASS','native_xcb_mouse',['evidence/screenshots/020-designer-open.jpg','evidence/screenshots/021-designer-completed.jpg','evidence/environment/designer-jobs-readonly.json','evidence/environment/final-git-projects.json','evidence/environment/designer-worker-final-check.json'],'Job完成value7，标题栏关闭exit0；副本保存revision2，不替代D01-D08')
for i,t in [('D01-D08','完整Designer矩阵'),('O20','SQLite与O20专项'),('DEVICE-DPI','真实设备与DPI矩阵'),('SCALE','32Job64流性能'),('WINDOWS','Windows精确SHA Actions'),('RELEASE','发布部署与合并')]:case(i,t,'NOT_RUN','not_run',[],'本轮无此结论')
case('H-A02','旧8c全96显示覆盖','FAIL','historical',['source/docs/testing/2026-10-13-display-subscriptions/CONTRACT.md'],'原缺号FAIL保留；不计本轮新失败')
m=dict(schema_version=1,freeze_status='FINAL',repository='jsdfhasuh/emo_master',sha=SHA,date='2026-10-13',cases=cases,historical_open=['旧8c缺帧历史根因缺少决策瞬间直证','Windows捕获稳定性未由本轮关闭'],pending_freeze=[])
(O/'CASE-MATRIX.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
(O/'README.txt').write_text('显示订阅与桌面生命周期验收\n证据已核验\n仓库 jsdfhasuh/emo_master\nSHA '+SHA+'\n\n先读 ACCEPTANCE-REPORT.pdf；可编辑版本为同名DOCX。CASE-MATRIX.json逐项索引。\n所有证据相对路径均相对于验收包根目录。\n最终Designer、PID fence、录像和文件SHA清单待冻结补齐。\n历史8c A02 FAIL与Windows OPEN保留；2个Qt pytest实际offscreen，不计真实桌面。\n')
print(O)
