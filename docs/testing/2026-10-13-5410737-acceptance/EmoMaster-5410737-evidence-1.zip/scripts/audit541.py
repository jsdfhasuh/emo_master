import json,hashlib,collections,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/workspace/shared/emo-display-5410737-acceptance-20261013'); E=root/'evidence'
out={'sha':'5410737a561e1f192ee9a081b3f208c9b27d9886','trials':[],'native':[],'xml':{}}
def cover(vals):
 s=set(vals);return {'count_1_96':len(s&set(range(1,97))),'missing_1_96':sorted(set(range(1,97))-s),'count_9_96':len(s&set(range(9,97))),'missing_9_96':sorted(set(range(9,97))-s),'unexpected':sorted(s-set(range(1,97)))}
for p in sorted(E.glob('abba/**/trial.json')):
 d=json.loads(p.read_text()); km={k:v['ordinal'] for k,v in d['observed_result_outcomes'].items()}; cs=d['consumers']; us=d['ui']; errors=[]
 t={'trial':p.parent.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source':cover(km.values()),'source_available_complete':all(v['status']=='COMPLETE' and set(v['source_outcomes'])==set(d['expected_source_ids']) and all(x['state']=='AVAILABLE' for x in v['source_outcomes'].values()) for v in d['observed_result_outcomes'].values()),'consumers':[],'ui':[],'retention':d['record_retention'],'cleanup_errors':d['cleanup_errors']}
 for i,c in enumerate(cs):
  rows=c['raw_records']; supers=[]
  for r in rows:
   if km.get(r['key'])!=r['ordinal']:errors.append(['keyordinal',i,r['ordinal']])
   if r['job_id']!=d['job'] or r['decision_job_id']!=r['job_id'] or r['decision_runtime_instance_id']!=r['runtime_instance_id'] or r['task_generation']!=r['decision_generation']:errors.append(['identity',i,r['ordinal']])
   if set(r['source_outcomes'])!=set(d['expected_source_ids']):errors.append(['sources',i,r['ordinal']])
   for source,ref in r['image_refs'].items():
    if ref['owner_result_key']!=r['key'] or ref['sha256']!=d['input_sha256']:errors.append(['ownerhash',i,r['ordinal']])
   if r['live_decision']=='SUPERSEDED':
    h=next((x for x in rows if x['key']==r['high_result_key']),None)
    supers.append({'row':r,'high_row':h,'decision_after_high_receive_ms':(r['decoded_ns']-h['received_ns'])/1e6 if h else None})
    if not h or h['ordinal']!=r['high_ordinal'] or h['scope_id']!=r['scope_id'] or h['received_ns']>r['decoded_ns'] or not r['high_ordinal']>r['ordinal']: errors.append(['supersession',i,r['ordinal']])
  t['consumers'].append({'consumer':i,'records':len(rows),'received':cover(r['ordinal'] for r in rows if r.get('received_ns')),'decoded':cover(r['ordinal'] for r in rows if r['decoded']==['image'] and not r['failures']),'live':cover(r['ordinal'] for r in rows if r['applied_to_live'] and r.get('model_ns')),'decisions':dict(collections.Counter(r['live_decision'] for r in rows)),'superseded':supers,'errors':c['errors']})
 for i,u in enumerate(us):
  rows=u['raw_records'];t['ui'].append({'window':i,'records':len(rows),'committed':cover(km[r['key']] for r in rows if r.get('gui_ns') and r['key'] in km),'painted':cover(km[r['key']] for r in rows if r.get('paint_ns') and r['key'] in km),'unknown_keys':[r['key'] for r in rows if r['key'] not in km]})
 t['identity_errors']=errors;out['trials'].append(t)
for p in sorted(E.glob('native-*/observer.jsonl')):
 rows=[json.loads(l) for l in p.read_text().splitlines()];events=[r['event'] for r in rows if r['kind']=='admission_event']; admitted=[r['subscriptionId'] for r in events if r['action']=='admitted'];retired=[r['subscriptionId'] for r in events if r['action']=='retired'];sessions={r['key']:r for r in rows if r['kind']=='session_resources'}
 images=[r for r in rows if r['kind']=='displayed_image'];image_errors=[]
 for r in images:
  ref=r['image_ref']; ident=r['result']['identity']
  if ref['ownerResultKey']!=ident['resultKey'] or hashlib.sha256((p.parent/r['derived_png']).read_bytes()).hexdigest()!=r['derived_png_sha256']:image_errors.append(r['derived_png'])
 out['native'].append({'scenario':p.parent.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'admitted':admitted,'retired':retired,'paired':collections.Counter(admitted)==collections.Counter(retired),'rejected':[e for e in events if e['action']=='rejected'],'last_server':next(r for r in reversed(rows) if r['kind']=='server_resources'),'last_assets':next(r for r in reversed(rows) if r['kind']=='assets'),'last_close':next(r for r in reversed(rows) if r['kind']=='runtime_close_return'),'last_sessions':list(sessions.values()),'exit':next(r for r in reversed(rows) if r['kind']=='qt_event_loop_return'),'errors':[r for r in rows if r['kind'] in ['observer_error','auxiliary_action_error','admission_retention_gap']],'auxiliary_actions':[r for r in rows if r['kind']=='auxiliary_action'],'images':len(images),'image_errors':image_errors})
for p in E.glob('automated/*junit.xml'):
 x=ET.parse(p).getroot();out['xml'][p.name]=[s.attrib for s in x.iter('testsuite')]
path=root/'report/INDEPENDENT-DISPLAY-AUDIT.json';path.write_text(json.dumps(out,indent=2));print(path)
for t in out['trials']:
 print(t['trial'],'source',t['source'],'identityErrors',t['identity_errors'])
 for c in t['consumers']:print(' consumer',c['consumer'],c['received']['count_1_96'],c['decoded']['count_1_96'],c['live'],c['decisions'])
 for u in t['ui']:print(' ui',u['window'],'commit',u['committed'],'paint',u['painted'])
for n in out['native']:
 print(n['scenario'],'pair',len(n['admitted']),len(n['retired']),n['paired'],'lastserver',n['last_server'],'assets',n['last_assets'],'threadalive',[(s['job_id'],[t['name'] for t in s['threads'] if t['alive']]) for s in n['last_sessions']],'errors',n['errors'],'images',n['images'],n['image_errors'])
print('xml',out['xml'])
