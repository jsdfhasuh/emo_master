import json,importlib.util,hashlib,time
from pathlib import Path
r=Path('/workspace/shared/emo-display-5410737-acceptance-20261013');e=r/'evidence';p=r/'report/INDEPENDENT-DISPLAY-AUDIT.json';d=json.loads(p.read_text())
spec=importlib.util.spec_from_file_location('report',r/'source/scripts/r3_export_credit_report.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
collections=[]
for t in sorted(e.glob('abba/**/trial.json')):
 j=json.loads(t.read_text());collections.extend((str(t.relative_to(r)),i,x['raw_records']) for i,x in enumerate(j['consumers']))
c=json.loads((e/'automated/software-artifacts/changing-96.json').read_text());collections.extend(('changing-96',i,x) for i,x in enumerate(c['consumers']))
roundtrips=[]
for name,i,rows in collections:
 a=m.expand_live_decisions(m.live_decisions(rows));cols=a['records']['columns']
 for original,packed in zip(rows,a['records']['rows']):
  restored=dict(zip(cols,packed));ident=dict(zip(a['identity_columns'],a['identities'][restored['identity_index']]))
  assert all(original[k]==v for k,v in ident.items())
  assert all(original.get(k)==restored[k] for k in m.DECISION_FIELDS if k not in ['identity_index','source_outcomes_sha256','image_refs_sha256'])
  for k in ['source_outcomes','image_refs']:assert restored[k+'_sha256']==m.digest(m.encoded(original[k]))
 assert len(a['records']['rows'])==len(rows)
 roundtrips.append({'source':name,'consumer':i,'rows':len(rows),'all_identity_decision_cells_and_source_digests_equal':True})
d['compression_roundtrip']=roundtrips
parent=[]
for t in sorted(e.glob('abba/**/export-credit.json')):
 j=json.loads(t.read_text());rows=j['rows'];a=m.expand_parent_rows(m.parent_table(rows)); cols=a['row_columns'];restored={}
 for g in a['groups']:
  identity=dict(zip(a['identity_columns'],g['identity']))
  for packed in g['rows']:
   row=dict(zip(cols,packed));index=row.pop('raw_row_index');row['stage']=a['stage_dictionary'][row['stage']];row['thread_id']=a['thread_id_dictionary'][row['thread_id']]
   if row['aggregate'] is not None:row['aggregate']=dict(zip(a['aggregate_columns'],row['aggregate']))
   restored[index]={**identity,**row}
 for i,row in enumerate(rows):assert all(restored[i][k]==row.get(k) for k in m.IDENTITY+m.PARENT_FIELDS)
 parent.append({'source':str(t.relative_to(r)),'rows':len(rows),'all_cells_identity_clocks_indices_nulls_equal':True})
d['parent_compression_roundtrip']=parent
sup=[]
for i,rows in enumerate(c['consumers']):
 assert [x['ordinal'] for x in rows]==list(range(1,97));assert c['verified_pixels'][i]==list(range(1,97))
 assert all(x['decoded']==['image'] and not x['failures'] and x['image_refs']['image']['owner_result_key']==x['key'] for x in rows)
 for x in rows:
  if x['live_decision']=='SUPERSEDED':
   h=next(y for y in rows if y['key']==x['high_result_key']);assert x['high_ordinal']==h['ordinal']==3 and x['ordinal']==2
   assert all(x[k]==h[k] for k in ['runtime_instance_id','job_id','scope_id','task_generation','decision_generation','decision_job_id','decision_runtime_instance_id'])
   assert x['decoded_ns']>h['received_ns'];sup.append({'consumer':i,'row':x,'high_row':h,'high_received_before_old_decision_ms':(x['decoded_ns']-h['received_ns'])/1e6})
d['deterministic_96']={'denominator':96,'pixel_verification_ordinals_complete':True,'consumer_decisions':[{k:sum(x['live_decision']==k for x in rows) for k in ['APPLIED','SUPERSEDED']} for rows in c['consumers']],'superseded':sup,'not_historical_cause_proof':True}
for n in d['native']:
 rows=[json.loads(l) for l in (e/n['scenario']/'observer.jsonl').read_text().splitlines()]
 n['last_jobs_observation']=next(x for x in reversed(rows) if x['kind']=='jobs')
 n['final_assets']=n['last_close']['assets']
 ids={x['pid'] for x in n['exit']['observed_children']}|{n['exit']['pid']}
 n['post_exit_proc_check']={'checked_unix_ns':time.time_ns(),'rows':[{'pid':pid,'proc_exists':Path('/proc',str(pid),'stat').exists()} for pid in sorted(ids)]}
 n['owns_job_resources_final_observed']=n['scenario']=='native-full-lifecycle'
 n['ownership_observation_note']='Direct-close last jobs sample is pre-close RUNNING; final supervisor ownership not separately sampled. Close success and OS process retirement are distinct evidence.'
p.write_text(json.dumps(d,indent=2));print('decision rows roundtrip',sum(x['rows'] for x in roundtrips),'parent',parent,'supersession delta',sup[0]['high_received_before_old_decision_ms']);print('all tracked proc absent',all(not x['proc_exists'] for n in d['native'] for x in n['post_exit_proc_check']['rows']))
