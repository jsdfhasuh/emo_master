"""Prepare an unchanged five-While synthetic fixture; starts no Runtime or Job."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--project', type=Path, required=True)
    args = parser.parse_args()
    source, project = args.source.resolve(), args.project.resolve()
    if project.exists() or project.is_relative_to(source):
        parser.error('project must be a new directory outside source')
    project.mkdir(parents=True)
    sys.path[:0] = [str(source / 'src'), str(source)]
    from tests.runtime.parallel_workflow_fixture import whileProject
    from examples.runtime_pages_p2 import pluginRoots
    document, roots = whileProject(project, count=5, limit=None)
    plugins = pluginRoots(project)
    info = {'project': str(project), 'roots_to_select_in_gui': roots,
            'plugin_roots': list(plugins), 'default_startup_workflows': document.startupWorkflows(),
            'project_json_sha256': hashlib.sha256((project/'project.json').read_bytes()).hexdigest(),
            'note': 'Unchanged original fixture. No NG judge. No Job started. Select all five -run entries in GUI.'}
    (project/'fixture-provenance.json').write_text(json.dumps(info, indent=2), encoding='utf-8')
    print(json.dumps(info, indent=2))


if __name__ == '__main__':
    main()
