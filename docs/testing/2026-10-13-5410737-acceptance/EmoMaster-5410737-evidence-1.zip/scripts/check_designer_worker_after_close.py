import pathlib,json,sqlite3,datetime,os
r=pathlib.Path('/workspace/shared/emo-display-5410737-acceptance-20261013');p=r/'source/manual_test_workspace/runtime-embedded/emo_master.db';c=sqlite3.connect(f'file:{p}?mode=ro',uri=True);rows=[]
for job,pid in c.execute('select jobId,pid from jobs'):
 rows.append({'jobId':job,'pid':pid,'proc_entry_present':pathlib.Path('/proc',str(pid)).exists()})
c.close();out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_desktop_check_pid':os.getpid(),'workers':rows,'note':'Read-only follow-up in actual desktop process namespace, no Job/test rerun.'};(r/'evidence/environment/designer-worker-final-check.json').write_text(json.dumps(out,indent=2));print(out)
