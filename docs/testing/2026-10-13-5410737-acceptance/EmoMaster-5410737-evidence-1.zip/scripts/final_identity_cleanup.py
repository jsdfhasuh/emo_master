import json,os,pathlib,hashlib,subprocess,datetime,sqlite3
r=pathlib.Path('/workspace/shared/emo-display-5410737-acceptance-20261013');ids={};reports={}
for scene in ('full-lifecycle','close-running'):
 rows=[json.loads(x) for x in (r/f'evidence/native-{scene}/observer.jsonl').read_text().splitlines()]
 for row in rows:
  if row['kind']=='observer_start':ids[row['pid']]={'origin':scene,'starttime_ticks':None}
  for ch in row.get('observed_children',[]):ids[ch['pid']]={'origin':scene,'starttime_ticks':ch['starttime_ticks']}
for p in r.glob('evidence/*.pid'):
 try:ids[int(p.read_text())]={'origin':p.name,'starttime_ticks':None}
 except ValueError:pass
ids[20465]={'origin':'Designer runtime log filename runtime-20261013-055903-20465-0001.jsonl','starttime_ticks':None}
checked=[]
for pid,ref in ids.items():
 try:
  text=pathlib.Path(f'/proc/{pid}/stat').read_text();f=text[text.rfind(')')+2:].split();ticks=int(f[19]);same=ref['starttime_ticks'] in (None,ticks)
  checked.append(dict(pid=pid,**ref,present=True,state=f[0],actual_starttime_ticks=ticks,same_identity=same))
 except FileNotFoundError:checked.append(dict(pid=pid,**ref,present=False))
matching=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  if str(r) in cmd and any(t in cmd for t in ('observe_display_541_native.py','emo_master.apps','multiprocessing.spawn','r3_policy_measure.py')):matching.append({'pid':int(p.name),'command':cmd})
 except (OSError,ValueError):pass
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'check_process_pid':os.getpid(),'tracked':checked,'matching_product_processes':matching,'note':'Executed on actual desktop terminal. Includes known PID fences; not assertion that no unrelated host processes exist.'}
(r/'evidence/environment/final-process-check.json').write_text(json.dumps(out,indent=2))
source=r/'source'; db=source/'manual_test_workspace/runtime-embedded/emo_master.db';con=sqlite3.connect(f'file:{db}?mode=ro',uri=True);con.row_factory=sqlite3.Row
(r/'evidence/environment/designer-jobs-readonly.json').write_text(json.dumps({'jobs':[dict(x) for x in con.execute('select * from jobs')],'note':'Read-only isolated Designer DB after exit; does not prove internal owned resources without process evidence.'},indent=2,default=str));con.close()
original=source/'examples/workflow_debugger/01-nested-calls.emoproj';copy=r/'projects/designer-check.emoproj'
a=json.loads(original.read_text());b=json.loads(copy.read_text());
def core(d):
 return {w:{'nodes':[(n['nodeId'],n.get('kind'),n.get('params',{}),n.get('targetWorkflowId')) for n in wf['nodes']],'edges':wf['edges'],'positions':wf.get('layout',{}).get('nodePositions',{})} for w,wf in d['workflows'].items()}
(r/'evidence/environment/final-git-projects.json').write_text(json.dumps({'head':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),'dirty':subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True),'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'copy_sha256':hashlib.sha256(copy.read_bytes()).hexdigest(),'original_revision':a['project']['revision'],'copy_revision':b['project']['revision'],'core_nodes_edges_positions_equal':core(a)==core(b),'note':'Formal Run calls _syncRuntimeProjectBeforeRun and saves revision; independent copy changed, original untouched. Not independent-debug contamination test.'},indent=2))
print(json.dumps(out,indent=2))
