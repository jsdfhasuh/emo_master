"""5410737 native OperatorWindow: passive sampling plus labelled auxiliary controls.
Product UI owns all five real sessions. No added network consumer, auto Start/Stop,
quota/deadline changes, or product edits. Auxiliary shared-window and stream-cancel
buttons are explicit test controls, NOT existing product UI acceptance.
Retained Python session/server references delay GC, not explicit close or owned
resource retirement. Sampling/JSON/PNG introduce overhead and are not ABBA evidence.
"""
import argparse
from collections import defaultdict
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import subprocess
import sys
import threading
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--data-root', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--plugin-root', type=Path, action='append', required=True,
                        help='Repeat for builtins and generated project/plugins directory')
    args = parser.parse_args()
    source, evidence = args.source.resolve(), args.evidence.resolve()
    if evidence.exists() or evidence.is_relative_to(source):
        parser.error('evidence must be new and outside source')
    if args.data_root.resolve().is_relative_to(source):
        parser.error('data-root must be outside source')
    evidence.mkdir(parents=True)
    sys.path[:0] = [str(source/'src'), str(source)]
    os.chdir(source)
    import cv2
    from PySide2.QtCore import QSettings, QTimer
    from PySide2.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QPushButton
    from emo_master.ui.presentation.renderer import RuntimePages
    from emo_master.apps.operator_runtime.controller import ProductionRuntime
    from emo_master.apps.operator_runtime.main import OperatorWindow
    lock = threading.Lock()
    observed_processes = {}
    signature = {}
    image_counts = defaultdict(int)
    saved_images = set()
    record_seen = set()
    displayed_seen = set()
    retained_sessions = {}
    retained_servers = {}
    live_seen = set()
    admission_seen = set()
    auxiliary_pages = {}
    last_event_sequences = {}

    def remember_sessions():
        current = dict(window.workflowSessions)
        if window.session is not None:
            current['single'] = window.session
        for workflow, session in current.items():
            retained_sessions[id(session)] = (workflow, session)
        return current

    def server_sample(server, stage):
        """Runs on the server loop while live; final read only after explicit close."""
        try:
            sub = server.displaySubscriptions
            rows = list(sub.events)
            previous = last_event_sequences.get(id(server), 0)
            if rows and rows[0]['sequence'] > previous + 1:
                emit('admission_retention_gap', server=id(server), previous=previous,
                     first_retained=rows[0]['sequence'])
            for row in rows:
                token = (id(server), row['sequence'])
                if token not in admission_seen:
                    admission_seen.add(token)
                    emit('admission_event', server=id(server), stage=stage, event=dict(row))
            if rows:
                last_event_sequences[id(server)] = rows[-1]['sequence']
            changed('server_resources', id(server), dict(stage=stage, active=dict(server.active),
                work_active=sub.workActive, work_peak=sub.workPeak, by_job=dict(sub.byJob),
                cleanups=len(server.cleanups), errors=list(server.errors),
                event_sequence=sub.eventSequence, events_retained=len(rows),
                jobs_limit=sub.jobsLimit, per_job_limit=sub.perJobLimit))
        except Exception as error:
            emit('observer_error', stage='server_sample', error=repr(error))

    def session_sample():
        current_ids = {id(value) for value in remember_sessions().values()}
        for identity, (workflow, session) in list(retained_sessions.items()):
            with session.lock:
                rows = list(session.records)
                state = dict(job_id=session.jobId, runtime_instance_id=session.instanceId,
                    generation=session.generation, high=dict(session.high), expired=dict(session.expired),
                    stats=dict(session.stats), errors=list(session.errors), connection=session.connection,
                    current=identity in current_ids, closed=session.stop.is_set(),
                    stream_id=id(session.stream) if session.stream is not None else None,
                    stream_active=session.stream.is_active() if session.stream is not None else None,
                    records_retained=len(rows), pending=session.pending.qsize(),
                    threads=[dict(name=t.name, ident=t.ident, alive=t.is_alive()) for t in session.threads])
            changed('session_resources', identity, state)
            for row in rows:
                token=(identity,row.get('key'),row.get('received_ns'),row.get('decoded_ns'))
                if token not in live_seen:
                    live_seen.add(token)
                    emit('live_record', workflow=workflow, session=identity, record=row)


    def emit(kind, **fields):
        with lock:
            with (evidence/'observer.jsonl').open('a', encoding='utf-8') as stream:
                stream.write(json.dumps({'kind': kind, 'time_ns': time.perf_counter_ns(),
                    'pid': os.getpid(), **fields}, ensure_ascii=False, default=str)+'\n')

    def changed(kind, key, value):
        serialized = json.dumps(value, sort_keys=True, default=str)
        if signature.get((kind, key)) != serialized:
            signature[(kind, key)] = serialized
            emit(kind, key=key, **value)

    def proc_stat(pid):
        """Linux stat field 22 starttime fences PID reuse; no third-party package."""
        content = (Path('/proc') / str(pid) / 'stat').read_text()
        close = content.rfind(')')
        if close < 0:
            raise ValueError('invalid /proc stat')
        fields = content[close+2:].split()
        return {'pid': int(pid), 'name': content[content.find('(')+1:close],
                'state': fields[0], 'ppid': int(fields[1]), 'starttime_ticks': int(fields[19])}

    def process_state():
        table = {}
        scan_errors = []
        try:
            entries = list(Path('/proc').iterdir())
        except OSError as error:
            emit('observer_error', stage='proc_scan', error=repr(error))
            entries = []
        for entry in entries:
            if not entry.name.isdigit():
                continue
            try:
                table[int(entry.name)] = proc_stat(int(entry.name))
            except FileNotFoundError:
                pass  # A process retired between directory listing and stat read.
            except (OSError, ValueError, IndexError) as error:
                scan_errors.append({'pid': int(entry.name), 'error': repr(error)})
        descendants, frontier = set(), {os.getpid()}
        while frontier:
            children = {pid for pid, row in table.items()
                        if row['ppid'] in frontier and pid not in descendants}
            descendants.update(children)
            frontier = children
        for pid in descendants:
            row = table[pid]
            observed_processes[(pid, row['starttime_ticks'])] = row['name']
        rows = []
        for (pid, started), name in list(observed_processes.items()):
            try:
                current = proc_stat(pid)
                same = current['starttime_ticks'] == started
                rows.append(dict(pid=pid, starttime_ticks=started, name=name,
                    alive=same, status=current['state'] if same else 'pid_reused',
                    note='A zombie remains present/alive here until its /proc entry is reaped.'))
            except FileNotFoundError:
                rows.append(dict(pid=pid, starttime_ticks=started, name=name, alive=False, status='gone'))
            except (OSError, ValueError, IndexError) as error:
                rows.append(dict(pid=pid, starttime_ticks=started, name=name, alive=None, error=repr(error)))
        if scan_errors:
            emit('proc_scan_errors', errors=scan_errors,
                note='Unreadable PIDs prevent claiming exhaustive descendant discovery.')
        return rows

    def asset_state(controller):
        # AssetStore.stats() calls _collect(), so inspect under its lock without
        # advancing cleanup: an observer must not cause the retirement it proves.
        assets = controller.presentation.assets
        with assets.lock:
            return dict(cache_bytes=sum(i['size'] for i in assets.items.values()),
                lease_handles=len(assets.leases), readers=sum(assets.readers.values()),
                assets=len(assets.items), passive_no_collect=True)

    def resources(controller):
        exporter = getattr(controller.presentation, 'exporter', None)
        slots = []
        for slot in list(exporter.slots) if exporter else []:
            process, thread = slot.get('process'), slot.get('thread')
            try:
                alive = process.is_alive() if process else False
            except Exception as error:
                alive = 'unverified:' + repr(error)
            slots.append({'index': slot.get('index'), 'pid': getattr(process, 'pid', None),
                'process_alive': alive, 'thread_alive': thread.is_alive() if thread else False,
                'busy': slot.get('busy'), 'pending': bool(slot.get('pending'))})
        return {'threads': [{'name': t.name, 'ident': t.ident, 'alive': t.is_alive()} for t in threading.enumerate()],
            'observed_children': process_state(), 'exporter_slots': slots,
            'reader_threads': {str(k): v.is_alive() for k, v in controller.presentation.readers.items()}}

    class ObservedRuntime(ProductionRuntime):
        def status(self, *a, **kw):
            result = super().status(*a, **kw)
            try:
                changed('runtime_status', 'owner', {'status': result, 'address': self.address if self.server else None})
                jobs = []
                for record in self.runtime.jobRepository.all():
                    events = self.runtime.eventStore.read(record.jobId)
                    completed = [e for e in events if e.eventType == 'workflow.completed']
                    jobs.append({'job': vars(record), 'workflow_completed_count': len(completed),
                        'workflow_completed_by_workflow': {wid: sum(e.workflowId == wid for e in completed)
                            for wid in {e.workflowId for e in completed}},
                        'recent_completed': [{'workflowId': e.workflowId, 'invocationId': e.workflowRunId,
                            'sequence': e.sequence} for e in completed[-10:]],
                        'owns_job_resources': self.runtime.jobSupervisor.ownsJobResources(record.jobId)})
                changed('jobs', 'all', {'jobs': jobs})
                changed('resources', 'all', resources(self))
                changed('assets', 'all', asset_state(self))
                if self.server is not None:
                    retained_servers[id(self.server)] = self.server
                    self.server.loop.call_soon_threadsafe(server_sample, self.server, 'live')
            except Exception as error:
                emit('observer_error', stage='status', error=repr(error))
            return result

        def close(self, *a, **kw):
            try:
                emit('runtime_close_enter', **resources(self))
                if self.server is not None:
                    retained_servers[id(self.server)] = self.server
            except Exception as error:
                emit('observer_error', stage='close_enter', error=repr(error))
            try:
                result = super().close(*a, **kw)
            except BaseException as error:
                emit('runtime_close_exception', error=repr(error))
                raise
            try:
                emit('runtime_close_return', closed=self.closed, assets=asset_state(self), **resources(self))
                for server in retained_servers.values():
                    if not server.thread.is_alive():
                        server_sample(server, 'retired')
            except Exception as error:
                emit('observer_error', stage='close_return', error=repr(error))
            return result

    app = QApplication.instance() or QApplication([])
    def factory(data_root):
        return ObservedRuntime(data_root, pluginRootPaths=tuple(str(p.resolve()) for p in args.plugin_root))
    window = OperatorWindow(args.project.resolve(), dataRoot=args.data_root.resolve(),
        preferences=QSettings(str(evidence/'preferences.ini'), QSettings.IniFormat), runtimeFactory=factory)

    controls = QWidget()
    controls.setWindowTitle('AUXILIARY TEST CONTROLS — NOT PRODUCT UI')
    layout = QVBoxLayout(controls)
    layout.addWidget(QLabel('辅助测试控制 / 故障注入，非产品原生入口\n仅复用当前 tab 的真实 Session/Hub；不新建网络消费者。'))
    def selected():
        page = window.workflowTabs.currentWidget()
        for key, candidate in window.workflowPages.items():
            if window.workflowControls[key]['layout'].parentWidget() is page:
                return key, candidate, window.workflowHubs.get(key), window.workflowSessions.get(key)
        raise ValueError('Select a running workflow tab first')
    def shared():
        try:
            key, page, hub, session = selected()
            if hub is None or session is None or key in auxiliary_pages:
                raise ValueError('No live hub or auxiliary window already open')
            second = RuntimePages(page.config, hub=hub)
            second.setWindowTitle('AUXILIARY SHARED WINDOW — ' + str(key))
            auxiliary_pages[key] = second
            second.show()
            emit('auxiliary_action', action='shared_window_open', workflow=key,
                session=id(session), hub=id(hub), native_product_entry=False)
        except Exception as error:
            emit('auxiliary_action_error', action='shared_window_open', error=repr(error))
    def close_shared():
        for key, page in list(auxiliary_pages.items()):
            page.close()
            del auxiliary_pages[key]
            emit('auxiliary_action', action='shared_window_close', workflow=key, native_product_entry=False)
    def reconnect():
        try:
            key, page, hub, session = selected()
            if session is None or session.stream is None:
                raise ValueError('No current stream')
            old = session.stream
            emit('auxiliary_action', action='stream_cancel_fault_injection', workflow=key,
                 session=id(session), stream=id(old), native_product_entry=False)
            old.cancel()
        except Exception as error:
            emit('auxiliary_action_error', action='stream_cancel_fault_injection', error=repr(error))
    for label, callback in [('辅助：打开当前 tab 共享窗', shared), ('辅助：关闭共享窗', close_shared),
                            ('故障注入：取消当前订阅以观察自动重连', reconnect)]:
        button = QPushButton(label)
        button.clicked.connect(callback)
        layout.addWidget(button)

    def sample():
        try:
            session_sample()
            if window.closing:
                close_shared()
                controls.close()
            pages = dict(window.workflowPages)
            pages.update({'auxiliary:'+key: value for key,value in auxiliary_pages.items()})
            if window.pages is not None:
                pages['single'] = window.pages
            for workflow, page in pages.items():
                for row in list(page.records):
                    key = (id(page), row.get('key'), row.get('gui_ns'), row.get('paint_ns'))
                    if key not in record_seen:
                        record_seen.add(key)
                        emit('qt_record', workflow=workflow, window=id(page), record=dict(row))
                for scope_id, scope in dict(page.displayed).items():
                    identity = scope.result.identity.model_dump()
                    key = (id(page), identity['jobId'], identity['resultKey'])
                    if key not in displayed_seen:
                        displayed_seen.add(key)
                        emit('displayed', workflow=workflow, scope=scope_id, window=id(page),
                            result=scope.result.model_dump(mode='json'), image_states=dict(scope.imageStates), errors=dict(scope.failures))
                    for source_id, pixels in scope.images.items():
                        image_key = (identity['jobId'], identity['resultKey'], source_id)
                        if image_key in saved_images or image_counts[identity['jobId']] >= 5:
                            continue
                        image_counts[identity['jobId']] += 1
                        saved_images.add(image_key)
                        file_key = hashlib.sha256(json.dumps(image_key).encode()).hexdigest()[:24]
                        filename = file_key + '.png'
                        success = cv2.imwrite(str(evidence/filename), pixels)
                        if not success:
                            raise RuntimeError('observer PNG save failed: '+filename)
                        source_ref = next((s.image.model_dump(mode='json') for s in scope.result.sources
                            if s.sourceId == source_id and s.image), None)
                        emit('displayed_image', workflow=workflow, window=id(page), source_id=source_id,
                            result=scope.result.model_dump(mode='json'), image_ref=source_ref,
                            shape=list(pixels.shape), dtype=str(pixels.dtype), strides=list(pixels.strides),
                            readonly=not pixels.flags.writeable, pixels_sha256=hashlib.sha256(pixels.tobytes(order='C')).hexdigest(),
                            derived_png=filename, derived_png_sha256=hashlib.sha256((evidence/filename).read_bytes()).hexdigest())
            sessions = dict(window.workflowSessions)
            if window.session is not None:
                sessions['single'] = window.session
            for workflow, session in sessions.items():
                snapshot = session.readSnapshot()
                changed('session_snapshot', workflow, {'job_id': snapshot.jobId, 'revision': snapshot.revision,
                    'session': id(session), 'hub': id(window.workflowHubs.get(workflow)),
                    'scopes': {sid: {'identity': value.result.identity.model_dump(mode='json'),
                        'image_states': dict(value.imageStates), 'errors': dict(value.failures),
                        'decoded_source_ids': list(value.images)} for sid, value in snapshot.scopes.items()}})
        except Exception as error:
            emit('observer_error', stage='qt_sample', error=repr(error))

    emit('observer_start', source=str(source), head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), python=sys.executable,
        project=str(args.project.resolve()), plugin_roots=[str(p.resolve()) for p in args.plugin_root],
        data_root=str(args.data_root.resolve()), platform=app.platformName(),
        boundaries=['Actual product OperatorWindow; only public runtimeFactory injects plugin roots.',
            'No automatic start/stop/target choice/extra consumers; shared GUI naturally updates demand.',
            'Labelled auxiliary shared-window and stream-cancel buttons are NOT original product entry points.',
            'Retained session/server references delay GC only; explicit close and owned resources are measured.',
            'Admission ring 512, live ring 128 and Qt ring 256: sampling can miss evicted records; never all-96 proof.',
            '100ms sampled displayed/records evidence; does not prove all invocations were seen.',
            'At most five actual displayed image PNGs per Job; saves and observations add overhead.',
            'Derived PNG hash is not the original transported PNG hash; original ImageRef hash is separate.'])
    timer = QTimer(window)
    timer.timeout.connect(sample)
    timer.start(100)
    window.show()
    controls.show()
    code = app.exec_()
    timer.stop()
    session_sample()
    for server in retained_servers.values():
        if not server.thread.is_alive():
            server_sample(server, "event_loop_return")
    emit('qt_event_loop_return', exit_code=code, window_done=window.done,
        observed_children=process_state(), threads=[{'name':t.name,'alive':t.is_alive()} for t in threading.enumerate()],
        image_counts=dict(image_counts))
    return code


if __name__ == '__main__':
    multiprocessing.freeze_support()
    raise SystemExit(main())
