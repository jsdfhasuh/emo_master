#!/bin/bash
R=/workspace/shared/emo-display-5410737-acceptance-20261013
cd "$R/source" || exit 1
export QT_QPA_PLATFORM=offscreen PYTHONUTF8=1 PYTHONIOENCODING=utf-8
export XDG_CONFIG_HOME="$R/config-software" XDG_CACHE_HOME="$R/cache-software" XDG_DATA_HOME="$R/data-software"
export EMO_DISPLAY_EVIDENCE="$R/evidence/automated/software-artifacts"
"$R/venv/bin/python" -m pytest -v tests/runtime/presentation/test_display_subscriptions.py tests/runtime/presentation/test_live_decisions.py tests/runtime/test_stop_all_dispatch.py --junitxml="$R/evidence/automated/software-junit.xml" -o faulthandler_timeout=90 > "$R/evidence/automated/software.log" 2>&1
printf '%s\n' "$?" > "$R/evidence/automated/software.exit"
