EmoMaster 8c13404 — Final Debian desktop evidence

Extract all five independent ZIPs into the same directory. Shared MANIFEST-FINAL.json and README-FINAL.txt are identical across packages. Each has an independent package SHA256SUMS file.

Read report/EmoMaster-8c13404-Debian-acceptance-zh.pdf or .docx for scoped findings; report 9 pages and matrix 24 cases. A02 original ABBA all 96 display coverage and W01 five-While subscription/display remain FAIL. Correct saved pixels do not cancel display failures. Windows Actions were not queried this round.

Data package: complete original four ABBA raw arms, independent 96 pixel probe, native Qt gallery fixtures and results, Designer exports/projects, NG/five-While raw records and process/thread checks, helper scripts, first psutil import failure, offline audits and final report/build script.
Screenshots package: 119 unchanged product screenshots of 125 originals. Six unrelated/host-terminal screenshots excluded with hash/reason.
Video ABBA package: 4 actual Qt excerpts, not all warmup frames. Original trial0 ordinal2 gap remains in raw trace/timeline.
Video probe/gallery package: independent pixel probe and native Qt gallery, not original ABBA or Designer.
Video Designer/runtime package: continuous Designer original packet range 333.333–2133.166 s split into 2 files with no missing packet at the split, followed by NG and five-While excerpts including RESOURCE_EXHAUSTED. D05/D06 waiting periods are retained at original speed.

Full 2898-second recording and excluded originals remain in task workspace. Delivered 10 video excerpts are not the full recording or proof of every cleanup step. Original recording SHA, ranges and packet proofs are included. ffmpeg log shows SIGINT; no independent wait return code was collected. Retirement claims are limited to recorded tracked PIDs/threads.
