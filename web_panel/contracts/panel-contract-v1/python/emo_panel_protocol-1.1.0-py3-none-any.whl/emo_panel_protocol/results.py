"""Closed-result/asset DTOs only; no exporter, cache or subscription implementation."""
from __future__ import annotations

from typing import Literal

from pydantic import ConfigDict, Field, model_validator

from emo_panel_protocol.models import Id, Model
from emo_panel_protocol.values import readValue


class FrozenModel(Model):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True, allow_inf_nan=False)


class ResultIdentity(FrozenModel):
    runtimeInstanceId: Id
    jobId: Id
    resultScopeId: Id
    invocationId: Id
    resultKey: Id
    resultOrdinal: int = Field(ge=1)
    executionRevision: str = Field(pattern=r"^[0-9a-f]{64}$")
    capturePlanRevision: str = Field(pattern=r"^[0-9a-f]{64}$")
    mode: Literal["debug", "release", "runtime"]


class FrameProvenance(FrozenModel):
    frameIdentity: Id
    coordinateSpaceId: Id
    trust: Literal["proven", "unknown"]
    parentFrameIdentity: Id | None = None
    adapterVersion: Id | None = None


class ImageRef(FrozenModel):
    resourceId: Id
    ownerResultKey: Id
    byteSize: int = Field(gt=0, le=8 * 1024 * 1024)
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    mimeType: Literal["image/png", "image/jpeg"]
    provenance: FrameProvenance
    ownership: Literal["result_store"] = "result_store"


class AssetLease(FrozenModel):
    leaseId: Id
    resourceId: Id
    ttlMs: int = Field(gt=0, le=30000)
    # Lease expiry uses the owner's monotonic clock; never compare clocks across hosts.
    clock: Literal["owner_monotonic"] = "owner_monotonic"


class ClosedSource(FrozenModel):
    sourceId: Id
    state: Literal["AVAILABLE", "UNAVAILABLE"]
    valueJson: str | None = Field(default=None, max_length=256 * 1024)
    image: ImageRef | None = None
    reason: str | None = None
    reasonCode: Literal["OPTIONAL_ABSENT", "BRANCH_SKIPPED", "NODE_FAILED", "EXECUTION_CANCELLED",
                        "EXPORT_TIMEOUT", "EXPORT_FAILED", "RESOURCE_EXPIRED", "BUDGET_EXCEEDED",
                        "INVALID_VALUE", "SOURCE_MISSING", "IPC_ERROR"] | None = None

    @model_validator(mode="after")
    def checkAvailability(self) -> ClosedSource:
        if self.state == "AVAILABLE":
            if (self.valueJson is None) == (self.image is None) or self.reason is not None or self.reasonCode is not None:
                raise ValueError("available source requires exactly one frozen value or owned asset")
            if self.valueJson is not None:
                readValue(self.valueJson)
        elif not self.reason or self.valueJson is not None or self.image is not None:
            raise ValueError("unavailable source requires reason and no stale payload")
        return self


class ResultTiming(FrozenModel):
    captureStartedNs: int = Field(ge=0)
    scopeEndedNs: int = Field(ge=0)
    closedNs: int = Field(ge=0)
    clock: Literal["runtime_monotonic"] = "runtime_monotonic"


class ClosedResult(FrozenModel):
    identity: ResultIdentity
    expectedSourceIds: tuple[Id, ...] = Field(max_length=16)
    sources: tuple[ClosedSource, ...] = Field(max_length=16)
    status: Literal["COMPLETE", "INCOMPLETE", "FAILED", "CANCELLED"]
    executionTerminal: Literal["COMPLETED", "FAILED", "CANCELLED", "UNKNOWN"]
    timing: ResultTiming | None = None

    @model_validator(mode="after")
    def checkManifest(self) -> ClosedResult:
        actual = [source.sourceId for source in self.sources]
        if (len(set(actual)) != len(actual) or len(set(self.expectedSourceIds)) != len(self.expectedSourceIds)
                or set(actual) != set(self.expectedSourceIds)):
            raise ValueError("closed result must account for every expected source exactly once")
        complete = all(source.state == "AVAILABLE" for source in self.sources)
        expected = ("COMPLETE" if complete else "INCOMPLETE") if self.executionTerminal == "COMPLETED" else self.executionTerminal
        if self.executionTerminal == "UNKNOWN":
            expected = "INCOMPLETE"
        if self.status != expected:
            raise ValueError("status contradicts execution terminal or export outcome")
        if sum(len(source.valueJson.encode()) for source in self.sources if source.valueJson) > 1024 * 1024:
            raise ValueError("result value byte budget exceeded")
        for source in self.sources:
            if source.image and source.image.ownerResultKey != self.identity.resultKey:
                raise ValueError("asset must be owned by this result before closure")
        images: dict[str, ImageRef] = {}
        for source in self.sources:
            if source.image is not None:
                previous = images.setdefault(source.image.resourceId, source.image)
                if previous != source.image:
                    raise ValueError("aliased image resource has inconsistent metadata")
        if sum(image.byteSize for image in images.values()) > 16 * 1024 * 1024:
            raise ValueError("result image byte budget exceeded")
        return self


class ResultNotification(FrozenModel):
    messageCursor: int = Field(ge=1)
    result: ClosedResult
